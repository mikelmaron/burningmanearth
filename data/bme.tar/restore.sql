create temporary table pgdump_restore_path(p text);
--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
-- Edit the following to match the path where the
-- tar archive has been extracted.
--
insert into pgdump_restore_path values('/tmp');

--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET standard_conforming_strings = off;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET escape_string_warning = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.web_circular_street DROP CONSTRAINT year_id_refs_id_4f38e2fa;
ALTER TABLE ONLY public.web_theme_camp DROP CONSTRAINT web_theme_camp_year_id_fkey;
ALTER TABLE ONLY public.web_theme_camp_participants DROP CONSTRAINT web_theme_camp_participants_user_id_fkey;
ALTER TABLE ONLY public.web_theme_camp_participants DROP CONSTRAINT web_theme_camp_participants_theme_camp_id_fkey;
ALTER TABLE ONLY public.web_theme_camp DROP CONSTRAINT web_theme_camp_circular_street_id_fkey;
ALTER TABLE ONLY public.web_playa_event DROP CONSTRAINT web_playa_event_year_id_fkey;
ALTER TABLE ONLY public.web_playa_event DROP CONSTRAINT web_playa_event_hosted_by_camp_id_fkey;
ALTER TABLE ONLY public.web_art_installation DROP CONSTRAINT web_art_installation_year_id_fkey;
ALTER TABLE ONLY public.web_art_installation DROP CONSTRAINT web_art_installation_circular_street_id_fkey;
ALTER TABLE ONLY public.auth_message DROP CONSTRAINT user_id_refs_id_650f49a6;
ALTER TABLE ONLY public.tagging_taggeditem DROP CONSTRAINT tagging_taggeditem_content_type_id_fkey;
ALTER TABLE ONLY public.tagging_taggeditem DROP CONSTRAINT tag_id_refs_id_60aefff3;
ALTER TABLE ONLY public.feedjack_subscriber DROP CONSTRAINT feedjack_subscriber_site_id_fkey;
ALTER TABLE ONLY public.feedjack_subscriber DROP CONSTRAINT feedjack_subscriber_feed_id_fkey;
ALTER TABLE ONLY public.feedjack_site_links DROP CONSTRAINT feedjack_site_links_site_id_fkey;
ALTER TABLE ONLY public.feedjack_site_links DROP CONSTRAINT feedjack_site_links_link_id_fkey;
ALTER TABLE ONLY public.feedjack_post_tags DROP CONSTRAINT feedjack_post_tags_tag_id_fkey;
ALTER TABLE ONLY public.feedjack_post_tags DROP CONSTRAINT feedjack_post_tags_post_id_fkey;
ALTER TABLE ONLY public.feedjack_post DROP CONSTRAINT feedjack_post_feed_id_fkey;
ALTER TABLE ONLY public.django_flatpage_sites DROP CONSTRAINT django_flatpage_sites_site_id_fkey;
ALTER TABLE ONLY public.django_flatpage_sites DROP CONSTRAINT django_flatpage_sites_flatpage_id_fkey;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_fkey;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_content_type_id_fkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT content_type_id_refs_id_728de91f;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_fkey;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_permission_id_fkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_fkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_fkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_permission_id_fkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_fkey;
DROP INDEX public.web_year_location_point_id;
DROP INDEX public.web_theme_camp_year_id;
DROP INDEX public.web_theme_camp_location_poly_id;
DROP INDEX public.web_theme_camp_location_point_id;
DROP INDEX public.web_theme_camp_circular_street_id;
DROP INDEX public.web_playa_event_year_id;
DROP INDEX public.web_playa_event_location_track_id;
DROP INDEX public.web_playa_event_location_point_id;
DROP INDEX public.web_playa_event_located_at_art_id;
DROP INDEX public.web_playa_event_hosted_by_camp_id;
DROP INDEX public.web_circular_street_year_id;
DROP INDEX public.web_art_installation_year_id;
DROP INDEX public.web_art_installation_slug;
DROP INDEX public.web_art_installation_location_poly_id;
DROP INDEX public.web_art_installation_location_point_id;
DROP INDEX public.web_art_installation_circular_street_id;
DROP INDEX public.tagging_taggeditem_tag_id;
DROP INDEX public.tagging_taggeditem_object_id;
DROP INDEX public.tagging_taggeditem_content_type_id;
DROP INDEX public.feedjack_subscriber_site_id;
DROP INDEX public.feedjack_subscriber_feed_id;
DROP INDEX public.feedjack_post_guid;
DROP INDEX public.feedjack_post_feed_id;
DROP INDEX public.django_flatpage_url;
DROP INDEX public.django_admin_log_user_id;
DROP INDEX public.django_admin_log_content_type_id;
DROP INDEX public.auth_permission_content_type_id;
DROP INDEX public.auth_message_user_id;
ALTER TABLE ONLY public.web_year DROP CONSTRAINT web_year_pkey;
ALTER TABLE ONLY public.web_theme_camp DROP CONSTRAINT web_theme_camp_pkey;
ALTER TABLE ONLY public.web_theme_camp_participants DROP CONSTRAINT web_theme_camp_participants_theme_camp_id_key;
ALTER TABLE ONLY public.web_theme_camp_participants DROP CONSTRAINT web_theme_camp_participants_pkey;
ALTER TABLE ONLY public.web_playa_event DROP CONSTRAINT web_playa_event_pkey;
ALTER TABLE ONLY public.web_circular_street DROP CONSTRAINT web_circular_street_pkey;
ALTER TABLE ONLY public.web_art_installation DROP CONSTRAINT web_art_installation_pkey;
ALTER TABLE ONLY public.tagging_taggeditem DROP CONSTRAINT tagging_taggeditem_tag_id_key;
ALTER TABLE ONLY public.tagging_taggeditem DROP CONSTRAINT tagging_taggeditem_pkey;
ALTER TABLE ONLY public.tagging_tag DROP CONSTRAINT tagging_tag_pkey;
ALTER TABLE ONLY public.tagging_tag DROP CONSTRAINT tagging_tag_name_key;
ALTER TABLE ONLY public.spatial_ref_sys DROP CONSTRAINT spatial_ref_sys_pkey;
ALTER TABLE ONLY public.geometry_columns DROP CONSTRAINT geometry_columns_pk;
ALTER TABLE ONLY public.feedjack_tag DROP CONSTRAINT feedjack_tag_pkey;
ALTER TABLE ONLY public.feedjack_tag DROP CONSTRAINT feedjack_tag_name_key;
ALTER TABLE ONLY public.feedjack_subscriber DROP CONSTRAINT feedjack_subscriber_site_id_key;
ALTER TABLE ONLY public.feedjack_subscriber DROP CONSTRAINT feedjack_subscriber_pkey;
ALTER TABLE ONLY public.feedjack_site DROP CONSTRAINT feedjack_site_url_key;
ALTER TABLE ONLY public.feedjack_site DROP CONSTRAINT feedjack_site_pkey;
ALTER TABLE ONLY public.feedjack_site_links DROP CONSTRAINT feedjack_site_links_site_id_key;
ALTER TABLE ONLY public.feedjack_site_links DROP CONSTRAINT feedjack_site_links_pkey;
ALTER TABLE ONLY public.feedjack_post_tags DROP CONSTRAINT feedjack_post_tags_post_id_key;
ALTER TABLE ONLY public.feedjack_post_tags DROP CONSTRAINT feedjack_post_tags_pkey;
ALTER TABLE ONLY public.feedjack_post DROP CONSTRAINT feedjack_post_pkey;
ALTER TABLE ONLY public.feedjack_post DROP CONSTRAINT feedjack_post_feed_id_key;
ALTER TABLE ONLY public.feedjack_link DROP CONSTRAINT feedjack_link_pkey;
ALTER TABLE ONLY public.feedjack_link DROP CONSTRAINT feedjack_link_name_key;
ALTER TABLE ONLY public.feedjack_feed DROP CONSTRAINT feedjack_feed_pkey;
ALTER TABLE ONLY public.feedjack_feed DROP CONSTRAINT feedjack_feed_feed_url_key;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_pkey;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_flatpage_sites DROP CONSTRAINT django_flatpage_sites_pkey;
ALTER TABLE ONLY public.django_flatpage_sites DROP CONSTRAINT django_flatpage_sites_flatpage_id_key;
ALTER TABLE ONLY public.django_flatpage DROP CONSTRAINT django_flatpage_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_key;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_key;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_key;
ALTER TABLE ONLY public.auth_message DROP CONSTRAINT auth_message_pkey;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_key;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.web_year ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.web_theme_camp_participants ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.web_theme_camp ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.web_playa_event ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.web_circular_street ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.web_art_installation ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tagging_taggeditem ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.tagging_tag ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.feedjack_tag ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.feedjack_subscriber ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.feedjack_site_links ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.feedjack_site ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.feedjack_post_tags ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.feedjack_post ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.feedjack_link ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.feedjack_feed ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_site ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_flatpage_sites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_flatpage ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_message ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.web_year_id_seq;
DROP TABLE public.web_year;
DROP SEQUENCE public.web_theme_camp_participants_id_seq;
DROP TABLE public.web_theme_camp_participants;
DROP SEQUENCE public.web_theme_camp_id_seq;
DROP TABLE public.web_theme_camp;
DROP SEQUENCE public.web_playa_event_id_seq;
DROP TABLE public.web_playa_event;
DROP SEQUENCE public.web_circular_street_id_seq;
DROP TABLE public.web_circular_street;
DROP SEQUENCE public.web_art_installation_id_seq;
DROP TABLE public.web_art_installation;
DROP SEQUENCE public.tagging_taggeditem_id_seq;
DROP TABLE public.tagging_taggeditem;
DROP SEQUENCE public.tagging_tag_id_seq;
DROP TABLE public.tagging_tag;
DROP TABLE public.spatial_ref_sys;
DROP TABLE public.geometry_columns;
DROP SEQUENCE public.feedjack_tag_id_seq;
DROP TABLE public.feedjack_tag;
DROP SEQUENCE public.feedjack_subscriber_id_seq;
DROP TABLE public.feedjack_subscriber;
DROP SEQUENCE public.feedjack_site_links_id_seq;
DROP TABLE public.feedjack_site_links;
DROP SEQUENCE public.feedjack_site_id_seq;
DROP TABLE public.feedjack_site;
DROP SEQUENCE public.feedjack_post_tags_id_seq;
DROP TABLE public.feedjack_post_tags;
DROP SEQUENCE public.feedjack_post_id_seq;
DROP TABLE public.feedjack_post;
DROP SEQUENCE public.feedjack_link_id_seq;
DROP TABLE public.feedjack_link;
DROP SEQUENCE public.feedjack_feed_id_seq;
DROP TABLE public.feedjack_feed;
DROP SEQUENCE public.django_site_id_seq;
DROP TABLE public.django_site;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_flatpage_sites_id_seq;
DROP TABLE public.django_flatpage_sites;
DROP SEQUENCE public.django_flatpage_id_seq;
DROP TABLE public.django_flatpage;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_message_id_seq;
DROP TABLE public.auth_message;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
SET search_path = pg_catalog;

DROP CAST (text AS public.geometry);
DROP CAST (public.geometry AS text);
DROP CAST (public.geometry AS bytea);
DROP CAST (public.geometry AS public.box3d);
DROP CAST (public.geometry AS public.box2d);
DROP CAST (public.geometry AS box);
DROP CAST (public.chip AS public.geometry);
DROP CAST (bytea AS public.geometry);
DROP CAST (public.box3d AS public.geometry);
DROP CAST (public.box3d AS public.box2d);
DROP CAST (public.box3d AS box);
DROP CAST (public.box2d AS public.geometry);
DROP CAST (public.box2d AS public.box3d);
SET search_path = public, pg_catalog;

DROP OPERATOR CLASS public.gist_geometry_ops USING gist;
DROP OPERATOR CLASS public.btree_geometry_ops USING btree;
DROP OPERATOR public.~= (geometry, geometry);
DROP OPERATOR public.~ (geometry, geometry);
DROP OPERATOR public.|>> (geometry, geometry);
DROP OPERATOR public.|&> (geometry, geometry);
DROP OPERATOR public.@ (geometry, geometry);
DROP OPERATOR public.>> (geometry, geometry);
DROP OPERATOR public.>= (geometry, geometry);
DROP OPERATOR public.> (geometry, geometry);
DROP OPERATOR public.= (geometry, geometry);
DROP OPERATOR public.<= (geometry, geometry);
DROP OPERATOR public.<<| (geometry, geometry);
DROP OPERATOR public.<< (geometry, geometry);
DROP OPERATOR public.< (geometry, geometry);
DROP OPERATOR public.&> (geometry, geometry);
DROP OPERATOR public.&<| (geometry, geometry);
DROP OPERATOR public.&< (geometry, geometry);
DROP OPERATOR public.&& (geometry, geometry);
DROP AGGREGATE public.st_union(geometry);
DROP AGGREGATE public.st_polygonize(geometry);
DROP AGGREGATE public.st_memunion(geometry);
DROP AGGREGATE public.st_memcollect(geometry);
DROP AGGREGATE public.st_makeline(geometry);
DROP AGGREGATE public.st_extent3d(geometry);
DROP AGGREGATE public.st_extent(geometry);
DROP AGGREGATE public.st_collect(geometry);
DROP AGGREGATE public.st_accum(geometry);
DROP AGGREGATE public.polygonize(geometry);
DROP AGGREGATE public.memgeomunion(geometry);
DROP AGGREGATE public.memcollect(geometry);
DROP AGGREGATE public.makeline(geometry);
DROP AGGREGATE public.geomunion(geometry);
DROP AGGREGATE public.extent3d(geometry);
DROP AGGREGATE public.extent(geometry);
DROP AGGREGATE public.collect(geometry);
DROP AGGREGATE public.accum(geometry);
DROP FUNCTION public.zmin(box3d);
DROP FUNCTION public.zmflag(geometry);
DROP FUNCTION public.zmax(box3d);
DROP FUNCTION public.z(geometry);
DROP FUNCTION public.ymin(box3d);
DROP FUNCTION public.ymax(box3d);
DROP FUNCTION public.y(geometry);
DROP FUNCTION public.xmin(box3d);
DROP FUNCTION public.xmax(box3d);
DROP FUNCTION public.x(geometry);
DROP FUNCTION public.within(geometry, geometry);
DROP FUNCTION public.width(chip);
DROP FUNCTION public.updategeometrysrid(character varying, character varying, integer);
DROP FUNCTION public.updategeometrysrid(character varying, character varying, character varying, integer);
DROP FUNCTION public.updategeometrysrid(character varying, character varying, character varying, character varying, integer);
DROP FUNCTION public.update_geometry_stats(character varying, character varying);
DROP FUNCTION public.update_geometry_stats();
DROP FUNCTION public.unlockrows(text);
DROP FUNCTION public.unite_garray(geometry[]);
DROP FUNCTION public.transscale(geometry, double precision, double precision, double precision, double precision);
DROP FUNCTION public.translate(geometry, double precision, double precision);
DROP FUNCTION public.translate(geometry, double precision, double precision, double precision);
DROP FUNCTION public.transform_geometry(geometry, text, text, integer);
DROP FUNCTION public.transform(geometry, integer);
DROP FUNCTION public.touches(geometry, geometry);
DROP FUNCTION public.text(boolean);
DROP FUNCTION public.text(geometry);
DROP FUNCTION public.symmetricdifference(geometry, geometry);
DROP FUNCTION public.symdifference(geometry, geometry);
DROP FUNCTION public.summary(geometry);
DROP FUNCTION public.startpoint(geometry);
DROP FUNCTION public.st_zmin(box3d);
DROP FUNCTION public.st_zmflag(geometry);
DROP FUNCTION public.st_zmax(box3d);
DROP FUNCTION public.st_z(geometry);
DROP FUNCTION public.st_ymin(box3d);
DROP FUNCTION public.st_ymax(box3d);
DROP FUNCTION public.st_y(geometry);
DROP FUNCTION public.st_xmin(box3d);
DROP FUNCTION public.st_xmax(box3d);
DROP FUNCTION public.st_x(geometry);
DROP FUNCTION public.st_wkttosql(text);
DROP FUNCTION public.st_wkbtosql(bytea);
DROP FUNCTION public.st_within(geometry, geometry);
DROP FUNCTION public.st_width(chip);
DROP FUNCTION public.st_unite_garray(geometry[]);
DROP FUNCTION public.st_union(geometry, geometry);
DROP FUNCTION public.st_transscale(geometry, double precision, double precision, double precision, double precision);
DROP FUNCTION public.st_translate(geometry, double precision, double precision);
DROP FUNCTION public.st_translate(geometry, double precision, double precision, double precision);
DROP FUNCTION public.st_transform(geometry, integer);
DROP FUNCTION public.st_touches(geometry, geometry);
DROP FUNCTION public.st_text(boolean);
DROP FUNCTION public.st_text(geometry);
DROP FUNCTION public.st_symmetricdifference(geometry, geometry);
DROP FUNCTION public.st_symdifference(geometry, geometry);
DROP FUNCTION public.st_summary(geometry);
DROP FUNCTION public.st_startpoint(geometry);
DROP FUNCTION public.st_srid(geometry);
DROP FUNCTION public.st_srid(chip);
DROP FUNCTION public.st_snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision);
DROP FUNCTION public.st_snaptogrid(geometry, double precision);
DROP FUNCTION public.st_snaptogrid(geometry, double precision, double precision);
DROP FUNCTION public.st_snaptogrid(geometry, double precision, double precision, double precision, double precision);
DROP FUNCTION public.st_simplify(geometry, double precision);
DROP FUNCTION public.st_shift_longitude(geometry);
DROP FUNCTION public.st_setsrid(geometry, integer);
DROP FUNCTION public.st_setpoint(geometry, integer, geometry);
DROP FUNCTION public.st_setfactor(chip, real);
DROP FUNCTION public.st_segmentize(geometry, double precision);
DROP FUNCTION public.st_scale(geometry, double precision, double precision);
DROP FUNCTION public.st_scale(geometry, double precision, double precision, double precision);
DROP FUNCTION public.st_rotatez(geometry, double precision);
DROP FUNCTION public.st_rotatey(geometry, double precision);
DROP FUNCTION public.st_rotatex(geometry, double precision);
DROP FUNCTION public.st_rotate(geometry, double precision);
DROP FUNCTION public.st_reverse(geometry);
DROP FUNCTION public.st_removepoint(geometry, integer);
DROP FUNCTION public.st_relate(geometry, geometry, text);
DROP FUNCTION public.st_relate(geometry, geometry);
DROP FUNCTION public.st_postgis_gist_sel(internal, oid, internal, integer);
DROP FUNCTION public.st_postgis_gist_joinsel(internal, oid, internal, smallint);
DROP FUNCTION public.st_polygonize_garray(geometry[]);
DROP FUNCTION public.st_polygonfromwkb(bytea);
DROP FUNCTION public.st_polygonfromwkb(bytea, integer);
DROP FUNCTION public.st_polygonfromtext(text);
DROP FUNCTION public.st_polygonfromtext(text, integer);
DROP FUNCTION public.st_polygon(geometry, integer);
DROP FUNCTION public.st_polyfromwkb(bytea);
DROP FUNCTION public.st_polyfromwkb(bytea, integer);
DROP FUNCTION public.st_polyfromtext(text, integer);
DROP FUNCTION public.st_polyfromtext(text);
DROP FUNCTION public.st_pointonsurface(geometry);
DROP FUNCTION public.st_pointn(geometry, integer);
DROP FUNCTION public.st_pointfromwkb(bytea);
DROP FUNCTION public.st_pointfromwkb(bytea, integer);
DROP FUNCTION public.st_pointfromtext(text, integer);
DROP FUNCTION public.st_pointfromtext(text);
DROP FUNCTION public.st_point_inside_circle(geometry, double precision, double precision, double precision);
DROP FUNCTION public.st_point(double precision, double precision);
DROP FUNCTION public.st_perimeter3d(geometry);
DROP FUNCTION public.st_perimeter2d(geometry);
DROP FUNCTION public.st_perimeter(geometry);
DROP FUNCTION public.st_overlaps(geometry, geometry);
DROP FUNCTION public.st_orderingequals(geometry, geometry);
DROP FUNCTION public.st_numpoints(geometry);
DROP FUNCTION public.st_numinteriorrings(geometry);
DROP FUNCTION public.st_numinteriorring(geometry);
DROP FUNCTION public.st_numgeometries(geometry);
DROP FUNCTION public.st_nrings(geometry);
DROP FUNCTION public.st_npoints(geometry);
DROP FUNCTION public.st_noop(geometry);
DROP FUNCTION public.st_ndims(geometry);
DROP FUNCTION public.st_multipolygonfromtext(text);
DROP FUNCTION public.st_multipolygonfromtext(text, integer);
DROP FUNCTION public.st_multipolyfromwkb(bytea);
DROP FUNCTION public.st_multipolyfromwkb(bytea, integer);
DROP FUNCTION public.st_multipointfromwkb(bytea);
DROP FUNCTION public.st_multipointfromwkb(bytea, integer);
DROP FUNCTION public.st_multipointfromtext(text);
DROP FUNCTION public.st_multilinestringfromtext(text, integer);
DROP FUNCTION public.st_multilinestringfromtext(text);
DROP FUNCTION public.st_multilinefromwkb(bytea);
DROP FUNCTION public.st_multi(geometry);
DROP FUNCTION public.st_mpolyfromwkb(bytea);
DROP FUNCTION public.st_mpolyfromwkb(bytea, integer);
DROP FUNCTION public.st_mpolyfromtext(text);
DROP FUNCTION public.st_mpolyfromtext(text, integer);
DROP FUNCTION public.st_mpointfromwkb(bytea);
DROP FUNCTION public.st_mpointfromwkb(bytea, integer);
DROP FUNCTION public.st_mpointfromtext(text);
DROP FUNCTION public.st_mpointfromtext(text, integer);
DROP FUNCTION public.st_mlinefromwkb(bytea);
DROP FUNCTION public.st_mlinefromwkb(bytea, integer);
DROP FUNCTION public.st_mlinefromtext(text);
DROP FUNCTION public.st_mlinefromtext(text, integer);
DROP FUNCTION public.st_mem_size(geometry);
DROP FUNCTION public.st_max_distance(geometry, geometry);
DROP FUNCTION public.st_makepolygon(geometry);
DROP FUNCTION public.st_makepolygon(geometry, geometry[]);
DROP FUNCTION public.st_makepoint(double precision, double precision, double precision, double precision);
DROP FUNCTION public.st_makepoint(double precision, double precision, double precision);
DROP FUNCTION public.st_makepoint(double precision, double precision);
DROP FUNCTION public.st_makeline_garray(geometry[]);
DROP FUNCTION public.st_makeline(geometry, geometry);
DROP FUNCTION public.st_makebox3d(geometry, geometry);
DROP FUNCTION public.st_makebox2d(geometry, geometry);
DROP FUNCTION public.st_m(geometry);
DROP FUNCTION public.st_locate_between_measures(geometry, double precision, double precision);
DROP FUNCTION public.st_locate_along_measure(geometry, double precision);
DROP FUNCTION public.st_linetocurve(geometry);
DROP FUNCTION public.st_linestringfromwkb(bytea);
DROP FUNCTION public.st_linestringfromwkb(bytea, integer);
DROP FUNCTION public.st_linemerge(geometry);
DROP FUNCTION public.st_linefromwkb(bytea);
DROP FUNCTION public.st_linefromwkb(bytea, integer);
DROP FUNCTION public.st_linefromtext(text, integer);
DROP FUNCTION public.st_linefromtext(text);
DROP FUNCTION public.st_linefrommultipoint(geometry);
DROP FUNCTION public.st_line_substring(geometry, double precision, double precision);
DROP FUNCTION public.st_line_locate_point(geometry, geometry);
DROP FUNCTION public.st_line_interpolate_point(geometry, double precision);
DROP FUNCTION public.st_length_spheroid(geometry, spheroid);
DROP FUNCTION public.st_length3d_spheroid(geometry, spheroid);
DROP FUNCTION public.st_length3d(geometry);
DROP FUNCTION public.st_length2d_spheroid(geometry, spheroid);
DROP FUNCTION public.st_length2d(geometry);
DROP FUNCTION public.st_length(geometry);
DROP FUNCTION public.st_isvalid(geometry);
DROP FUNCTION public.st_issimple(geometry);
DROP FUNCTION public.st_isring(geometry);
DROP FUNCTION public.st_isempty(geometry);
DROP FUNCTION public.st_isclosed(geometry);
DROP FUNCTION public.st_intersects(geometry, geometry);
DROP FUNCTION public.st_intersection(geometry, geometry);
DROP FUNCTION public.st_interiorringn(geometry, integer);
DROP FUNCTION public.st_height(chip);
DROP FUNCTION public.st_hasbbox(geometry);
DROP FUNCTION public.st_hasarc(geometry);
DROP FUNCTION public.st_geomfromwkb(bytea, integer);
DROP FUNCTION public.st_geomfromwkb(bytea);
DROP FUNCTION public.st_geomfromtext(text, integer);
DROP FUNCTION public.st_geomfromtext(text);
DROP FUNCTION public.st_geomfromewkt(text);
DROP FUNCTION public.st_geomfromewkb(bytea);
DROP FUNCTION public.st_geometrytype(geometry);
DROP FUNCTION public.st_geometryn(geometry, integer);
DROP FUNCTION public.st_geometryfromtext(text, integer);
DROP FUNCTION public.st_geometryfromtext(text);
DROP FUNCTION public.st_geometry_same(geometry, geometry);
DROP FUNCTION public.st_geometry_right(geometry, geometry);
DROP FUNCTION public.st_geometry_overright(geometry, geometry);
DROP FUNCTION public.st_geometry_overleft(geometry, geometry);
DROP FUNCTION public.st_geometry_overlap(geometry, geometry);
DROP FUNCTION public.st_geometry_overbelow(geometry, geometry);
DROP FUNCTION public.st_geometry_overabove(geometry, geometry);
DROP FUNCTION public.st_geometry_lt(geometry, geometry);
DROP FUNCTION public.st_geometry_left(geometry, geometry);
DROP FUNCTION public.st_geometry_le(geometry, geometry);
DROP FUNCTION public.st_geometry_gt(geometry, geometry);
DROP FUNCTION public.st_geometry_ge(geometry, geometry);
DROP FUNCTION public.st_geometry_eq(geometry, geometry);
DROP FUNCTION public.st_geometry_contained(geometry, geometry);
DROP FUNCTION public.st_geometry_contain(geometry, geometry);
DROP FUNCTION public.st_geometry_cmp(geometry, geometry);
DROP FUNCTION public.st_geometry_below(geometry, geometry);
DROP FUNCTION public.st_geometry_above(geometry, geometry);
DROP FUNCTION public.st_geometry(bytea);
DROP FUNCTION public.st_geometry(chip);
DROP FUNCTION public.st_geometry(text);
DROP FUNCTION public.st_geometry(box3d);
DROP FUNCTION public.st_geometry(box2d);
DROP FUNCTION public.st_geomcollfromwkb(bytea);
DROP FUNCTION public.st_geomcollfromwkb(bytea, integer);
DROP FUNCTION public.st_geomcollfromtext(text);
DROP FUNCTION public.st_geomcollfromtext(text, integer);
DROP FUNCTION public.st_geom_accum(geometry[], geometry);
DROP FUNCTION public.st_forcerhr(geometry);
DROP FUNCTION public.st_force_collection(geometry);
DROP FUNCTION public.st_force_4d(geometry);
DROP FUNCTION public.st_force_3dz(geometry);
DROP FUNCTION public.st_force_3dm(geometry);
DROP FUNCTION public.st_force_3d(geometry);
DROP FUNCTION public.st_force_2d(geometry);
DROP FUNCTION public.st_find_extent(text, text);
DROP FUNCTION public.st_find_extent(text, text, text);
DROP FUNCTION public.st_factor(chip);
DROP FUNCTION public.st_exteriorring(geometry);
DROP FUNCTION public.st_explode_histogram2d(histogram2d, text);
DROP FUNCTION public.st_expand(geometry, double precision);
DROP FUNCTION public.st_expand(box2d, double precision);
DROP FUNCTION public.st_expand(box3d, double precision);
DROP FUNCTION public.st_estimated_extent(text, text);
DROP FUNCTION public.st_estimated_extent(text, text, text);
DROP FUNCTION public.st_estimate_histogram2d(histogram2d, box2d);
DROP FUNCTION public.st_equals(geometry, geometry);
DROP FUNCTION public.st_envelope(geometry);
DROP FUNCTION public.st_endpoint(geometry);
DROP FUNCTION public.st_dwithin(geometry, geometry, double precision);
DROP FUNCTION public.st_dumprings(geometry);
DROP FUNCTION public.st_dump(geometry);
DROP FUNCTION public.st_dropbbox(geometry);
DROP FUNCTION public.st_distance_spheroid(geometry, geometry, spheroid);
DROP FUNCTION public.st_distance_sphere(geometry, geometry);
DROP FUNCTION public.st_distance(geometry, geometry);
DROP FUNCTION public.st_disjoint(geometry, geometry);
DROP FUNCTION public.st_dimension(geometry);
DROP FUNCTION public.st_difference(geometry, geometry);
DROP FUNCTION public.st_datatype(chip);
DROP FUNCTION public.st_curvetoline(geometry);
DROP FUNCTION public.st_curvetoline(geometry, integer);
DROP FUNCTION public.st_crosses(geometry, geometry);
DROP FUNCTION public.st_create_histogram2d(box2d, integer);
DROP FUNCTION public.st_covers(geometry, geometry);
DROP FUNCTION public.st_coveredby(geometry, geometry);
DROP FUNCTION public.st_coorddim(geometry);
DROP FUNCTION public.st_convexhull(geometry);
DROP FUNCTION public.st_contains(geometry, geometry);
DROP FUNCTION public.st_compression(chip);
DROP FUNCTION public.st_combine_bbox(box3d, geometry);
DROP FUNCTION public.st_combine_bbox(box2d, geometry);
DROP FUNCTION public.st_collector(geometry, geometry);
DROP FUNCTION public.st_collect_garray(geometry[]);
DROP FUNCTION public.st_collect(geometry, geometry);
DROP FUNCTION public.st_centroid(geometry);
DROP FUNCTION public.st_cache_bbox();
DROP FUNCTION public.st_bytea(geometry);
DROP FUNCTION public.st_buildarea(geometry);
DROP FUNCTION public.st_build_histogram2d(histogram2d, text, text, text);
DROP FUNCTION public.st_build_histogram2d(histogram2d, text, text);
DROP FUNCTION public.st_buffer(geometry, double precision, integer);
DROP FUNCTION public.st_buffer(geometry, double precision);
DROP FUNCTION public.st_box3d(box2d);
DROP FUNCTION public.st_box3d(geometry);
DROP FUNCTION public.st_box2d_same(box2d, box2d);
DROP FUNCTION public.st_box2d_right(box2d, box2d);
DROP FUNCTION public.st_box2d_overright(box2d, box2d);
DROP FUNCTION public.st_box2d_overleft(box2d, box2d);
DROP FUNCTION public.st_box2d_overlap(box2d, box2d);
DROP FUNCTION public.st_box2d_left(box2d, box2d);
DROP FUNCTION public.st_box2d_intersects(box2d, box2d);
DROP FUNCTION public.st_box2d_contained(box2d, box2d);
DROP FUNCTION public.st_box2d_contain(box2d, box2d);
DROP FUNCTION public.st_box2d(box3d);
DROP FUNCTION public.st_box2d(geometry);
DROP FUNCTION public.st_box(box3d);
DROP FUNCTION public.st_box(geometry);
DROP FUNCTION public.st_boundary(geometry);
DROP FUNCTION public.st_bdpolyfromtext(text, integer);
DROP FUNCTION public.st_bdmpolyfromtext(text, integer);
DROP FUNCTION public.st_azimuth(geometry, geometry);
DROP FUNCTION public.st_asukml(geometry);
DROP FUNCTION public.st_asukml(geometry, integer);
DROP FUNCTION public.st_asukml(geometry, integer, integer);
DROP FUNCTION public.st_astext(geometry);
DROP FUNCTION public.st_assvg(geometry);
DROP FUNCTION public.st_assvg(geometry, integer);
DROP FUNCTION public.st_assvg(geometry, integer, integer);
DROP FUNCTION public.st_askml(geometry);
DROP FUNCTION public.st_askml(geometry, integer);
DROP FUNCTION public.st_askml(geometry, integer, integer);
DROP FUNCTION public.st_ashexewkb(geometry, text);
DROP FUNCTION public.st_ashexewkb(geometry);
DROP FUNCTION public.st_asgml(integer, geometry, integer);
DROP FUNCTION public.st_asgml(integer, geometry);
DROP FUNCTION public.st_asgml(geometry);
DROP FUNCTION public.st_asgml(geometry, integer);
DROP FUNCTION public.st_asewkt(geometry);
DROP FUNCTION public.st_asewkb(geometry, text);
DROP FUNCTION public.st_asewkb(geometry);
DROP FUNCTION public.st_asbinary(geometry, text);
DROP FUNCTION public.st_asbinary(geometry);
DROP FUNCTION public.st_area2d(geometry);
DROP FUNCTION public.st_area(geometry);
DROP FUNCTION public.st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision);
DROP FUNCTION public.st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision);
DROP FUNCTION public.st_addpoint(geometry, geometry, integer);
DROP FUNCTION public.st_addpoint(geometry, geometry);
DROP FUNCTION public.st_addbbox(geometry);
DROP FUNCTION public.srid(geometry);
DROP FUNCTION public.srid(chip);
DROP FUNCTION public.spheroid_out(spheroid);
DROP FUNCTION public.spheroid_in(cstring);
DROP FUNCTION public.snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision);
DROP FUNCTION public.snaptogrid(geometry, double precision);
DROP FUNCTION public.snaptogrid(geometry, double precision, double precision);
DROP FUNCTION public.snaptogrid(geometry, double precision, double precision, double precision, double precision);
DROP FUNCTION public.simplify(geometry, double precision);
DROP FUNCTION public.shift_longitude(geometry);
DROP FUNCTION public.setsrid(geometry, integer);
DROP FUNCTION public.setsrid(chip, integer);
DROP FUNCTION public.setpoint(geometry, integer, geometry);
DROP FUNCTION public.setfactor(chip, real);
DROP FUNCTION public.segmentize(geometry, double precision);
DROP FUNCTION public.se_z(geometry);
DROP FUNCTION public.se_m(geometry);
DROP FUNCTION public.se_locatebetween(geometry, double precision, double precision);
DROP FUNCTION public.se_locatealong(geometry, double precision);
DROP FUNCTION public.se_ismeasured(geometry);
DROP FUNCTION public.se_is3d(geometry);
DROP FUNCTION public.se_envelopesintersect(geometry, geometry);
DROP FUNCTION public.scale(geometry, double precision, double precision);
DROP FUNCTION public.scale(geometry, double precision, double precision, double precision);
DROP FUNCTION public.rotatez(geometry, double precision);
DROP FUNCTION public.rotatey(geometry, double precision);
DROP FUNCTION public.rotatex(geometry, double precision);
DROP FUNCTION public.rotate(geometry, double precision);
DROP FUNCTION public.reverse(geometry);
DROP FUNCTION public.rename_geometry_table_constraints();
DROP FUNCTION public.removepoint(geometry, integer);
DROP FUNCTION public.relate(geometry, geometry, text);
DROP FUNCTION public.relate(geometry, geometry);
DROP FUNCTION public.probe_geometry_columns();
DROP FUNCTION public.postgis_version();
DROP FUNCTION public.postgis_uses_stats();
DROP FUNCTION public.postgis_scripts_released();
DROP FUNCTION public.postgis_scripts_installed();
DROP FUNCTION public.postgis_scripts_build_date();
DROP FUNCTION public.postgis_proj_version();
DROP FUNCTION public.postgis_lib_version();
DROP FUNCTION public.postgis_lib_build_date();
DROP FUNCTION public.postgis_jts_version();
DROP FUNCTION public.postgis_gist_sel(internal, oid, internal, integer);
DROP FUNCTION public.postgis_gist_joinsel(internal, oid, internal, smallint);
DROP FUNCTION public.postgis_geos_version();
DROP FUNCTION public.postgis_full_version();
DROP FUNCTION public.polygonize_garray(geometry[]);
DROP FUNCTION public.polygonfromwkb(bytea);
DROP FUNCTION public.polygonfromwkb(bytea, integer);
DROP FUNCTION public.polygonfromtext(text);
DROP FUNCTION public.polygonfromtext(text, integer);
DROP FUNCTION public.polyfromwkb(bytea);
DROP FUNCTION public.polyfromwkb(bytea, integer);
DROP FUNCTION public.polyfromtext(text, integer);
DROP FUNCTION public.polyfromtext(text);
DROP FUNCTION public.pointonsurface(geometry);
DROP FUNCTION public.pointn(geometry, integer);
DROP FUNCTION public.pointfromwkb(bytea);
DROP FUNCTION public.pointfromwkb(bytea, integer);
DROP FUNCTION public.pointfromtext(text, integer);
DROP FUNCTION public.pointfromtext(text);
DROP FUNCTION public.point_inside_circle(geometry, double precision, double precision, double precision);
DROP FUNCTION public.perimeter3d(geometry);
DROP FUNCTION public.perimeter2d(geometry);
DROP FUNCTION public.perimeter(geometry);
DROP FUNCTION public."overlaps"(geometry, geometry);
DROP FUNCTION public.numpoints(geometry);
DROP FUNCTION public.numinteriorrings(geometry);
DROP FUNCTION public.numinteriorring(geometry);
DROP FUNCTION public.numgeometries(geometry);
DROP FUNCTION public.nrings(geometry);
DROP FUNCTION public.npoints(geometry);
DROP FUNCTION public.noop(geometry);
DROP FUNCTION public.ndims(geometry);
DROP FUNCTION public.multipolygonfromtext(text);
DROP FUNCTION public.multipolygonfromtext(text, integer);
DROP FUNCTION public.multipolyfromwkb(bytea);
DROP FUNCTION public.multipolyfromwkb(bytea, integer);
DROP FUNCTION public.multipointfromwkb(bytea);
DROP FUNCTION public.multipointfromwkb(bytea, integer);
DROP FUNCTION public.multipointfromtext(text);
DROP FUNCTION public.multipointfromtext(text, integer);
DROP FUNCTION public.multilinestringfromtext(text, integer);
DROP FUNCTION public.multilinestringfromtext(text);
DROP FUNCTION public.multilinefromwkb(bytea);
DROP FUNCTION public.multilinefromwkb(bytea, integer);
DROP FUNCTION public.multi(geometry);
DROP FUNCTION public.mpolyfromwkb(bytea);
DROP FUNCTION public.mpolyfromwkb(bytea, integer);
DROP FUNCTION public.mpolyfromtext(text);
DROP FUNCTION public.mpolyfromtext(text, integer);
DROP FUNCTION public.mpointfromwkb(bytea);
DROP FUNCTION public.mpointfromwkb(bytea, integer);
DROP FUNCTION public.mpointfromtext(text);
DROP FUNCTION public.mpointfromtext(text, integer);
DROP FUNCTION public.mlinefromwkb(bytea);
DROP FUNCTION public.mlinefromwkb(bytea, integer);
DROP FUNCTION public.mlinefromtext(text);
DROP FUNCTION public.mlinefromtext(text, integer);
DROP FUNCTION public.mem_size(geometry);
DROP FUNCTION public.max_distance(geometry, geometry);
DROP FUNCTION public.makepolygon(geometry);
DROP FUNCTION public.makepolygon(geometry, geometry[]);
DROP FUNCTION public.makepointm(double precision, double precision, double precision);
DROP FUNCTION public.makepoint(double precision, double precision, double precision, double precision);
DROP FUNCTION public.makepoint(double precision, double precision, double precision);
DROP FUNCTION public.makepoint(double precision, double precision);
DROP FUNCTION public.makeline_garray(geometry[]);
DROP FUNCTION public.makeline(geometry, geometry);
DROP FUNCTION public.makebox3d(geometry, geometry);
DROP FUNCTION public.makebox2d(geometry, geometry);
DROP FUNCTION public.m(geometry);
DROP FUNCTION public.lwgeom_gist_union(bytea, internal);
DROP FUNCTION public.lwgeom_gist_same(box2d, box2d, internal);
DROP FUNCTION public.lwgeom_gist_picksplit(internal, internal);
DROP FUNCTION public.lwgeom_gist_penalty(internal, internal, internal);
DROP FUNCTION public.lwgeom_gist_decompress(internal);
DROP FUNCTION public.lwgeom_gist_consistent(internal, geometry, integer);
DROP FUNCTION public.lwgeom_gist_compress(internal);
DROP FUNCTION public.longtransactionsenabled();
DROP FUNCTION public.lockrow(text, text, text, timestamp without time zone);
DROP FUNCTION public.lockrow(text, text, text);
DROP FUNCTION public.lockrow(text, text, text, text);
DROP FUNCTION public.lockrow(text, text, text, text, timestamp without time zone);
DROP FUNCTION public.locate_between_measures(geometry, double precision, double precision);
DROP FUNCTION public.locate_along_measure(geometry, double precision);
DROP FUNCTION public.linestringfromwkb(bytea);
DROP FUNCTION public.linestringfromwkb(bytea, integer);
DROP FUNCTION public.linestringfromtext(text, integer);
DROP FUNCTION public.linestringfromtext(text);
DROP FUNCTION public.linemerge(geometry);
DROP FUNCTION public.linefromwkb(bytea);
DROP FUNCTION public.linefromwkb(bytea, integer);
DROP FUNCTION public.linefromtext(text, integer);
DROP FUNCTION public.linefromtext(text);
DROP FUNCTION public.linefrommultipoint(geometry);
DROP FUNCTION public.line_substring(geometry, double precision, double precision);
DROP FUNCTION public.line_locate_point(geometry, geometry);
DROP FUNCTION public.line_interpolate_point(geometry, double precision);
DROP FUNCTION public.length_spheroid(geometry, spheroid);
DROP FUNCTION public.length3d_spheroid(geometry, spheroid);
DROP FUNCTION public.length3d(geometry);
DROP FUNCTION public.length2d_spheroid(geometry, spheroid);
DROP FUNCTION public.length2d(geometry);
DROP FUNCTION public.length(geometry);
DROP FUNCTION public.jtsnoop(geometry);
DROP FUNCTION public.isvalid(geometry);
DROP FUNCTION public.issimple(geometry);
DROP FUNCTION public.isring(geometry);
DROP FUNCTION public.isempty(geometry);
DROP FUNCTION public.isclosed(geometry);
DROP FUNCTION public.intersects(geometry, geometry);
DROP FUNCTION public.intersection(geometry, geometry);
DROP FUNCTION public.interiorringn(geometry, integer);
DROP FUNCTION public.histogram2d_out(histogram2d);
DROP FUNCTION public.histogram2d_in(cstring);
DROP FUNCTION public.height(chip);
DROP FUNCTION public.hasbbox(geometry);
DROP FUNCTION public.gettransactionid();
DROP FUNCTION public.getsrid(geometry);
DROP FUNCTION public.getbbox(geometry);
DROP FUNCTION public.get_proj4_from_srid(integer);
DROP FUNCTION public.geosnoop(geometry);
DROP FUNCTION public.geomunion(geometry, geometry);
DROP FUNCTION public.geomfromwkb(bytea, integer);
DROP FUNCTION public.geomfromwkb(bytea);
DROP FUNCTION public.geomfromtext(text, integer);
DROP FUNCTION public.geomfromtext(text);
DROP FUNCTION public.geomfromewkt(text);
DROP FUNCTION public.geomfromewkb(bytea);
DROP FUNCTION public.geometrytype(geometry);
DROP FUNCTION public.geometryn(geometry, integer);
DROP FUNCTION public.geometryfromtext(text, integer);
DROP FUNCTION public.geometryfromtext(text);
DROP FUNCTION public.geometry_send(geometry);
DROP FUNCTION public.geometry_same(geometry, geometry);
DROP FUNCTION public.geometry_right(geometry, geometry);
DROP FUNCTION public.geometry_recv(internal);
DROP FUNCTION public.geometry_overright(geometry, geometry);
DROP FUNCTION public.geometry_overleft(geometry, geometry);
DROP FUNCTION public.geometry_overlap(geometry, geometry);
DROP FUNCTION public.geometry_overbelow(geometry, geometry);
DROP FUNCTION public.geometry_overabove(geometry, geometry);
DROP FUNCTION public.geometry_out(geometry);
DROP FUNCTION public.geometry_lt(geometry, geometry);
DROP FUNCTION public.geometry_left(geometry, geometry);
DROP FUNCTION public.geometry_le(geometry, geometry);
DROP FUNCTION public.geometry_in(cstring);
DROP FUNCTION public.geometry_gt(geometry, geometry);
DROP FUNCTION public.geometry_ge(geometry, geometry);
DROP FUNCTION public.geometry_eq(geometry, geometry);
DROP FUNCTION public.geometry_contained(geometry, geometry);
DROP FUNCTION public.geometry_contain(geometry, geometry);
DROP FUNCTION public.geometry_cmp(geometry, geometry);
DROP FUNCTION public.geometry_below(geometry, geometry);
DROP FUNCTION public.geometry_analyze(internal);
DROP FUNCTION public.geometry_above(geometry, geometry);
DROP FUNCTION public.geometry(bytea);
DROP FUNCTION public.geometry(chip);
DROP FUNCTION public.geometry(text);
DROP FUNCTION public.geometry(box3d);
DROP FUNCTION public.geometry(box2d);
DROP FUNCTION public.geomcollfromwkb(bytea);
DROP FUNCTION public.geomcollfromwkb(bytea, integer);
DROP FUNCTION public.geomcollfromtext(text);
DROP FUNCTION public.geomcollfromtext(text, integer);
DROP FUNCTION public.geom_accum(geometry[], geometry);
DROP FUNCTION public.forcerhr(geometry);
DROP FUNCTION public.force_collection(geometry);
DROP FUNCTION public.force_4d(geometry);
DROP FUNCTION public.force_3dz(geometry);
DROP FUNCTION public.force_3dm(geometry);
DROP FUNCTION public.force_3d(geometry);
DROP FUNCTION public.force_2d(geometry);
DROP FUNCTION public.fix_geometry_columns();
DROP FUNCTION public.find_srid(character varying, character varying, character varying);
DROP FUNCTION public.find_extent(text, text);
DROP FUNCTION public.find_extent(text, text, text);
DROP FUNCTION public.factor(chip);
DROP FUNCTION public.exteriorring(geometry);
DROP FUNCTION public.explode_histogram2d(histogram2d, text);
DROP FUNCTION public.expand(geometry, double precision);
DROP FUNCTION public.expand(box2d, double precision);
DROP FUNCTION public.expand(box3d, double precision);
DROP FUNCTION public.estimated_extent(text, text);
DROP FUNCTION public.estimated_extent(text, text, text);
DROP FUNCTION public.estimate_histogram2d(histogram2d, box2d);
DROP FUNCTION public.equals(geometry, geometry);
DROP FUNCTION public.envelope(geometry);
DROP FUNCTION public.endpoint(geometry);
DROP FUNCTION public.enablelongtransactions();
DROP FUNCTION public.dumprings(geometry);
DROP FUNCTION public.dump(geometry);
DROP FUNCTION public.dropgeometrytable(character varying);
DROP FUNCTION public.dropgeometrytable(character varying, character varying);
DROP FUNCTION public.dropgeometrytable(character varying, character varying, character varying);
DROP FUNCTION public.dropgeometrycolumn(character varying, character varying);
DROP FUNCTION public.dropgeometrycolumn(character varying, character varying, character varying);
DROP FUNCTION public.dropgeometrycolumn(character varying, character varying, character varying, character varying);
DROP FUNCTION public.dropbbox(geometry);
DROP FUNCTION public.distance_spheroid(geometry, geometry, spheroid);
DROP FUNCTION public.distance_sphere(geometry, geometry);
DROP FUNCTION public.distance(geometry, geometry);
DROP FUNCTION public.disjoint(geometry, geometry);
DROP FUNCTION public.disablelongtransactions();
DROP FUNCTION public.dimension(geometry);
DROP FUNCTION public.difference(geometry, geometry);
DROP FUNCTION public.datatype(chip);
DROP FUNCTION public.crosses(geometry, geometry);
DROP FUNCTION public.create_histogram2d(box2d, integer);
DROP FUNCTION public.convexhull(geometry);
DROP FUNCTION public.contains(geometry, geometry);
DROP FUNCTION public.compression(chip);
DROP FUNCTION public.combine_bbox(box3d, geometry);
DROP FUNCTION public.combine_bbox(box2d, geometry);
DROP FUNCTION public.collector(geometry, geometry);
DROP FUNCTION public.collect_garray(geometry[]);
DROP FUNCTION public.collect(geometry, geometry);
DROP FUNCTION public.chip_out(chip);
DROP FUNCTION public.chip_in(cstring);
DROP FUNCTION public.checkauthtrigger();
DROP FUNCTION public.checkauth(text, text);
DROP FUNCTION public.checkauth(text, text, text);
DROP FUNCTION public.centroid(geometry);
DROP FUNCTION public.cache_bbox();
DROP FUNCTION public.bytea(geometry);
DROP FUNCTION public.buildarea(geometry);
DROP FUNCTION public.build_histogram2d(histogram2d, text, text, text);
DROP FUNCTION public.build_histogram2d(histogram2d, text, text);
DROP FUNCTION public.buffer(geometry, double precision, integer);
DROP FUNCTION public.buffer(geometry, double precision);
DROP FUNCTION public.box3dtobox(box3d);
DROP FUNCTION public.box3d_out(box3d);
DROP FUNCTION public.box3d_in(cstring);
DROP FUNCTION public.box3d(box2d);
DROP FUNCTION public.box3d(geometry);
DROP FUNCTION public.box2d_same(box2d, box2d);
DROP FUNCTION public.box2d_right(box2d, box2d);
DROP FUNCTION public.box2d_overright(box2d, box2d);
DROP FUNCTION public.box2d_overleft(box2d, box2d);
DROP FUNCTION public.box2d_overlap(box2d, box2d);
DROP FUNCTION public.box2d_out(box2d);
DROP FUNCTION public.box2d_left(box2d, box2d);
DROP FUNCTION public.box2d_intersects(box2d, box2d);
DROP FUNCTION public.box2d_in(cstring);
DROP FUNCTION public.box2d_contained(box2d, box2d);
DROP FUNCTION public.box2d_contain(box2d, box2d);
DROP FUNCTION public.box2d(box3d);
DROP FUNCTION public.box2d(geometry);
DROP FUNCTION public.box(box3d);
DROP FUNCTION public.box(geometry);
DROP FUNCTION public.boundary(geometry);
DROP FUNCTION public.bdpolyfromtext(text, integer);
DROP FUNCTION public.bdmpolyfromtext(text, integer);
DROP FUNCTION public.azimuth(geometry, geometry);
DROP FUNCTION public.asukml(geometry);
DROP FUNCTION public.asukml(geometry, integer);
DROP FUNCTION public.asukml(geometry, integer, integer);
DROP FUNCTION public.astext(geometry);
DROP FUNCTION public.assvg(geometry);
DROP FUNCTION public.assvg(geometry, integer);
DROP FUNCTION public.assvg(geometry, integer, integer);
DROP FUNCTION public.askml(geometry);
DROP FUNCTION public.askml(geometry, integer);
DROP FUNCTION public.askml(geometry, integer, integer);
DROP FUNCTION public.ashexewkb(geometry, text);
DROP FUNCTION public.ashexewkb(geometry);
DROP FUNCTION public.asgml(geometry);
DROP FUNCTION public.asgml(geometry, integer);
DROP FUNCTION public.asewkt(geometry);
DROP FUNCTION public.asewkb(geometry, text);
DROP FUNCTION public.asewkb(geometry);
DROP FUNCTION public.asbinary(geometry, text);
DROP FUNCTION public.asbinary(geometry);
DROP FUNCTION public.area2d(geometry);
DROP FUNCTION public.area(geometry);
DROP FUNCTION public.affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision);
DROP FUNCTION public.affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision);
DROP FUNCTION public.addpoint(geometry, geometry, integer);
DROP FUNCTION public.addpoint(geometry, geometry);
DROP FUNCTION public.addgeometrycolumn(character varying, character varying, integer, character varying, integer);
DROP FUNCTION public.addgeometrycolumn(character varying, character varying, character varying, integer, character varying, integer);
DROP FUNCTION public.addgeometrycolumn(character varying, character varying, character varying, character varying, integer, character varying, integer);
DROP FUNCTION public.addbbox(geometry);
DROP FUNCTION public.addauth(text);
DROP FUNCTION public._st_within(geometry, geometry);
DROP FUNCTION public._st_touches(geometry, geometry);
DROP FUNCTION public._st_overlaps(geometry, geometry);
DROP FUNCTION public._st_intersects(geometry, geometry);
DROP FUNCTION public._st_crosses(geometry, geometry);
DROP FUNCTION public._st_covers(geometry, geometry);
DROP FUNCTION public._st_coveredby(geometry, geometry);
DROP FUNCTION public._st_contains(geometry, geometry);
DROP FUNCTION public._st_asgml(integer, geometry, integer);
DROP TYPE public.geometry_dump;
DROP TYPE public.spheroid CASCADE;
DROP FUNCTION public.st_spheroid_out(spheroid);
DROP FUNCTION public.st_spheroid_in(cstring);
DROP TYPE public.histogram2d CASCADE;
DROP FUNCTION public.st_histogram2d_out(histogram2d);
DROP FUNCTION public.st_histogram2d_in(cstring);
DROP TYPE public.geometry CASCADE;
DROP FUNCTION public.st_geometry_send(geometry);
DROP FUNCTION public.st_geometry_recv(internal);
DROP FUNCTION public.st_geometry_out(geometry);
DROP FUNCTION public.st_geometry_in(cstring);
DROP FUNCTION public.st_geometry_analyze(internal);
DROP TYPE public.chip CASCADE;
DROP FUNCTION public.st_chip_out(chip);
DROP FUNCTION public.st_chip_in(cstring);
DROP TYPE public.box3d CASCADE;
DROP FUNCTION public.st_box3d_out(box3d);
DROP FUNCTION public.st_box3d_in(cstring);
DROP TYPE public.box2d CASCADE;
DROP FUNCTION public.st_box2d_out(box2d);
DROP FUNCTION public.st_box2d_in(cstring);
DROP PROCEDURAL LANGUAGE plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


--
-- Name: plpgsql; Type: PROCEDURAL LANGUAGE; Schema: -; Owner: postgres
--

CREATE PROCEDURAL LANGUAGE plpgsql;


--
-- Name: box2d; Type: SHELL TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE box2d;


--
-- Name: st_box2d_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_in(cstring) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_in(cstring) OWNER TO ortelius;

--
-- Name: st_box2d_out(box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_out(box2d) RETURNS cstring
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_out(box2d) OWNER TO ortelius;

--
-- Name: box2d; Type: TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE box2d (
    INTERNALLENGTH = 16,
    INPUT = st_box2d_in,
    OUTPUT = st_box2d_out,
    ALIGNMENT = int4,
    STORAGE = plain
);


ALTER TYPE public.box2d OWNER TO ortelius;

--
-- Name: box3d; Type: SHELL TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE box3d;


--
-- Name: st_box3d_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box3d_in(cstring) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box3d_in(cstring) OWNER TO ortelius;

--
-- Name: st_box3d_out(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box3d_out(box3d) RETURNS cstring
    AS '$libdir/liblwgeom', 'BOX3D_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box3d_out(box3d) OWNER TO ortelius;

--
-- Name: box3d; Type: TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE box3d (
    INTERNALLENGTH = 48,
    INPUT = st_box3d_in,
    OUTPUT = st_box3d_out,
    ALIGNMENT = double,
    STORAGE = plain
);


ALTER TYPE public.box3d OWNER TO ortelius;

--
-- Name: chip; Type: SHELL TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE chip;


--
-- Name: st_chip_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_chip_in(cstring) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_chip_in(cstring) OWNER TO ortelius;

--
-- Name: st_chip_out(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_chip_out(chip) RETURNS cstring
    AS '$libdir/liblwgeom', 'CHIP_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_chip_out(chip) OWNER TO ortelius;

--
-- Name: chip; Type: TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE chip (
    INTERNALLENGTH = variable,
    INPUT = st_chip_in,
    OUTPUT = st_chip_out,
    ALIGNMENT = double,
    STORAGE = extended
);


ALTER TYPE public.chip OWNER TO ortelius;

--
-- Name: geometry; Type: SHELL TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE geometry;


--
-- Name: st_geometry_analyze(internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_analyze(internal) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_analyze'
    LANGUAGE c STRICT;


ALTER FUNCTION public.st_geometry_analyze(internal) OWNER TO ortelius;

--
-- Name: st_geometry_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_in(cstring) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_in(cstring) OWNER TO ortelius;

--
-- Name: st_geometry_out(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_out(geometry) RETURNS cstring
    AS '$libdir/liblwgeom', 'LWGEOM_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_out(geometry) OWNER TO ortelius;

--
-- Name: st_geometry_recv(internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_recv(internal) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_recv'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_recv(internal) OWNER TO ortelius;

--
-- Name: st_geometry_send(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_send(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_send'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_send(geometry) OWNER TO ortelius;

--
-- Name: geometry; Type: TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE geometry (
    INTERNALLENGTH = variable,
    INPUT = st_geometry_in,
    OUTPUT = st_geometry_out,
    RECEIVE = st_geometry_recv,
    SEND = st_geometry_send,
    ANALYZE = st_geometry_analyze,
    DELIMITER = ':',
    ALIGNMENT = int4,
    STORAGE = main
);


ALTER TYPE public.geometry OWNER TO ortelius;

--
-- Name: histogram2d; Type: SHELL TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE histogram2d;


--
-- Name: st_histogram2d_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_histogram2d_in(cstring) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'lwhistogram2d_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_histogram2d_in(cstring) OWNER TO ortelius;

--
-- Name: st_histogram2d_out(histogram2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_histogram2d_out(histogram2d) RETURNS cstring
    AS '$libdir/liblwgeom', 'lwhistogram2d_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_histogram2d_out(histogram2d) OWNER TO ortelius;

--
-- Name: histogram2d; Type: TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE histogram2d (
    INTERNALLENGTH = variable,
    INPUT = st_histogram2d_in,
    OUTPUT = st_histogram2d_out,
    ALIGNMENT = double,
    STORAGE = main
);


ALTER TYPE public.histogram2d OWNER TO ortelius;

--
-- Name: spheroid; Type: SHELL TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE spheroid;


--
-- Name: st_spheroid_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_spheroid_in(cstring) RETURNS spheroid
    AS '$libdir/liblwgeom', 'ellipsoid_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_spheroid_in(cstring) OWNER TO ortelius;

--
-- Name: st_spheroid_out(spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_spheroid_out(spheroid) RETURNS cstring
    AS '$libdir/liblwgeom', 'ellipsoid_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_spheroid_out(spheroid) OWNER TO ortelius;

--
-- Name: spheroid; Type: TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE spheroid (
    INTERNALLENGTH = 65,
    INPUT = st_spheroid_in,
    OUTPUT = st_spheroid_out,
    ALIGNMENT = double,
    STORAGE = plain
);


ALTER TYPE public.spheroid OWNER TO ortelius;

--
-- Name: geometry_dump; Type: TYPE; Schema: public; Owner: ortelius
--

CREATE TYPE geometry_dump AS (
	path integer[],
	geom geometry
);


ALTER TYPE public.geometry_dump OWNER TO ortelius;

--
-- Name: _st_asgml(integer, geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION _st_asgml(integer, geometry, integer) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asGML'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_asgml(integer, geometry, integer) OWNER TO ortelius;

--
-- Name: _st_contains(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION _st_contains(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'contains'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_contains(geometry, geometry) OWNER TO ortelius;

--
-- Name: _st_coveredby(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION _st_coveredby(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'coveredby'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_coveredby(geometry, geometry) OWNER TO ortelius;

--
-- Name: _st_covers(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION _st_covers(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'covers'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_covers(geometry, geometry) OWNER TO ortelius;

--
-- Name: _st_crosses(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION _st_crosses(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'crosses'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_crosses(geometry, geometry) OWNER TO ortelius;

--
-- Name: _st_intersects(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION _st_intersects(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'intersects'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_intersects(geometry, geometry) OWNER TO ortelius;

--
-- Name: _st_overlaps(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION _st_overlaps(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'overlaps'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_overlaps(geometry, geometry) OWNER TO ortelius;

--
-- Name: _st_touches(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION _st_touches(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'touches'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_touches(geometry, geometry) OWNER TO ortelius;

--
-- Name: _st_within(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION _st_within(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'within'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public._st_within(geometry, geometry) OWNER TO ortelius;

--
-- Name: addauth(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION addauth(text) RETURNS boolean
    AS $_$
DECLARE
	lockid alias for $1;
	okay boolean;
	myrec record;
BEGIN
	-- check to see if table exists
	--  if not, CREATE TEMP TABLE mylock (transid xid, lockcode text)
	okay := 'f';
	FOR myrec IN SELECT * FROM pg_class WHERE relname = 'temp_lock_have_table' LOOP
		okay := 't';
	END LOOP; 
	IF (okay <> 't') THEN 
		CREATE TEMP TABLE temp_lock_have_table (transid xid, lockcode text);
			-- this will only work from pgsql7.4 up
			-- ON COMMIT DELETE ROWS;
	END IF;

	--  INSERT INTO mylock VALUES ( $1)
--	EXECUTE 'INSERT INTO temp_lock_have_table VALUES ( '||
--		quote_literal(getTransactionID()) || ',' ||
--		quote_literal(lockid) ||')';

	INSERT INTO temp_lock_have_table VALUES (getTransactionID(), lockid);

	RETURN true::boolean;
END;
$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.addauth(text) OWNER TO ortelius;

--
-- Name: addbbox(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION addbbox(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.addbbox(geometry) OWNER TO ortelius;

--
-- Name: addgeometrycolumn(character varying, character varying, character varying, character varying, integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION addgeometrycolumn(character varying, character varying, character varying, character varying, integer, character varying, integer) RETURNS text
    AS $_$
DECLARE
	catalog_name alias for $1;
	schema_name alias for $2;
	table_name alias for $3;
	column_name alias for $4;
	new_srid alias for $5;
	new_type alias for $6;
	new_dim alias for $7;
	rec RECORD;
	schema_ok bool;
	real_schema name;

BEGIN

	IF ( not ( (new_type ='GEOMETRY') or
		   (new_type ='GEOMETRYCOLLECTION') or
		   (new_type ='POINT') or 
		   (new_type ='MULTIPOINT') or
		   (new_type ='POLYGON') or
		   (new_type ='MULTIPOLYGON') or
		   (new_type ='LINESTRING') or
		   (new_type ='MULTILINESTRING') or
		   (new_type ='GEOMETRYCOLLECTIONM') or
		   (new_type ='POINTM') or 
		   (new_type ='MULTIPOINTM') or
		   (new_type ='POLYGONM') or
		   (new_type ='MULTIPOLYGONM') or
		   (new_type ='LINESTRINGM') or
		   (new_type ='MULTILINESTRINGM') or
                   (new_type = 'CIRCULARSTRING') or
                   (new_type = 'CIRCULARSTRINGM') or
                   (new_type = 'COMPOUNDCURVE') or
                   (new_type = 'COMPOUNDCURVEM') or
                   (new_type = 'CURVEPOLYGON') or
                   (new_type = 'CURVEPOLYGONM') or
                   (new_type = 'MULTICURVE') or
                   (new_type = 'MULTICURVEM') or
                   (new_type = 'MULTISURFACE') or
                   (new_type = 'MULTISURFACEM')) )
	THEN
		RAISE EXCEPTION 'Invalid type name - valid ones are: 
			GEOMETRY, GEOMETRYCOLLECTION, POINT, 
			MULTIPOINT, POLYGON, MULTIPOLYGON, 
			LINESTRING, MULTILINESTRING,
                        CIRCULARSTRING, COMPOUNDCURVE,
                        CURVEPOLYGON, MULTICURVE, MULTISURFACE,
			GEOMETRYCOLLECTIONM, POINTM, 
			MULTIPOINTM, POLYGONM, MULTIPOLYGONM, 
			LINESTRINGM, MULTILINESTRINGM 
                        CIRCULARSTRINGM, COMPOUNDCURVEM,
                        CURVEPOLYGONM, MULTICURVEM or MULTISURFACEM';
		return 'fail';
	END IF;

	IF ( (new_dim >4) or (new_dim <0) ) THEN
		RAISE EXCEPTION 'invalid dimension';
		return 'fail';
	END IF;

	IF ( (new_type LIKE '%M') and (new_dim!=3) ) THEN

		RAISE EXCEPTION 'TypeM needs 3 dimensions';
		return 'fail';
	END IF;

	IF ( schema_name != '' ) THEN
		schema_ok = 'f';
		FOR rec IN SELECT nspname FROM pg_namespace WHERE text(nspname) = schema_name LOOP
			schema_ok := 't';
		END LOOP;

		if ( schema_ok <> 't' ) THEN
			RAISE NOTICE 'Invalid schema name - using current_schema()';
			SELECT current_schema() into real_schema;
		ELSE
			real_schema = schema_name;
		END IF;

	ELSE
		SELECT current_schema() into real_schema;
	END IF;


	-- Add geometry column

	EXECUTE 'ALTER TABLE ' ||
		quote_ident(real_schema) || '.' || quote_ident(table_name)
		|| ' ADD COLUMN ' || quote_ident(column_name) || 
		' geometry ';


	-- Delete stale record in geometry_column (if any)

	EXECUTE 'DELETE FROM geometry_columns WHERE
		f_table_catalog = ' || quote_literal('') || 
		' AND f_table_schema = ' ||
		quote_literal(real_schema) || 
		' AND f_table_name = ' || quote_literal(table_name) ||
		' AND f_geometry_column = ' || quote_literal(column_name);


	-- Add record in geometry_column 

	EXECUTE 'INSERT INTO geometry_columns VALUES (' ||
		quote_literal('') || ',' ||
		quote_literal(real_schema) || ',' ||
		quote_literal(table_name) || ',' ||
		quote_literal(column_name) || ',' ||
		new_dim::text || ',' || new_srid::text || ',' ||
		quote_literal(new_type) || ')';

	-- Add table checks

	EXECUTE 'ALTER TABLE ' || 
		quote_ident(real_schema) || '.' || quote_ident(table_name)
		|| ' ADD CONSTRAINT ' 
		|| quote_ident('enforce_srid_' || column_name)
		|| ' CHECK (SRID(' || quote_ident(column_name) ||
		') = ' || new_srid::text || ')' ;

	EXECUTE 'ALTER TABLE ' || 
		quote_ident(real_schema) || '.' || quote_ident(table_name)
		|| ' ADD CONSTRAINT '
		|| quote_ident('enforce_dims_' || column_name)
		|| ' CHECK (ndims(' || quote_ident(column_name) ||
		') = ' || new_dim::text || ')' ;

	IF (not(new_type = 'GEOMETRY')) THEN
		EXECUTE 'ALTER TABLE ' || 
		quote_ident(real_schema) || '.' || quote_ident(table_name)
		|| ' ADD CONSTRAINT '
		|| quote_ident('enforce_geotype_' || column_name)
		|| ' CHECK (geometrytype(' ||
		quote_ident(column_name) || ')=' ||
		quote_literal(new_type) || ' OR (' ||
		quote_ident(column_name) || ') is null)';
	END IF;

	return 
		real_schema || '.' || 
		table_name || '.' || column_name ||
		' SRID:' || new_srid::text ||
		' TYPE:' || new_type || 
		' DIMS:' || new_dim::text || chr(10) || ' '; 
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.addgeometrycolumn(character varying, character varying, character varying, character varying, integer, character varying, integer) OWNER TO ortelius;

--
-- Name: addgeometrycolumn(character varying, character varying, character varying, integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION addgeometrycolumn(character varying, character varying, character varying, integer, character varying, integer) RETURNS text
    AS $_$
DECLARE
	ret  text;
BEGIN
	SELECT AddGeometryColumn('',$1,$2,$3,$4,$5,$6) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STABLE STRICT;


ALTER FUNCTION public.addgeometrycolumn(character varying, character varying, character varying, integer, character varying, integer) OWNER TO ortelius;

--
-- Name: addgeometrycolumn(character varying, character varying, integer, character varying, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION addgeometrycolumn(character varying, character varying, integer, character varying, integer) RETURNS text
    AS $_$
DECLARE
	ret  text;
BEGIN
	SELECT AddGeometryColumn('','',$1,$2,$3,$4,$5) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.addgeometrycolumn(character varying, character varying, integer, character varying, integer) OWNER TO ortelius;

--
-- Name: addpoint(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION addpoint(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.addpoint(geometry, geometry) OWNER TO ortelius;

--
-- Name: addpoint(geometry, geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION addpoint(geometry, geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.addpoint(geometry, geometry, integer) OWNER TO ortelius;

--
-- Name: affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_affine'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $2, $3, 0,  $4, $5, 0,  0, 0, 1,  $6, $7, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: area(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION area(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_area_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.area(geometry) OWNER TO ortelius;

--
-- Name: area2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION area2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_area_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.area2d(geometry) OWNER TO ortelius;

--
-- Name: asbinary(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asbinary(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_asBinary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asbinary(geometry) OWNER TO ortelius;

--
-- Name: asbinary(geometry, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asbinary(geometry, text) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_asBinary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asbinary(geometry, text) OWNER TO ortelius;

--
-- Name: asewkb(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asewkb(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'WKBFromLWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asewkb(geometry) OWNER TO ortelius;

--
-- Name: asewkb(geometry, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asewkb(geometry, text) RETURNS bytea
    AS '$libdir/liblwgeom', 'WKBFromLWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asewkb(geometry, text) OWNER TO ortelius;

--
-- Name: asewkt(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asewkt(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asEWKT'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asewkt(geometry) OWNER TO ortelius;

--
-- Name: asgml(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asgml(geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsGML(2, $1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.asgml(geometry, integer) OWNER TO ortelius;

--
-- Name: asgml(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asgml(geometry) RETURNS text
    AS $_$SELECT _ST_AsGML(2, $1, 15)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.asgml(geometry) OWNER TO ortelius;

--
-- Name: ashexewkb(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION ashexewkb(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asHEXEWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ashexewkb(geometry) OWNER TO ortelius;

--
-- Name: ashexewkb(geometry, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION ashexewkb(geometry, text) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asHEXEWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ashexewkb(geometry, text) OWNER TO ortelius;

--
-- Name: askml(geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION askml(geometry, integer, integer) RETURNS text
    AS $_$SELECT AsUKML(transform($1,4326),$2,$3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.askml(geometry, integer, integer) OWNER TO ortelius;

--
-- Name: askml(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION askml(geometry, integer) RETURNS text
    AS $_$SELECT AsUKML(transform($1,4326),$2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.askml(geometry, integer) OWNER TO ortelius;

--
-- Name: askml(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION askml(geometry) RETURNS text
    AS $_$SELECT AsUKML(transform($1,4326))$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.askml(geometry) OWNER TO ortelius;

--
-- Name: assvg(geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION assvg(geometry, integer, integer) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.assvg(geometry, integer, integer) OWNER TO ortelius;

--
-- Name: assvg(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION assvg(geometry, integer) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.assvg(geometry, integer) OWNER TO ortelius;

--
-- Name: assvg(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION assvg(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.assvg(geometry) OWNER TO ortelius;

--
-- Name: astext(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION astext(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asText'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.astext(geometry) OWNER TO ortelius;

--
-- Name: asukml(geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asukml(geometry, integer, integer) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asKML'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asukml(geometry, integer, integer) OWNER TO ortelius;

--
-- Name: asukml(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asukml(geometry, integer) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asKML'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asukml(geometry, integer) OWNER TO ortelius;

--
-- Name: asukml(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION asukml(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asKML'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.asukml(geometry) OWNER TO ortelius;

--
-- Name: azimuth(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION azimuth(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_azimuth'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.azimuth(geometry, geometry) OWNER TO ortelius;

--
-- Name: bdmpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION bdmpolyfromtext(text, integer) RETURNS geometry
    AS $_$
DECLARE
	geomtext alias for $1;
	srid alias for $2;
	mline geometry;
	geom geometry;
BEGIN
	mline := MultiLineStringFromText(geomtext, srid);

	IF mline IS NULL
	THEN
		RAISE EXCEPTION 'Input is not a MultiLinestring';
	END IF;

	geom := multi(BuildArea(mline));

	RETURN geom;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.bdmpolyfromtext(text, integer) OWNER TO ortelius;

--
-- Name: bdpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION bdpolyfromtext(text, integer) RETURNS geometry
    AS $_$
DECLARE
	geomtext alias for $1;
	srid alias for $2;
	mline geometry;
	geom geometry;
BEGIN
	mline := MultiLineStringFromText(geomtext, srid);

	IF mline IS NULL
	THEN
		RAISE EXCEPTION 'Input is not a MultiLinestring';
	END IF;

	geom := BuildArea(mline);

	IF GeometryType(geom) != 'POLYGON'
	THEN
		RAISE EXCEPTION 'Input returns more then a single polygon, try using BdMPolyFromText instead';
	END IF;

	RETURN geom;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.bdpolyfromtext(text, integer) OWNER TO ortelius;

--
-- Name: boundary(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION boundary(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'boundary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.boundary(geometry) OWNER TO ortelius;

--
-- Name: box(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box(geometry) RETURNS box
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box(geometry) OWNER TO ortelius;

--
-- Name: box(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box(box3d) RETURNS box
    AS '$libdir/liblwgeom', 'BOX3D_to_BOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box(box3d) OWNER TO ortelius;

--
-- Name: box2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d(geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d(geometry) OWNER TO ortelius;

--
-- Name: box2d(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d(box3d) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX3D_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d(box3d) OWNER TO ortelius;

--
-- Name: box2d_contain(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_contain(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_contain'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_contain(box2d, box2d) OWNER TO ortelius;

--
-- Name: box2d_contained(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_contained(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_contained'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_contained(box2d, box2d) OWNER TO ortelius;

--
-- Name: box2d_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_in(cstring) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_in(cstring) OWNER TO ortelius;

--
-- Name: box2d_intersects(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_intersects(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_intersects'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_intersects(box2d, box2d) OWNER TO ortelius;

--
-- Name: box2d_left(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_left(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_left'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_left(box2d, box2d) OWNER TO ortelius;

--
-- Name: box2d_out(box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_out(box2d) RETURNS cstring
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_out(box2d) OWNER TO ortelius;

--
-- Name: box2d_overlap(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_overlap(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overlap'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_overlap(box2d, box2d) OWNER TO ortelius;

--
-- Name: box2d_overleft(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_overleft(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overleft'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_overleft(box2d, box2d) OWNER TO ortelius;

--
-- Name: box2d_overright(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_overright(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overright'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_overright(box2d, box2d) OWNER TO ortelius;

--
-- Name: box2d_right(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_right(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_right'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_right(box2d, box2d) OWNER TO ortelius;

--
-- Name: box2d_same(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box2d_same(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_same'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box2d_same(box2d, box2d) OWNER TO ortelius;

--
-- Name: box3d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box3d(geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX3D'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box3d(geometry) OWNER TO ortelius;

--
-- Name: box3d(box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box3d(box2d) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_to_BOX3D'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box3d(box2d) OWNER TO ortelius;

--
-- Name: box3d_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box3d_in(cstring) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box3d_in(cstring) OWNER TO ortelius;

--
-- Name: box3d_out(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box3d_out(box3d) RETURNS cstring
    AS '$libdir/liblwgeom', 'BOX3D_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.box3d_out(box3d) OWNER TO ortelius;

--
-- Name: box3dtobox(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION box3dtobox(box3d) RETURNS box
    AS $_$SELECT box($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.box3dtobox(box3d) OWNER TO ortelius;

--
-- Name: buffer(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION buffer(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'buffer'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.buffer(geometry, double precision) OWNER TO ortelius;

--
-- Name: buffer(geometry, double precision, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION buffer(geometry, double precision, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'buffer'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.buffer(geometry, double precision, integer) OWNER TO ortelius;

--
-- Name: build_histogram2d(histogram2d, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION build_histogram2d(histogram2d, text, text) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'build_lwhistogram2d'
    LANGUAGE c STABLE STRICT;


ALTER FUNCTION public.build_histogram2d(histogram2d, text, text) OWNER TO ortelius;

--
-- Name: build_histogram2d(histogram2d, text, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION build_histogram2d(histogram2d, text, text, text) RETURNS histogram2d
    AS $_$
BEGIN
	EXECUTE 'SET local search_path = '||$2||',public';
	RETURN public.build_histogram2d($1,$3,$4);
END
$_$
    LANGUAGE plpgsql STABLE STRICT;


ALTER FUNCTION public.build_histogram2d(histogram2d, text, text, text) OWNER TO ortelius;

--
-- Name: buildarea(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION buildarea(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_buildarea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.buildarea(geometry) OWNER TO ortelius;

--
-- Name: bytea(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION bytea(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_to_bytea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.bytea(geometry) OWNER TO ortelius;

--
-- Name: cache_bbox(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION cache_bbox() RETURNS "trigger"
    AS '$libdir/liblwgeom', 'cache_bbox'
    LANGUAGE c;


ALTER FUNCTION public.cache_bbox() OWNER TO ortelius;

--
-- Name: centroid(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION centroid(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'centroid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.centroid(geometry) OWNER TO ortelius;

--
-- Name: checkauth(text, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION checkauth(text, text, text) RETURNS integer
    AS $_$
DECLARE
	schema text;
BEGIN
	IF NOT LongTransactionsEnabled() THEN
		RAISE EXCEPTION 'Long transaction support disabled, use EnableLongTransaction() to enable.';
	END IF;

	if ( $1 != '' ) THEN
		schema = $1;
	ELSE
		SELECT current_schema() into schema;
	END IF;

	-- TODO: check for an already existing trigger ?

	EXECUTE 'CREATE TRIGGER check_auth BEFORE UPDATE OR DELETE ON ' 
		|| quote_ident(schema) || '.' || quote_ident($2)
		||' FOR EACH ROW EXECUTE PROCEDURE CheckAuthTrigger('
		|| quote_literal($3) || ')';

	RETURN 0;
END;
$_$
    LANGUAGE plpgsql;


ALTER FUNCTION public.checkauth(text, text, text) OWNER TO ortelius;

--
-- Name: checkauth(text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION checkauth(text, text) RETURNS integer
    AS $_$SELECT CheckAuth('', $1, $2)$_$
    LANGUAGE sql;


ALTER FUNCTION public.checkauth(text, text) OWNER TO ortelius;

--
-- Name: checkauthtrigger(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION checkauthtrigger() RETURNS "trigger"
    AS '$libdir/liblwgeom', 'check_authorization'
    LANGUAGE c;


ALTER FUNCTION public.checkauthtrigger() OWNER TO ortelius;

--
-- Name: chip_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION chip_in(cstring) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.chip_in(cstring) OWNER TO ortelius;

--
-- Name: chip_out(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION chip_out(chip) RETURNS cstring
    AS '$libdir/liblwgeom', 'CHIP_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.chip_out(chip) OWNER TO ortelius;

--
-- Name: collect(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION collect(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.collect(geometry, geometry) OWNER TO ortelius;

--
-- Name: collect_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION collect_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.collect_garray(geometry[]) OWNER TO ortelius;

--
-- Name: collector(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION collector(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.collector(geometry, geometry) OWNER TO ortelius;

--
-- Name: combine_bbox(box2d, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION combine_bbox(box2d, geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_combine'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.combine_bbox(box2d, geometry) OWNER TO ortelius;

--
-- Name: combine_bbox(box3d, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION combine_bbox(box3d, geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_combine'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.combine_bbox(box3d, geometry) OWNER TO ortelius;

--
-- Name: compression(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION compression(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getCompression'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.compression(chip) OWNER TO ortelius;

--
-- Name: contains(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION contains(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'contains'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.contains(geometry, geometry) OWNER TO ortelius;

--
-- Name: convexhull(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION convexhull(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'convexhull'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.convexhull(geometry) OWNER TO ortelius;

--
-- Name: create_histogram2d(box2d, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION create_histogram2d(box2d, integer) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'create_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.create_histogram2d(box2d, integer) OWNER TO ortelius;

--
-- Name: crosses(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION crosses(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'crosses'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.crosses(geometry, geometry) OWNER TO ortelius;

--
-- Name: datatype(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION datatype(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getDatatype'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.datatype(chip) OWNER TO ortelius;

--
-- Name: difference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION difference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'difference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.difference(geometry, geometry) OWNER TO ortelius;

--
-- Name: dimension(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dimension(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_dimension'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.dimension(geometry) OWNER TO ortelius;

--
-- Name: disablelongtransactions(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION disablelongtransactions() RETURNS text
    AS $$
DECLARE
	rec RECORD;

BEGIN

	--
	-- Drop all triggers applied by CheckAuth()
	--
	FOR rec IN
		SELECT c.relname, t.tgname, t.tgargs FROM pg_trigger t, pg_class c, pg_proc p
		WHERE p.proname = 'checkauthtrigger' and t.tgfoid = p.oid and t.tgrelid = c.oid
	LOOP
		EXECUTE 'DROP TRIGGER ' || quote_ident(rec.tgname) ||
			' ON ' || quote_ident(rec.relname);
	END LOOP;

	--
	-- Drop the authorization_table table
	--
	FOR rec IN SELECT * FROM pg_class WHERE relname = 'authorization_table' LOOP
		DROP TABLE authorization_table;
	END LOOP;

	--
	-- Drop the authorized_tables view
	--
	FOR rec IN SELECT * FROM pg_class WHERE relname = 'authorized_tables' LOOP
		DROP VIEW authorized_tables;
	END LOOP;

	RETURN 'Long transactions support disabled';
END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.disablelongtransactions() OWNER TO ortelius;

--
-- Name: disjoint(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION disjoint(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'disjoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.disjoint(geometry, geometry) OWNER TO ortelius;

--
-- Name: distance(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION distance(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_mindistance2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.distance(geometry, geometry) OWNER TO ortelius;

--
-- Name: distance_sphere(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION distance_sphere(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_distance_sphere'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.distance_sphere(geometry, geometry) OWNER TO ortelius;

--
-- Name: distance_spheroid(geometry, geometry, spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION distance_spheroid(geometry, geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_distance_ellipsoid_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.distance_spheroid(geometry, geometry, spheroid) OWNER TO ortelius;

--
-- Name: dropbbox(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dropbbox(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_dropBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.dropbbox(geometry) OWNER TO ortelius;

--
-- Name: dropgeometrycolumn(character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dropgeometrycolumn(character varying, character varying, character varying, character varying) RETURNS text
    AS $_$
DECLARE
	catalog_name alias for $1; 
	schema_name alias for $2;
	table_name alias for $3;
	column_name alias for $4;
	myrec RECORD;
	okay boolean;
	real_schema name;

BEGIN


	-- Find, check or fix schema_name
	IF ( schema_name != '' ) THEN
		okay = 'f';

		FOR myrec IN SELECT nspname FROM pg_namespace WHERE text(nspname) = schema_name LOOP
			okay := 't';
		END LOOP;

		IF ( okay <> 't' ) THEN
			RAISE NOTICE 'Invalid schema name - using current_schema()';
			SELECT current_schema() into real_schema;
		ELSE
			real_schema = schema_name;
		END IF;
	ELSE
		SELECT current_schema() into real_schema;
	END IF;

 	-- Find out if the column is in the geometry_columns table
	okay = 'f';
	FOR myrec IN SELECT * from geometry_columns where f_table_schema = text(real_schema) and f_table_name = table_name and f_geometry_column = column_name LOOP
		okay := 't';
	END LOOP; 
	IF (okay <> 't') THEN 
		RAISE EXCEPTION 'column not found in geometry_columns table';
		RETURN 'f';
	END IF;

	-- Remove ref from geometry_columns table
	EXECUTE 'delete from geometry_columns where f_table_schema = ' ||
		quote_literal(real_schema) || ' and f_table_name = ' ||
		quote_literal(table_name)  || ' and f_geometry_column = ' ||
		quote_literal(column_name);
	
	-- Remove table column
	EXECUTE 'ALTER TABLE ' || quote_ident(real_schema) || '.' ||
		quote_ident(table_name) || ' DROP COLUMN ' ||
		quote_ident(column_name);


	RETURN real_schema || '.' || table_name || '.' || column_name ||' effectively removed.';
	
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.dropgeometrycolumn(character varying, character varying, character varying, character varying) OWNER TO ortelius;

--
-- Name: dropgeometrycolumn(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dropgeometrycolumn(character varying, character varying, character varying) RETURNS text
    AS $_$
DECLARE
	ret text;
BEGIN
	SELECT DropGeometryColumn('',$1,$2,$3) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.dropgeometrycolumn(character varying, character varying, character varying) OWNER TO ortelius;

--
-- Name: dropgeometrycolumn(character varying, character varying); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dropgeometrycolumn(character varying, character varying) RETURNS text
    AS $_$
DECLARE
	ret text;
BEGIN
	SELECT DropGeometryColumn('','',$1,$2) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.dropgeometrycolumn(character varying, character varying) OWNER TO ortelius;

--
-- Name: dropgeometrytable(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dropgeometrytable(character varying, character varying, character varying) RETURNS text
    AS $_$
DECLARE
	catalog_name alias for $1; 
	schema_name alias for $2;
	table_name alias for $3;
	real_schema name;

BEGIN

	IF ( schema_name = '' ) THEN
		SELECT current_schema() into real_schema;
	ELSE
		real_schema = schema_name;
	END IF;

	-- Remove refs from geometry_columns table
	EXECUTE 'DELETE FROM geometry_columns WHERE ' ||
		'f_table_schema = ' || quote_literal(real_schema) ||
		' AND ' ||
		' f_table_name = ' || quote_literal(table_name);
	
	-- Remove table 
	EXECUTE 'DROP TABLE '
		|| quote_ident(real_schema) || '.' ||
		quote_ident(table_name);

	RETURN
		real_schema || '.' ||
		table_name ||' dropped.';
	
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.dropgeometrytable(character varying, character varying, character varying) OWNER TO ortelius;

--
-- Name: dropgeometrytable(character varying, character varying); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dropgeometrytable(character varying, character varying) RETURNS text
    AS $_$SELECT DropGeometryTable('',$1,$2)$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.dropgeometrytable(character varying, character varying) OWNER TO ortelius;

--
-- Name: dropgeometrytable(character varying); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dropgeometrytable(character varying) RETURNS text
    AS $_$SELECT DropGeometryTable('','',$1)$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.dropgeometrytable(character varying) OWNER TO ortelius;

--
-- Name: dump(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dump(geometry) RETURNS SETOF geometry_dump
    AS '$libdir/liblwgeom', 'LWGEOM_dump'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.dump(geometry) OWNER TO ortelius;

--
-- Name: dumprings(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION dumprings(geometry) RETURNS SETOF geometry_dump
    AS '$libdir/liblwgeom', 'LWGEOM_dump_rings'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.dumprings(geometry) OWNER TO ortelius;

--
-- Name: enablelongtransactions(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION enablelongtransactions() RETURNS text
    AS $$
DECLARE
	"query" text;
	exists bool;
	rec RECORD;

BEGIN

	exists = 'f';
	FOR rec IN SELECT * FROM pg_class WHERE relname = 'authorization_table'
	LOOP
		exists = 't';
	END LOOP;

	IF NOT exists
	THEN
		"query" = 'CREATE TABLE authorization_table (
			toid oid, -- table oid
			rid text, -- row id
			expires timestamp,
			authid text
		)';
		EXECUTE "query";
	END IF;

	exists = 'f';
	FOR rec IN SELECT * FROM pg_class WHERE relname = 'authorized_tables'
	LOOP
		exists = 't';
	END LOOP;

	IF NOT exists THEN
		"query" = 'CREATE VIEW authorized_tables AS ' ||
			'SELECT ' ||
			'n.nspname as schema, ' ||
			'c.relname as table, trim(' ||
			quote_literal(chr(92) || '000') ||
			' from t.tgargs) as id_column ' ||
			'FROM pg_trigger t, pg_class c, pg_proc p ' ||
			', pg_namespace n ' ||
			'WHERE p.proname = ' || quote_literal('checkauthtrigger') ||
			' AND c.relnamespace = n.oid' ||
			' AND t.tgfoid = p.oid and t.tgrelid = c.oid';
		EXECUTE "query";
	END IF;

	RETURN 'Long transactions support enabled';
END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.enablelongtransactions() OWNER TO ortelius;

--
-- Name: endpoint(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION endpoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_endpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.endpoint(geometry) OWNER TO ortelius;

--
-- Name: envelope(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION envelope(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_envelope'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.envelope(geometry) OWNER TO ortelius;

--
-- Name: equals(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION equals(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'geomequals'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.equals(geometry, geometry) OWNER TO ortelius;

--
-- Name: estimate_histogram2d(histogram2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION estimate_histogram2d(histogram2d, box2d) RETURNS double precision
    AS '$libdir/liblwgeom', 'estimate_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.estimate_histogram2d(histogram2d, box2d) OWNER TO ortelius;

--
-- Name: estimated_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION estimated_extent(text, text, text) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_estimated_extent'
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER;


ALTER FUNCTION public.estimated_extent(text, text, text) OWNER TO ortelius;

--
-- Name: estimated_extent(text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION estimated_extent(text, text) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_estimated_extent'
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER;


ALTER FUNCTION public.estimated_extent(text, text) OWNER TO ortelius;

--
-- Name: expand(box3d, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION expand(box3d, double precision) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.expand(box3d, double precision) OWNER TO ortelius;

--
-- Name: expand(box2d, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION expand(box2d, double precision) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.expand(box2d, double precision) OWNER TO ortelius;

--
-- Name: expand(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION expand(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.expand(geometry, double precision) OWNER TO ortelius;

--
-- Name: explode_histogram2d(histogram2d, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION explode_histogram2d(histogram2d, text) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'explode_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.explode_histogram2d(histogram2d, text) OWNER TO ortelius;

--
-- Name: exteriorring(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION exteriorring(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_exteriorring_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.exteriorring(geometry) OWNER TO ortelius;

--
-- Name: factor(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION factor(chip) RETURNS real
    AS '$libdir/liblwgeom', 'CHIP_getFactor'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.factor(chip) OWNER TO ortelius;

--
-- Name: find_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION find_extent(text, text, text) RETURNS box2d
    AS $_$
DECLARE
	schemaname alias for $1;
	tablename alias for $2;
	columnname alias for $3;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT extent("'||columnname||'") FROM "'||schemaname||'"."'||tablename||'"' LOOP
		return myrec.extent;
	END LOOP; 
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.find_extent(text, text, text) OWNER TO ortelius;

--
-- Name: find_extent(text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION find_extent(text, text) RETURNS box2d
    AS $_$
DECLARE
	tablename alias for $1;
	columnname alias for $2;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT extent("'||columnname||'") FROM "'||tablename||'"' LOOP
		return myrec.extent;
	END LOOP; 
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.find_extent(text, text) OWNER TO ortelius;

--
-- Name: find_srid(character varying, character varying, character varying); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION find_srid(character varying, character varying, character varying) RETURNS integer
    AS $_$DECLARE
   schem text;
   tabl text;
   sr int4;
BEGIN
   IF $1 IS NULL THEN
      RAISE EXCEPTION 'find_srid() - schema is NULL!';
   END IF;
   IF $2 IS NULL THEN
      RAISE EXCEPTION 'find_srid() - table name is NULL!';
   END IF;
   IF $3 IS NULL THEN
      RAISE EXCEPTION 'find_srid() - column name is NULL!';
   END IF;
   schem = $1;
   tabl = $2;
-- if the table contains a . and the schema is empty
-- split the table into a schema and a table
-- otherwise drop through to default behavior
   IF ( schem = '' and tabl LIKE '%.%' ) THEN
     schem = substr(tabl,1,strpos(tabl,'.')-1);
     tabl = substr(tabl,length(schem)+2);
   ELSE
     schem = schem || '%';
   END IF;

   select SRID into sr from geometry_columns where f_table_schema like schem and f_table_name = tabl and f_geometry_column = $3;
   IF NOT FOUND THEN
       RAISE EXCEPTION 'find_srid() - couldnt find the corresponding SRID - is the geometry registered in the GEOMETRY_COLUMNS table?  Is there an uppercase/lowercase missmatch?';
   END IF;
  return sr;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.find_srid(character varying, character varying, character varying) OWNER TO ortelius;

--
-- Name: fix_geometry_columns(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION fix_geometry_columns() RETURNS text
    AS $$
DECLARE
	mislinked record;
	result text;
	linked integer;
	deleted integer;
	foundschema integer;
BEGIN

	-- Since 7.3 schema support has been added.
	-- Previous postgis versions used to put the database name in
	-- the schema column. This needs to be fixed, so we try to 
	-- set the correct schema for each geometry_colums record
	-- looking at table, column, type and srid.
	UPDATE geometry_columns SET f_table_schema = n.nspname
		FROM pg_namespace n, pg_class c, pg_attribute a,
			pg_constraint sridcheck, pg_constraint typecheck
                WHERE ( f_table_schema is NULL
		OR f_table_schema = ''
                OR f_table_schema NOT IN (
                        SELECT nspname::varchar
                        FROM pg_namespace nn, pg_class cc, pg_attribute aa
                        WHERE cc.relnamespace = nn.oid
                        AND cc.relname = f_table_name::name
                        AND aa.attrelid = cc.oid
                        AND aa.attname = f_geometry_column::name))
                AND f_table_name::name = c.relname
                AND c.oid = a.attrelid
                AND c.relnamespace = n.oid
                AND f_geometry_column::name = a.attname

                AND sridcheck.conrelid = c.oid
		AND sridcheck.consrc LIKE '(srid(% = %)'
                AND sridcheck.consrc ~ textcat(' = ', srid::text)

                AND typecheck.conrelid = c.oid
		AND typecheck.consrc LIKE
	'((geometrytype(%) = ''%''::text) OR (% IS NULL))'
                AND typecheck.consrc ~ textcat(' = ''', type::text)

                AND NOT EXISTS (
                        SELECT oid FROM geometry_columns gc
                        WHERE c.relname::varchar = gc.f_table_name
                        AND n.nspname::varchar = gc.f_table_schema
                        AND a.attname::varchar = gc.f_geometry_column
                );

	GET DIAGNOSTICS foundschema = ROW_COUNT;

	-- no linkage to system table needed
	return 'fixed:'||foundschema::text;

	-- fix linking to system tables
	SELECT 0 INTO linked;
	FOR mislinked in
		SELECT gc.oid as gcrec,
			a.attrelid as attrelid, a.attnum as attnum
                FROM geometry_columns gc, pg_class c,
		pg_namespace n, pg_attribute a
                WHERE ( gc.attrelid IS NULL OR gc.attrelid != a.attrelid 
			OR gc.varattnum IS NULL OR gc.varattnum != a.attnum)
                AND n.nspname = gc.f_table_schema::name
                AND c.relnamespace = n.oid
                AND c.relname = gc.f_table_name::name
                AND a.attname = f_geometry_column::name
                AND a.attrelid = c.oid
	LOOP
		UPDATE geometry_columns SET
			attrelid = mislinked.attrelid,
			varattnum = mislinked.attnum,
			stats = NULL
			WHERE geometry_columns.oid = mislinked.gcrec;
		SELECT linked+1 INTO linked;
	END LOOP; 

	-- remove stale records
	DELETE FROM geometry_columns WHERE attrelid IS NULL;

	GET DIAGNOSTICS deleted = ROW_COUNT;

	result = 
		'fixed:' || foundschema::text ||
		' linked:' || linked::text || 
		' deleted:' || deleted::text;

	return result;

END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.fix_geometry_columns() OWNER TO ortelius;

--
-- Name: force_2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION force_2d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_2d(geometry) OWNER TO ortelius;

--
-- Name: force_3d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION force_3d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dz'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_3d(geometry) OWNER TO ortelius;

--
-- Name: force_3dm(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION force_3dm(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dm'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_3dm(geometry) OWNER TO ortelius;

--
-- Name: force_3dz(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION force_3dz(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dz'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_3dz(geometry) OWNER TO ortelius;

--
-- Name: force_4d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION force_4d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_4d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_4d(geometry) OWNER TO ortelius;

--
-- Name: force_collection(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION force_collection(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.force_collection(geometry) OWNER TO ortelius;

--
-- Name: forcerhr(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION forcerhr(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_forceRHR_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.forcerhr(geometry) OWNER TO ortelius;

--
-- Name: geom_accum(geometry[], geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geom_accum(geometry[], geometry) RETURNS geometry[]
    AS '$libdir/liblwgeom', 'LWGEOM_accum'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.geom_accum(geometry[], geometry) OWNER TO ortelius;

--
-- Name: geomcollfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomcollfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomcollfromtext(text, integer) OWNER TO ortelius;

--
-- Name: geomcollfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomcollfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomcollfromtext(text) OWNER TO ortelius;

--
-- Name: geomcollfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomcollfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromWKB($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomcollfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: geomcollfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomcollfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromWKB($1)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomcollfromwkb(bytea) OWNER TO ortelius;

--
-- Name: geometry(box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry(box2d) RETURNS geometry
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(box2d) OWNER TO ortelius;

--
-- Name: geometry(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry(box3d) RETURNS geometry
    AS '$libdir/liblwgeom', 'BOX3D_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(box3d) OWNER TO ortelius;

--
-- Name: geometry(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'parse_WKT_lwgeom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(text) OWNER TO ortelius;

--
-- Name: geometry(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry(chip) RETURNS geometry
    AS '$libdir/liblwgeom', 'CHIP_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(chip) OWNER TO ortelius;

--
-- Name: geometry(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_bytea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry(bytea) OWNER TO ortelius;

--
-- Name: geometry_above(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_above(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_above'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_above(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_analyze(internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_analyze(internal) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_analyze'
    LANGUAGE c STRICT;


ALTER FUNCTION public.geometry_analyze(internal) OWNER TO ortelius;

--
-- Name: geometry_below(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_below(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_below'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_below(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_cmp(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_cmp(geometry, geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'lwgeom_cmp'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_cmp(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_contain(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_contain(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_contain'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_contain(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_contained(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_contained(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_contained'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_contained(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_eq(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_eq(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_eq'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_eq(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_ge(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_ge(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_ge'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_ge(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_gt(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_gt(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_gt'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_gt(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_in(cstring) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_in(cstring) OWNER TO ortelius;

--
-- Name: geometry_le(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_le(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_le'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_le(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_left(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_left(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_left'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_left(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_lt(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_lt(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_lt'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_lt(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_out(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_out(geometry) RETURNS cstring
    AS '$libdir/liblwgeom', 'LWGEOM_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_out(geometry) OWNER TO ortelius;

--
-- Name: geometry_overabove(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_overabove(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overabove'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overabove(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_overbelow(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_overbelow(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overbelow'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overbelow(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_overlap(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_overlap(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overlap'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overlap(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_overleft(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_overleft(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overleft'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overleft(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_overright(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_overright(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overright'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_overright(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_recv(internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_recv(internal) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_recv'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_recv(internal) OWNER TO ortelius;

--
-- Name: geometry_right(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_right(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_right'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_right(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_same(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_same(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_same'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_same(geometry, geometry) OWNER TO ortelius;

--
-- Name: geometry_send(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometry_send(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_send'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometry_send(geometry) OWNER TO ortelius;

--
-- Name: geometryfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometryfromtext(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometryfromtext(text) OWNER TO ortelius;

--
-- Name: geometryfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometryfromtext(text, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometryfromtext(text, integer) OWNER TO ortelius;

--
-- Name: geometryn(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometryn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_geometryn_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometryn(geometry, integer) OWNER TO ortelius;

--
-- Name: geometrytype(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geometrytype(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_getTYPE'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geometrytype(geometry) OWNER TO ortelius;

--
-- Name: geomfromewkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomfromewkb(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOMFromWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromewkb(bytea) OWNER TO ortelius;

--
-- Name: geomfromewkt(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomfromewkt(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'parse_WKT_lwgeom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromewkt(text) OWNER TO ortelius;

--
-- Name: geomfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomfromtext(text) RETURNS geometry
    AS $_$SELECT geometryfromtext($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromtext(text) OWNER TO ortelius;

--
-- Name: geomfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomfromtext(text, integer) RETURNS geometry
    AS $_$SELECT geometryfromtext($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromtext(text, integer) OWNER TO ortelius;

--
-- Name: geomfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomfromwkb(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_WKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromwkb(bytea) OWNER TO ortelius;

--
-- Name: geomfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomfromwkb(bytea, integer) RETURNS geometry
    AS $_$SELECT setSRID(GeomFromWKB($1), $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.geomfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: geomunion(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geomunion(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'geomunion'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.geomunion(geometry, geometry) OWNER TO ortelius;

--
-- Name: geosnoop(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION geosnoop(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'GEOSnoop'
    LANGUAGE c STRICT;


ALTER FUNCTION public.geosnoop(geometry) OWNER TO ortelius;

--
-- Name: get_proj4_from_srid(integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION get_proj4_from_srid(integer) RETURNS text
    AS $_$
BEGIN
	RETURN proj4text::text FROM spatial_ref_sys WHERE srid= $1;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.get_proj4_from_srid(integer) OWNER TO ortelius;

--
-- Name: getbbox(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION getbbox(geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.getbbox(geometry) OWNER TO ortelius;

--
-- Name: getsrid(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION getsrid(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.getsrid(geometry) OWNER TO ortelius;

--
-- Name: gettransactionid(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION gettransactionid() RETURNS xid
    AS '$libdir/liblwgeom', 'getTransactionID'
    LANGUAGE c;


ALTER FUNCTION public.gettransactionid() OWNER TO ortelius;

--
-- Name: hasbbox(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION hasbbox(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_hasBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.hasbbox(geometry) OWNER TO ortelius;

--
-- Name: height(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION height(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getHeight'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.height(chip) OWNER TO ortelius;

--
-- Name: histogram2d_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION histogram2d_in(cstring) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'lwhistogram2d_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.histogram2d_in(cstring) OWNER TO ortelius;

--
-- Name: histogram2d_out(histogram2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION histogram2d_out(histogram2d) RETURNS cstring
    AS '$libdir/liblwgeom', 'lwhistogram2d_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.histogram2d_out(histogram2d) OWNER TO ortelius;

--
-- Name: interiorringn(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION interiorringn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_interiorringn_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.interiorringn(geometry, integer) OWNER TO ortelius;

--
-- Name: intersection(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION intersection(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'intersection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.intersection(geometry, geometry) OWNER TO ortelius;

--
-- Name: intersects(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION intersects(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'intersects'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.intersects(geometry, geometry) OWNER TO ortelius;

--
-- Name: isclosed(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION isclosed(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_isclosed_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.isclosed(geometry) OWNER TO ortelius;

--
-- Name: isempty(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION isempty(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_isempty'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.isempty(geometry) OWNER TO ortelius;

--
-- Name: isring(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION isring(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'isring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.isring(geometry) OWNER TO ortelius;

--
-- Name: issimple(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION issimple(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'issimple'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.issimple(geometry) OWNER TO ortelius;

--
-- Name: isvalid(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION isvalid(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'isvalid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.isvalid(geometry) OWNER TO ortelius;

--
-- Name: jtsnoop(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION jtsnoop(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'JTSnoop'
    LANGUAGE c STRICT;


ALTER FUNCTION public.jtsnoop(geometry) OWNER TO ortelius;

--
-- Name: length(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION length(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length(geometry) OWNER TO ortelius;

--
-- Name: length2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION length2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length2d(geometry) OWNER TO ortelius;

--
-- Name: length2d_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION length2d_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length2d_spheroid(geometry, spheroid) OWNER TO ortelius;

--
-- Name: length3d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION length3d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length3d(geometry) OWNER TO ortelius;

--
-- Name: length3d_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION length3d_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length3d_spheroid(geometry, spheroid) OWNER TO ortelius;

--
-- Name: length_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION length_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.length_spheroid(geometry, spheroid) OWNER TO ortelius;

--
-- Name: line_interpolate_point(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION line_interpolate_point(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_interpolate_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.line_interpolate_point(geometry, double precision) OWNER TO ortelius;

--
-- Name: line_locate_point(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION line_locate_point(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_line_locate_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.line_locate_point(geometry, geometry) OWNER TO ortelius;

--
-- Name: line_substring(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION line_substring(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_substring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.line_substring(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: linefrommultipoint(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linefrommultipoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_from_mpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.linefrommultipoint(geometry) OWNER TO ortelius;

--
-- Name: linefromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linefromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'LINESTRING'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linefromtext(text) OWNER TO ortelius;

--
-- Name: linefromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linefromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'LINESTRING'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linefromtext(text, integer) OWNER TO ortelius;

--
-- Name: linefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linefromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: linefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'LINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linefromwkb(bytea) OWNER TO ortelius;

--
-- Name: linemerge(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linemerge(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'linemerge'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.linemerge(geometry) OWNER TO ortelius;

--
-- Name: linestringfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linestringfromtext(text) RETURNS geometry
    AS $_$SELECT LineFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linestringfromtext(text) OWNER TO ortelius;

--
-- Name: linestringfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linestringfromtext(text, integer) RETURNS geometry
    AS $_$SELECT LineFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linestringfromtext(text, integer) OWNER TO ortelius;

--
-- Name: linestringfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linestringfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linestringfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: linestringfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION linestringfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'LINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.linestringfromwkb(bytea) OWNER TO ortelius;

--
-- Name: locate_along_measure(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION locate_along_measure(geometry, double precision) RETURNS geometry
    AS $_$SELECT locate_between_measures($1, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.locate_along_measure(geometry, double precision) OWNER TO ortelius;

--
-- Name: locate_between_measures(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION locate_between_measures(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_locate_between_m'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.locate_between_measures(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: lockrow(text, text, text, text, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lockrow(text, text, text, text, timestamp without time zone) RETURNS integer
    AS $_$
DECLARE
	myschema alias for $1;
	mytable alias for $2;
	myrid   alias for $3;
	authid alias for $4;
	expires alias for $5;
	ret int;
	mytoid oid;
	myrec RECORD;
	
BEGIN

	IF NOT LongTransactionsEnabled() THEN
		RAISE EXCEPTION 'Long transaction support disabled, use EnableLongTransaction() to enable.';
	END IF;

	EXECUTE 'DELETE FROM authorization_table WHERE expires < now()'; 

	SELECT c.oid INTO mytoid FROM pg_class c, pg_namespace n
		WHERE c.relname = mytable
		AND c.relnamespace = n.oid
		AND n.nspname = myschema;

	-- RAISE NOTICE 'toid: %', mytoid;

	FOR myrec IN SELECT * FROM authorization_table WHERE 
		toid = mytoid AND rid = myrid
	LOOP
		IF myrec.authid != authid THEN
			RETURN 0;
		ELSE
			RETURN 1;
		END IF;
	END LOOP;

	EXECUTE 'INSERT INTO authorization_table VALUES ('||
		quote_literal(mytoid::text)||','||quote_literal(myrid)||
		','||quote_literal(expires::text)||
		','||quote_literal(authid) ||')';

	GET DIAGNOSTICS ret = ROW_COUNT;

	RETURN ret;
END;$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.lockrow(text, text, text, text, timestamp without time zone) OWNER TO ortelius;

--
-- Name: lockrow(text, text, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lockrow(text, text, text, text) RETURNS integer
    AS $_$SELECT LockRow($1, $2, $3, $4, now()::timestamp+'1:00');$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.lockrow(text, text, text, text) OWNER TO ortelius;

--
-- Name: lockrow(text, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lockrow(text, text, text) RETURNS integer
    AS $_$SELECT LockRow(current_schema(), $1, $2, $3, now()::timestamp+'1:00');$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.lockrow(text, text, text) OWNER TO ortelius;

--
-- Name: lockrow(text, text, text, timestamp without time zone); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lockrow(text, text, text, timestamp without time zone) RETURNS integer
    AS $_$SELECT LockRow(current_schema(), $1, $2, $3, $4);$_$
    LANGUAGE sql STRICT;


ALTER FUNCTION public.lockrow(text, text, text, timestamp without time zone) OWNER TO ortelius;

--
-- Name: longtransactionsenabled(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION longtransactionsenabled() RETURNS boolean
    AS $$
DECLARE
	rec RECORD;
BEGIN
	FOR rec IN SELECT oid FROM pg_class WHERE relname = 'authorized_tables'
	LOOP
		return 't';
	END LOOP;
	return 'f';
END;
$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.longtransactionsenabled() OWNER TO ortelius;

--
-- Name: lwgeom_gist_compress(internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lwgeom_gist_compress(internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_compress'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_compress(internal) OWNER TO ortelius;

--
-- Name: lwgeom_gist_consistent(internal, geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lwgeom_gist_consistent(internal, geometry, integer) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_gist_consistent'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_consistent(internal, geometry, integer) OWNER TO ortelius;

--
-- Name: lwgeom_gist_decompress(internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lwgeom_gist_decompress(internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_decompress'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_decompress(internal) OWNER TO ortelius;

--
-- Name: lwgeom_gist_penalty(internal, internal, internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lwgeom_gist_penalty(internal, internal, internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_penalty'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_penalty(internal, internal, internal) OWNER TO ortelius;

--
-- Name: lwgeom_gist_picksplit(internal, internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lwgeom_gist_picksplit(internal, internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_picksplit'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_picksplit(internal, internal) OWNER TO ortelius;

--
-- Name: lwgeom_gist_same(box2d, box2d, internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lwgeom_gist_same(box2d, box2d, internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_same'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_same(box2d, box2d, internal) OWNER TO ortelius;

--
-- Name: lwgeom_gist_union(bytea, internal); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION lwgeom_gist_union(bytea, internal) RETURNS internal
    AS '$libdir/liblwgeom', 'LWGEOM_gist_union'
    LANGUAGE c;


ALTER FUNCTION public.lwgeom_gist_union(bytea, internal) OWNER TO ortelius;

--
-- Name: m(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION m(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_m_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.m(geometry) OWNER TO ortelius;

--
-- Name: makebox2d(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makebox2d(geometry, geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_construct'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makebox2d(geometry, geometry) OWNER TO ortelius;

--
-- Name: makebox3d(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makebox3d(geometry, geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_construct'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makebox3d(geometry, geometry) OWNER TO ortelius;

--
-- Name: makeline(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makeline(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makeline'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makeline(geometry, geometry) OWNER TO ortelius;

--
-- Name: makeline_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makeline_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makeline_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makeline_garray(geometry[]) OWNER TO ortelius;

--
-- Name: makepoint(double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makepoint(double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepoint(double precision, double precision) OWNER TO ortelius;

--
-- Name: makepoint(double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makepoint(double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepoint(double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: makepoint(double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makepoint(double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepoint(double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: makepointm(double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makepointm(double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint3dm'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepointm(double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: makepolygon(geometry, geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makepolygon(geometry, geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepolygon(geometry, geometry[]) OWNER TO ortelius;

--
-- Name: makepolygon(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION makepolygon(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.makepolygon(geometry) OWNER TO ortelius;

--
-- Name: max_distance(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION max_distance(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_maxdistance2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.max_distance(geometry, geometry) OWNER TO ortelius;

--
-- Name: mem_size(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mem_size(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_mem_size'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.mem_size(geometry) OWNER TO ortelius;

--
-- Name: mlinefromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mlinefromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mlinefromtext(text, integer) OWNER TO ortelius;

--
-- Name: mlinefromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mlinefromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTILINESTRING'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mlinefromtext(text) OWNER TO ortelius;

--
-- Name: mlinefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mlinefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mlinefromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: mlinefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mlinefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mlinefromwkb(bytea) OWNER TO ortelius;

--
-- Name: mpointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mpointfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1,$2)) = 'MULTIPOINT'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpointfromtext(text, integer) OWNER TO ortelius;

--
-- Name: mpointfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mpointfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTIPOINT'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpointfromtext(text) OWNER TO ortelius;

--
-- Name: mpointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mpointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'MULTIPOINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpointfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: mpointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mpointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpointfromwkb(bytea) OWNER TO ortelius;

--
-- Name: mpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mpolyfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpolyfromtext(text, integer) OWNER TO ortelius;

--
-- Name: mpolyfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mpolyfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTIPOLYGON'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpolyfromtext(text) OWNER TO ortelius;

--
-- Name: mpolyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mpolyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpolyfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: mpolyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION mpolyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.mpolyfromwkb(bytea) OWNER TO ortelius;

--
-- Name: multi(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multi(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_multi'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.multi(geometry) OWNER TO ortelius;

--
-- Name: multilinefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multilinefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multilinefromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: multilinefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multilinefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multilinefromwkb(bytea) OWNER TO ortelius;

--
-- Name: multilinestringfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multilinestringfromtext(text) RETURNS geometry
    AS $_$SELECT MLineFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multilinestringfromtext(text) OWNER TO ortelius;

--
-- Name: multilinestringfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multilinestringfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MLineFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multilinestringfromtext(text, integer) OWNER TO ortelius;

--
-- Name: multipointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multipointfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MPointFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipointfromtext(text, integer) OWNER TO ortelius;

--
-- Name: multipointfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multipointfromtext(text) RETURNS geometry
    AS $_$SELECT MPointFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipointfromtext(text) OWNER TO ortelius;

--
-- Name: multipointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multipointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'MULTIPOINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipointfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: multipointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multipointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipointfromwkb(bytea) OWNER TO ortelius;

--
-- Name: multipolyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multipolyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipolyfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: multipolyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multipolyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipolyfromwkb(bytea) OWNER TO ortelius;

--
-- Name: multipolygonfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multipolygonfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MPolyFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipolygonfromtext(text, integer) OWNER TO ortelius;

--
-- Name: multipolygonfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION multipolygonfromtext(text) RETURNS geometry
    AS $_$SELECT MPolyFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.multipolygonfromtext(text) OWNER TO ortelius;

--
-- Name: ndims(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION ndims(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_ndims'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ndims(geometry) OWNER TO ortelius;

--
-- Name: noop(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION noop(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_noop'
    LANGUAGE c STRICT;


ALTER FUNCTION public.noop(geometry) OWNER TO ortelius;

--
-- Name: npoints(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION npoints(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_npoints'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.npoints(geometry) OWNER TO ortelius;

--
-- Name: nrings(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION nrings(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_nrings'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.nrings(geometry) OWNER TO ortelius;

--
-- Name: numgeometries(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION numgeometries(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numgeometries_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.numgeometries(geometry) OWNER TO ortelius;

--
-- Name: numinteriorring(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION numinteriorring(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numinteriorrings_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.numinteriorring(geometry) OWNER TO ortelius;

--
-- Name: numinteriorrings(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION numinteriorrings(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numinteriorrings_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.numinteriorrings(geometry) OWNER TO ortelius;

--
-- Name: numpoints(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION numpoints(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numpoints_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.numpoints(geometry) OWNER TO ortelius;

--
-- Name: overlaps(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION "overlaps"(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'overlaps'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public."overlaps"(geometry, geometry) OWNER TO ortelius;

--
-- Name: perimeter(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION perimeter(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.perimeter(geometry) OWNER TO ortelius;

--
-- Name: perimeter2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION perimeter2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter2d_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.perimeter2d(geometry) OWNER TO ortelius;

--
-- Name: perimeter3d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION perimeter3d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.perimeter3d(geometry) OWNER TO ortelius;

--
-- Name: point_inside_circle(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION point_inside_circle(geometry, double precision, double precision, double precision) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_inside_circle_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.point_inside_circle(geometry, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: pointfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION pointfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'POINT'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.pointfromtext(text) OWNER TO ortelius;

--
-- Name: pointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION pointfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'POINT'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.pointfromtext(text, integer) OWNER TO ortelius;

--
-- Name: pointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION pointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'POINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.pointfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: pointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION pointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.pointfromwkb(bytea) OWNER TO ortelius;

--
-- Name: pointn(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION pointn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_pointn_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.pointn(geometry, integer) OWNER TO ortelius;

--
-- Name: pointonsurface(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION pointonsurface(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'pointonsurface'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.pointonsurface(geometry) OWNER TO ortelius;

--
-- Name: polyfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION polyfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'POLYGON'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polyfromtext(text) OWNER TO ortelius;

--
-- Name: polyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION polyfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'POLYGON'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polyfromtext(text, integer) OWNER TO ortelius;

--
-- Name: polyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION polyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'POLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polyfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: polyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION polyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polyfromwkb(bytea) OWNER TO ortelius;

--
-- Name: polygonfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION polygonfromtext(text, integer) RETURNS geometry
    AS $_$SELECT PolyFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polygonfromtext(text, integer) OWNER TO ortelius;

--
-- Name: polygonfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION polygonfromtext(text) RETURNS geometry
    AS $_$SELECT PolyFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polygonfromtext(text) OWNER TO ortelius;

--
-- Name: polygonfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION polygonfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'POLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polygonfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: polygonfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION polygonfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.polygonfromwkb(bytea) OWNER TO ortelius;

--
-- Name: polygonize_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION polygonize_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'polygonize_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.polygonize_garray(geometry[]) OWNER TO ortelius;

--
-- Name: postgis_full_version(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_full_version() RETURNS text
    AS $$
DECLARE
	libver text;
	projver text;
	geosver text;
	jtsver text;
	usestats bool;
	dbproc text;
	relproc text;
	fullver text;
BEGIN
	SELECT postgis_lib_version() INTO libver;
	SELECT postgis_proj_version() INTO projver;
	SELECT postgis_geos_version() INTO geosver;
	SELECT postgis_jts_version() INTO jtsver;
	SELECT postgis_uses_stats() INTO usestats;
	SELECT postgis_scripts_installed() INTO dbproc;
	SELECT postgis_scripts_released() INTO relproc;

	fullver = 'POSTGIS="' || libver || '"';

	IF  geosver IS NOT NULL THEN
		fullver = fullver || ' GEOS="' || geosver || '"';
	END IF;

	IF  jtsver IS NOT NULL THEN
		fullver = fullver || ' JTS="' || jtsver || '"';
	END IF;

	IF  projver IS NOT NULL THEN
		fullver = fullver || ' PROJ="' || projver || '"';
	END IF;

	IF usestats THEN
		fullver = fullver || ' USE_STATS';
	END IF;

	-- fullver = fullver || ' DBPROC="' || dbproc || '"';
	-- fullver = fullver || ' RELPROC="' || relproc || '"';

	IF dbproc != relproc THEN
		fullver = fullver || ' (procs from ' || dbproc || ' need upgrade)';
	END IF;

	RETURN fullver;
END
$$
    LANGUAGE plpgsql IMMUTABLE;


ALTER FUNCTION public.postgis_full_version() OWNER TO ortelius;

--
-- Name: postgis_geos_version(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_geos_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_geos_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_geos_version() OWNER TO ortelius;

--
-- Name: postgis_gist_joinsel(internal, oid, internal, smallint); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_gist_joinsel(internal, oid, internal, smallint) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_gist_joinsel'
    LANGUAGE c;


ALTER FUNCTION public.postgis_gist_joinsel(internal, oid, internal, smallint) OWNER TO ortelius;

--
-- Name: postgis_gist_sel(internal, oid, internal, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_gist_sel(internal, oid, internal, integer) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_gist_sel'
    LANGUAGE c;


ALTER FUNCTION public.postgis_gist_sel(internal, oid, internal, integer) OWNER TO ortelius;

--
-- Name: postgis_jts_version(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_jts_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_jts_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_jts_version() OWNER TO ortelius;

--
-- Name: postgis_lib_build_date(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_lib_build_date() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_lib_build_date'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_lib_build_date() OWNER TO ortelius;

--
-- Name: postgis_lib_version(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_lib_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_lib_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_lib_version() OWNER TO ortelius;

--
-- Name: postgis_proj_version(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_proj_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_proj_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_proj_version() OWNER TO ortelius;

--
-- Name: postgis_scripts_build_date(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_scripts_build_date() RETURNS text
    AS $$SELECT '2007-12-28 03:40:22'::text AS version$$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.postgis_scripts_build_date() OWNER TO ortelius;

--
-- Name: postgis_scripts_installed(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_scripts_installed() RETURNS text
    AS $$SELECT '1.3.2'::text AS version$$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.postgis_scripts_installed() OWNER TO ortelius;

--
-- Name: postgis_scripts_released(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_scripts_released() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_scripts_released'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_scripts_released() OWNER TO ortelius;

--
-- Name: postgis_uses_stats(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_uses_stats() RETURNS boolean
    AS '$libdir/liblwgeom', 'postgis_uses_stats'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_uses_stats() OWNER TO ortelius;

--
-- Name: postgis_version(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION postgis_version() RETURNS text
    AS '$libdir/liblwgeom', 'postgis_version'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.postgis_version() OWNER TO ortelius;

--
-- Name: probe_geometry_columns(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION probe_geometry_columns() RETURNS text
    AS $$
DECLARE
	inserted integer;
	oldcount integer;
	probed integer;
	stale integer;
BEGIN

	SELECT count(*) INTO oldcount FROM geometry_columns;

	SELECT count(*) INTO probed
		FROM pg_class c, pg_attribute a, pg_type t, 
			pg_namespace n,
			pg_constraint sridcheck, pg_constraint typecheck

		WHERE t.typname = 'geometry'
		AND a.atttypid = t.oid
		AND a.attrelid = c.oid
		AND c.relnamespace = n.oid
		AND sridcheck.connamespace = n.oid
		AND typecheck.connamespace = n.oid

		AND sridcheck.conrelid = c.oid
		AND sridcheck.consrc LIKE '(srid('||a.attname||') = %)'
		AND typecheck.conrelid = c.oid
		AND typecheck.consrc LIKE
	'((geometrytype('||a.attname||') = ''%''::text) OR (% IS NULL))'
		;

	INSERT INTO geometry_columns SELECT
		''::varchar as f_table_catalogue,
		n.nspname::varchar as f_table_schema,
		c.relname::varchar as f_table_name,
		a.attname::varchar as f_geometry_column,
		2 as coord_dimension,
		trim(both  ' =)' from substr(sridcheck.consrc,
			strpos(sridcheck.consrc, '=')))::integer as srid,
		trim(both ' =)''' from substr(typecheck.consrc, 
			strpos(typecheck.consrc, '='),
			strpos(typecheck.consrc, '::')-
			strpos(typecheck.consrc, '=')
			))::varchar as type

		FROM pg_class c, pg_attribute a, pg_type t, 
			pg_namespace n,
			pg_constraint sridcheck, pg_constraint typecheck
		WHERE t.typname = 'geometry'
		AND a.atttypid = t.oid
		AND a.attrelid = c.oid
		AND c.relnamespace = n.oid
		AND sridcheck.connamespace = n.oid
		AND typecheck.connamespace = n.oid
		AND sridcheck.conrelid = c.oid
		AND sridcheck.consrc LIKE '(srid('||a.attname||') = %)'
		AND typecheck.conrelid = c.oid
		AND typecheck.consrc LIKE
	'((geometrytype('||a.attname||') = ''%''::text) OR (% IS NULL))'

                AND NOT EXISTS (
                        SELECT oid FROM geometry_columns gc
                        WHERE c.relname::varchar = gc.f_table_name
                        AND n.nspname::varchar = gc.f_table_schema
                        AND a.attname::varchar = gc.f_geometry_column
                );

	GET DIAGNOSTICS inserted = ROW_COUNT;

	IF oldcount > probed THEN
		stale = oldcount-probed;
	ELSE
		stale = 0;
	END IF;

        RETURN 'probed:'||probed::text||
		' inserted:'||inserted::text||
		' conflicts:'||(probed-inserted)::text||
		' stale:'||stale::text;
END

$$
    LANGUAGE plpgsql;


ALTER FUNCTION public.probe_geometry_columns() OWNER TO ortelius;

--
-- Name: relate(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION relate(geometry, geometry) RETURNS text
    AS '$libdir/liblwgeom', 'relate_full'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.relate(geometry, geometry) OWNER TO ortelius;

--
-- Name: relate(geometry, geometry, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION relate(geometry, geometry, text) RETURNS boolean
    AS '$libdir/liblwgeom', 'relate_pattern'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.relate(geometry, geometry, text) OWNER TO ortelius;

--
-- Name: removepoint(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION removepoint(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_removepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.removepoint(geometry, integer) OWNER TO ortelius;

--
-- Name: rename_geometry_table_constraints(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION rename_geometry_table_constraints() RETURNS text
    AS $$
SELECT 'rename_geometry_table_constraint() is obsoleted'::text
$$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.rename_geometry_table_constraints() OWNER TO ortelius;

--
-- Name: reverse(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION reverse(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_reverse'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.reverse(geometry) OWNER TO ortelius;

--
-- Name: rotate(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION rotate(geometry, double precision) RETURNS geometry
    AS $_$SELECT rotateZ($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.rotate(geometry, double precision) OWNER TO ortelius;

--
-- Name: rotatex(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION rotatex(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1, 1, 0, 0, 0, cos($2), -sin($2), 0, sin($2), cos($2), 0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.rotatex(geometry, double precision) OWNER TO ortelius;

--
-- Name: rotatey(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION rotatey(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  cos($2), 0, sin($2),  0, 1, 0,  -sin($2), 0, cos($2), 0,  0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.rotatey(geometry, double precision) OWNER TO ortelius;

--
-- Name: rotatez(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION rotatez(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  cos($2), -sin($2), 0,  sin($2), cos($2), 0,  0, 0, 1,  0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.rotatez(geometry, double precision) OWNER TO ortelius;

--
-- Name: scale(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION scale(geometry, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $2, 0, 0,  0, $3, 0,  0, 0, $4,  0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.scale(geometry, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: scale(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION scale(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT scale($1, $2, $3, 1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.scale(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: se_envelopesintersect(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION se_envelopesintersect(geometry, geometry) RETURNS boolean
    AS $_$
	SELECT $1 && $2
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.se_envelopesintersect(geometry, geometry) OWNER TO ortelius;

--
-- Name: se_is3d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION se_is3d(geometry) RETURNS boolean
    AS $_$
    SELECT CASE ST_zmflag($1)
               WHEN 0 THEN false
               WHEN 1 THEN false
               WHEN 2 THEN true
               WHEN 3 THEN true
               ELSE false
           END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.se_is3d(geometry) OWNER TO ortelius;

--
-- Name: se_ismeasured(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION se_ismeasured(geometry) RETURNS boolean
    AS $_$
    SELECT CASE ST_zmflag($1)
               WHEN 0 THEN false
               WHEN 1 THEN true
               WHEN 2 THEN false
               WHEN 3 THEN true
               ELSE false
           END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.se_ismeasured(geometry) OWNER TO ortelius;

--
-- Name: se_locatealong(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION se_locatealong(geometry, double precision) RETURNS geometry
    AS $_$SELECT locate_between_measures($1, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.se_locatealong(geometry, double precision) OWNER TO ortelius;

--
-- Name: se_locatebetween(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION se_locatebetween(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_locate_between_m'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.se_locatebetween(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: se_m(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION se_m(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_m_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.se_m(geometry) OWNER TO ortelius;

--
-- Name: se_z(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION se_z(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_z_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.se_z(geometry) OWNER TO ortelius;

--
-- Name: segmentize(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION segmentize(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_segmentize2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.segmentize(geometry, double precision) OWNER TO ortelius;

--
-- Name: setfactor(chip, real); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION setfactor(chip, real) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_setFactor'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.setfactor(chip, real) OWNER TO ortelius;

--
-- Name: setpoint(geometry, integer, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION setpoint(geometry, integer, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_setpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.setpoint(geometry, integer, geometry) OWNER TO ortelius;

--
-- Name: setsrid(chip, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION setsrid(chip, integer) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_setSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.setsrid(chip, integer) OWNER TO ortelius;

--
-- Name: setsrid(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION setsrid(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_setSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.setsrid(geometry, integer) OWNER TO ortelius;

--
-- Name: shift_longitude(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION shift_longitude(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_longitude_shift'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.shift_longitude(geometry) OWNER TO ortelius;

--
-- Name: simplify(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION simplify(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_simplify2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.simplify(geometry, double precision) OWNER TO ortelius;

--
-- Name: snaptogrid(geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION snaptogrid(geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_snaptogrid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.snaptogrid(geometry, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: snaptogrid(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION snaptogrid(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT SnapToGrid($1, 0, 0, $2, $3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.snaptogrid(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: snaptogrid(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION snaptogrid(geometry, double precision) RETURNS geometry
    AS $_$SELECT SnapToGrid($1, 0, 0, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.snaptogrid(geometry, double precision) OWNER TO ortelius;

--
-- Name: snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_snaptogrid_pointoff'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: spheroid_in(cstring); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION spheroid_in(cstring) RETURNS spheroid
    AS '$libdir/liblwgeom', 'ellipsoid_in'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.spheroid_in(cstring) OWNER TO ortelius;

--
-- Name: spheroid_out(spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION spheroid_out(spheroid) RETURNS cstring
    AS '$libdir/liblwgeom', 'ellipsoid_out'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.spheroid_out(spheroid) OWNER TO ortelius;

--
-- Name: srid(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION srid(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.srid(chip) OWNER TO ortelius;

--
-- Name: srid(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION srid(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.srid(geometry) OWNER TO ortelius;

--
-- Name: st_addbbox(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_addbbox(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_addbbox(geometry) OWNER TO ortelius;

--
-- Name: st_addpoint(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_addpoint(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_addpoint(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_addpoint(geometry, geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_addpoint(geometry, geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_addpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_addpoint(geometry, geometry, integer) OWNER TO ortelius;

--
-- Name: st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_affine'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $2, $3, 0,  $4, $5, 0,  0, 0, 1,  $6, $7, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_affine(geometry, double precision, double precision, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_area(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_area(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_area_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_area(geometry) OWNER TO ortelius;

--
-- Name: st_area2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_area2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_area_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_area2d(geometry) OWNER TO ortelius;

--
-- Name: st_asbinary(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asbinary(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_asBinary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asbinary(geometry) OWNER TO ortelius;

--
-- Name: st_asbinary(geometry, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asbinary(geometry, text) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_asBinary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asbinary(geometry, text) OWNER TO ortelius;

--
-- Name: st_asewkb(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asewkb(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'WKBFromLWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asewkb(geometry) OWNER TO ortelius;

--
-- Name: st_asewkb(geometry, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asewkb(geometry, text) RETURNS bytea
    AS '$libdir/liblwgeom', 'WKBFromLWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asewkb(geometry, text) OWNER TO ortelius;

--
-- Name: st_asewkt(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asewkt(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asEWKT'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asewkt(geometry) OWNER TO ortelius;

--
-- Name: st_asgml(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asgml(geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsGML(2, $1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgml(geometry, integer) OWNER TO ortelius;

--
-- Name: st_asgml(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asgml(geometry) RETURNS text
    AS $_$SELECT _ST_AsGML(2, $1, 15)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgml(geometry) OWNER TO ortelius;

--
-- Name: st_asgml(integer, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asgml(integer, geometry) RETURNS text
    AS $_$SELECT _ST_AsGML($1, $2, 15)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgml(integer, geometry) OWNER TO ortelius;

--
-- Name: st_asgml(integer, geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asgml(integer, geometry, integer) RETURNS text
    AS $_$SELECT _ST_AsGML($1, $2, $3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_asgml(integer, geometry, integer) OWNER TO ortelius;

--
-- Name: st_ashexewkb(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_ashexewkb(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asHEXEWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ashexewkb(geometry) OWNER TO ortelius;

--
-- Name: st_ashexewkb(geometry, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_ashexewkb(geometry, text) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asHEXEWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ashexewkb(geometry, text) OWNER TO ortelius;

--
-- Name: st_askml(geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_askml(geometry, integer, integer) RETURNS text
    AS $_$SELECT AsUKML(transform($1,4326),$2,$3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_askml(geometry, integer, integer) OWNER TO ortelius;

--
-- Name: st_askml(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_askml(geometry, integer) RETURNS text
    AS $_$SELECT AsUKML(transform($1,4326),$2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_askml(geometry, integer) OWNER TO ortelius;

--
-- Name: st_askml(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_askml(geometry) RETURNS text
    AS $_$SELECT AsUKML(transform($1,4326))$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_askml(geometry) OWNER TO ortelius;

--
-- Name: st_assvg(geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_assvg(geometry, integer, integer) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_assvg(geometry, integer, integer) OWNER TO ortelius;

--
-- Name: st_assvg(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_assvg(geometry, integer) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_assvg(geometry, integer) OWNER TO ortelius;

--
-- Name: st_assvg(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_assvg(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'assvg_geometry'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_assvg(geometry) OWNER TO ortelius;

--
-- Name: st_astext(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_astext(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asText'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_astext(geometry) OWNER TO ortelius;

--
-- Name: st_asukml(geometry, integer, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asukml(geometry, integer, integer) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asKML'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asukml(geometry, integer, integer) OWNER TO ortelius;

--
-- Name: st_asukml(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asukml(geometry, integer) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asKML'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asukml(geometry, integer) OWNER TO ortelius;

--
-- Name: st_asukml(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_asukml(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_asKML'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_asukml(geometry) OWNER TO ortelius;

--
-- Name: st_azimuth(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_azimuth(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_azimuth'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_azimuth(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_bdmpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_bdmpolyfromtext(text, integer) RETURNS geometry
    AS $_$
DECLARE
	geomtext alias for $1;
	srid alias for $2;
	mline geometry;
	geom geometry;
BEGIN
	mline := MultiLineStringFromText(geomtext, srid);

	IF mline IS NULL
	THEN
		RAISE EXCEPTION 'Input is not a MultiLinestring';
	END IF;

	geom := multi(BuildArea(mline));

	RETURN geom;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_bdmpolyfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_bdpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_bdpolyfromtext(text, integer) RETURNS geometry
    AS $_$
DECLARE
	geomtext alias for $1;
	srid alias for $2;
	mline geometry;
	geom geometry;
BEGIN
	mline := MultiLineStringFromText(geomtext, srid);

	IF mline IS NULL
	THEN
		RAISE EXCEPTION 'Input is not a MultiLinestring';
	END IF;

	geom := BuildArea(mline);

	IF GeometryType(geom) != 'POLYGON'
	THEN
		RAISE EXCEPTION 'Input returns more then a single polygon, try using BdMPolyFromText instead';
	END IF;

	RETURN geom;
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_bdpolyfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_boundary(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_boundary(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'boundary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_boundary(geometry) OWNER TO ortelius;

--
-- Name: st_box(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box(geometry) RETURNS box
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box(geometry) OWNER TO ortelius;

--
-- Name: st_box(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box(box3d) RETURNS box
    AS '$libdir/liblwgeom', 'BOX3D_to_BOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box(box3d) OWNER TO ortelius;

--
-- Name: st_box2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d(geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d(geometry) OWNER TO ortelius;

--
-- Name: st_box2d(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d(box3d) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX3D_to_BOX2DFLOAT4'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d(box3d) OWNER TO ortelius;

--
-- Name: st_box2d_contain(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_contain(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_contain'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_contain(box2d, box2d) OWNER TO ortelius;

--
-- Name: st_box2d_contained(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_contained(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_contained'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_contained(box2d, box2d) OWNER TO ortelius;

--
-- Name: st_box2d_intersects(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_intersects(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_intersects'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_intersects(box2d, box2d) OWNER TO ortelius;

--
-- Name: st_box2d_left(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_left(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_left'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_left(box2d, box2d) OWNER TO ortelius;

--
-- Name: st_box2d_overlap(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_overlap(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overlap'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_overlap(box2d, box2d) OWNER TO ortelius;

--
-- Name: st_box2d_overleft(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_overleft(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overleft'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_overleft(box2d, box2d) OWNER TO ortelius;

--
-- Name: st_box2d_overright(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_overright(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_overright'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_overright(box2d, box2d) OWNER TO ortelius;

--
-- Name: st_box2d_right(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_right(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_right'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_right(box2d, box2d) OWNER TO ortelius;

--
-- Name: st_box2d_same(box2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box2d_same(box2d, box2d) RETURNS boolean
    AS '$libdir/liblwgeom', 'BOX2D_same'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box2d_same(box2d, box2d) OWNER TO ortelius;

--
-- Name: st_box3d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box3d(geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'LWGEOM_to_BOX3D'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box3d(geometry) OWNER TO ortelius;

--
-- Name: st_box3d(box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_box3d(box2d) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_to_BOX3D'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_box3d(box2d) OWNER TO ortelius;

--
-- Name: st_buffer(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_buffer(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'buffer'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_buffer(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_buffer(geometry, double precision, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_buffer(geometry, double precision, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'buffer'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_buffer(geometry, double precision, integer) OWNER TO ortelius;

--
-- Name: st_build_histogram2d(histogram2d, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_build_histogram2d(histogram2d, text, text) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'build_lwhistogram2d'
    LANGUAGE c STABLE STRICT;


ALTER FUNCTION public.st_build_histogram2d(histogram2d, text, text) OWNER TO ortelius;

--
-- Name: st_build_histogram2d(histogram2d, text, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_build_histogram2d(histogram2d, text, text, text) RETURNS histogram2d
    AS $_$
BEGIN
	EXECUTE 'SET local search_path = '||$2||',public';
	RETURN public.build_histogram2d($1,$3,$4);
END
$_$
    LANGUAGE plpgsql STABLE STRICT;


ALTER FUNCTION public.st_build_histogram2d(histogram2d, text, text, text) OWNER TO ortelius;

--
-- Name: st_buildarea(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_buildarea(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_buildarea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_buildarea(geometry) OWNER TO ortelius;

--
-- Name: st_bytea(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_bytea(geometry) RETURNS bytea
    AS '$libdir/liblwgeom', 'LWGEOM_to_bytea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_bytea(geometry) OWNER TO ortelius;

--
-- Name: st_cache_bbox(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_cache_bbox() RETURNS "trigger"
    AS '$libdir/liblwgeom', 'cache_bbox'
    LANGUAGE c;


ALTER FUNCTION public.st_cache_bbox() OWNER TO ortelius;

--
-- Name: st_centroid(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_centroid(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'centroid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_centroid(geometry) OWNER TO ortelius;

--
-- Name: st_collect(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_collect(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_collect(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_collect_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_collect_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_collect_garray(geometry[]) OWNER TO ortelius;

--
-- Name: st_collector(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_collector(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_collect'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_collector(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_combine_bbox(box2d, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_combine_bbox(box2d, geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_combine'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_combine_bbox(box2d, geometry) OWNER TO ortelius;

--
-- Name: st_combine_bbox(box3d, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_combine_bbox(box3d, geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_combine'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_combine_bbox(box3d, geometry) OWNER TO ortelius;

--
-- Name: st_compression(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_compression(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getCompression'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_compression(chip) OWNER TO ortelius;

--
-- Name: st_contains(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_contains(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Contains($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_contains(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_convexhull(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_convexhull(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'convexhull'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_convexhull(geometry) OWNER TO ortelius;

--
-- Name: st_coorddim(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_coorddim(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_ndims'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_coorddim(geometry) OWNER TO ortelius;

--
-- Name: st_coveredby(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_coveredby(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_CoveredBy($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_coveredby(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_covers(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_covers(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Covers($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_covers(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_create_histogram2d(box2d, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_create_histogram2d(box2d, integer) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'create_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_create_histogram2d(box2d, integer) OWNER TO ortelius;

--
-- Name: st_crosses(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_crosses(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Crosses($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_crosses(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_curvetoline(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_curvetoline(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_curve_segmentize'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_curvetoline(geometry, integer) OWNER TO ortelius;

--
-- Name: st_curvetoline(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_curvetoline(geometry) RETURNS geometry
    AS $_$SELECT ST_CurveToLine($1, 32)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_curvetoline(geometry) OWNER TO ortelius;

--
-- Name: st_datatype(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_datatype(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getDatatype'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_datatype(chip) OWNER TO ortelius;

--
-- Name: st_difference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_difference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'difference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_difference(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_dimension(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_dimension(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_dimension'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_dimension(geometry) OWNER TO ortelius;

--
-- Name: st_disjoint(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_disjoint(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'disjoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_disjoint(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_distance(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_distance(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_mindistance2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_distance(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_distance_sphere(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_distance_sphere(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_distance_sphere'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_distance_sphere(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_distance_spheroid(geometry, geometry, spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_distance_spheroid(geometry, geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_distance_ellipsoid_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_distance_spheroid(geometry, geometry, spheroid) OWNER TO ortelius;

--
-- Name: st_dropbbox(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_dropbbox(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_dropBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_dropbbox(geometry) OWNER TO ortelius;

--
-- Name: st_dump(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_dump(geometry) RETURNS SETOF geometry_dump
    AS '$libdir/liblwgeom', 'LWGEOM_dump'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_dump(geometry) OWNER TO ortelius;

--
-- Name: st_dumprings(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_dumprings(geometry) RETURNS SETOF geometry_dump
    AS '$libdir/liblwgeom', 'LWGEOM_dump_rings'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_dumprings(geometry) OWNER TO ortelius;

--
-- Name: st_dwithin(geometry, geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_dwithin(geometry, geometry, double precision) RETURNS boolean
    AS $_$SELECT $1 && ST_Expand($2,$3) AND $2 && ST_Expand($1,$3) AND ST_Distance($1, $2) < $3$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_dwithin(geometry, geometry, double precision) OWNER TO ortelius;

--
-- Name: st_endpoint(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_endpoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_endpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_endpoint(geometry) OWNER TO ortelius;

--
-- Name: st_envelope(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_envelope(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_envelope'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_envelope(geometry) OWNER TO ortelius;

--
-- Name: st_equals(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_equals(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'geomequals'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_equals(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_estimate_histogram2d(histogram2d, box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_estimate_histogram2d(histogram2d, box2d) RETURNS double precision
    AS '$libdir/liblwgeom', 'estimate_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_estimate_histogram2d(histogram2d, box2d) OWNER TO ortelius;

--
-- Name: st_estimated_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_estimated_extent(text, text, text) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_estimated_extent'
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER;


ALTER FUNCTION public.st_estimated_extent(text, text, text) OWNER TO ortelius;

--
-- Name: st_estimated_extent(text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_estimated_extent(text, text) RETURNS box2d
    AS '$libdir/liblwgeom', 'LWGEOM_estimated_extent'
    LANGUAGE c IMMUTABLE STRICT SECURITY DEFINER;


ALTER FUNCTION public.st_estimated_extent(text, text) OWNER TO ortelius;

--
-- Name: st_expand(box3d, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_expand(box3d, double precision) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_expand(box3d, double precision) OWNER TO ortelius;

--
-- Name: st_expand(box2d, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_expand(box2d, double precision) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_expand(box2d, double precision) OWNER TO ortelius;

--
-- Name: st_expand(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_expand(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_expand'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_expand(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_explode_histogram2d(histogram2d, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_explode_histogram2d(histogram2d, text) RETURNS histogram2d
    AS '$libdir/liblwgeom', 'explode_lwhistogram2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_explode_histogram2d(histogram2d, text) OWNER TO ortelius;

--
-- Name: st_exteriorring(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_exteriorring(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_exteriorring_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_exteriorring(geometry) OWNER TO ortelius;

--
-- Name: st_factor(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_factor(chip) RETURNS real
    AS '$libdir/liblwgeom', 'CHIP_getFactor'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_factor(chip) OWNER TO ortelius;

--
-- Name: st_find_extent(text, text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_find_extent(text, text, text) RETURNS box2d
    AS $_$
DECLARE
	schemaname alias for $1;
	tablename alias for $2;
	columnname alias for $3;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT extent("'||columnname||'") FROM "'||schemaname||'"."'||tablename||'"' LOOP
		return myrec.extent;
	END LOOP; 
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_find_extent(text, text, text) OWNER TO ortelius;

--
-- Name: st_find_extent(text, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_find_extent(text, text) RETURNS box2d
    AS $_$
DECLARE
	tablename alias for $1;
	columnname alias for $2;
	myrec RECORD;

BEGIN
	FOR myrec IN EXECUTE 'SELECT extent("'||columnname||'") FROM "'||tablename||'"' LOOP
		return myrec.extent;
	END LOOP; 
END;
$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_find_extent(text, text) OWNER TO ortelius;

--
-- Name: st_force_2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_force_2d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_2d(geometry) OWNER TO ortelius;

--
-- Name: st_force_3d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_force_3d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dz'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_3d(geometry) OWNER TO ortelius;

--
-- Name: st_force_3dm(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_force_3dm(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dm'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_3dm(geometry) OWNER TO ortelius;

--
-- Name: st_force_3dz(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_force_3dz(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_3dz'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_3dz(geometry) OWNER TO ortelius;

--
-- Name: st_force_4d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_force_4d(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_4d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_4d(geometry) OWNER TO ortelius;

--
-- Name: st_force_collection(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_force_collection(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_force_collection(geometry) OWNER TO ortelius;

--
-- Name: st_forcerhr(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_forcerhr(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_forceRHR_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_forcerhr(geometry) OWNER TO ortelius;

--
-- Name: st_geom_accum(geometry[], geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geom_accum(geometry[], geometry) RETURNS geometry[]
    AS '$libdir/liblwgeom', 'LWGEOM_accum'
    LANGUAGE c IMMUTABLE;


ALTER FUNCTION public.st_geom_accum(geometry[], geometry) OWNER TO ortelius;

--
-- Name: st_geomcollfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomcollfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomcollfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_geomcollfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomcollfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomcollfromtext(text) OWNER TO ortelius;

--
-- Name: st_geomcollfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomcollfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromWKB($1, $2)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomcollfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_geomcollfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomcollfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromWKB($1)) = 'GEOMETRYCOLLECTION'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomcollfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_geometry(box2d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry(box2d) RETURNS geometry
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(box2d) OWNER TO ortelius;

--
-- Name: st_geometry(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry(box3d) RETURNS geometry
    AS '$libdir/liblwgeom', 'BOX3D_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(box3d) OWNER TO ortelius;

--
-- Name: st_geometry(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'parse_WKT_lwgeom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(text) OWNER TO ortelius;

--
-- Name: st_geometry(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry(chip) RETURNS geometry
    AS '$libdir/liblwgeom', 'CHIP_to_LWGEOM'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(chip) OWNER TO ortelius;

--
-- Name: st_geometry(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_bytea'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry(bytea) OWNER TO ortelius;

--
-- Name: st_geometry_above(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_above(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_above'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_above(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_below(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_below(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_below'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_below(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_cmp(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_cmp(geometry, geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'lwgeom_cmp'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_cmp(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_contain(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_contain(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_contain'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_contain(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_contained(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_contained(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_contained'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_contained(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_eq(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_eq(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_eq'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_eq(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_ge(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_ge(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_ge'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_ge(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_gt(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_gt(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_gt'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_gt(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_le(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_le(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_le'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_le(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_left(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_left(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_left'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_left(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_lt(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_lt(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'lwgeom_lt'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_lt(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_overabove(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_overabove(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overabove'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overabove(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_overbelow(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_overbelow(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overbelow'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overbelow(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_overlap(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_overlap(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overlap'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overlap(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_overleft(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_overleft(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overleft'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overleft(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_overright(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_overright(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_overright'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_overright(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_right(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_right(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_right'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_right(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometry_same(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometry_same(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_same'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometry_same(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_geometryfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometryfromtext(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometryfromtext(text) OWNER TO ortelius;

--
-- Name: st_geometryfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometryfromtext(text, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometryfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_geometryn(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometryn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_geometryn_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometryn(geometry, integer) OWNER TO ortelius;

--
-- Name: st_geometrytype(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geometrytype(geometry) RETURNS text
    AS $_$
    DECLARE
        gtype text := geometrytype($1);
    BEGIN
        IF (gtype IN ('POINT', 'POINTM')) THEN
            gtype := 'Point';
        ELSIF (gtype IN ('LINESTRING', 'LINESTRINGM')) THEN
            gtype := 'LineString';
        ELSIF (gtype IN ('POLYGON', 'POLYGONM')) THEN
            gtype := 'Polygon';
        ELSIF (gtype IN ('MULTIPOINT', 'MULTIPOINTM')) THEN
            gtype := 'MultiPoint';
        ELSIF (gtype IN ('MULTILINESTRING', 'MULTILINESTRINGM')) THEN
            gtype := 'MultiLineString';
        ELSIF (gtype IN ('MULTIPOLYGON', 'MULTIPOLYGONM')) THEN
            gtype := 'MultiPolygon';
        ELSE
            gtype := 'Geometry';
        END IF;
        RETURN 'ST_' || gtype;
    END
	$_$
    LANGUAGE plpgsql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geometrytype(geometry) OWNER TO ortelius;

--
-- Name: st_geomfromewkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomfromewkb(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOMFromWKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromewkb(bytea) OWNER TO ortelius;

--
-- Name: st_geomfromewkt(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomfromewkt(text) RETURNS geometry
    AS '$libdir/liblwgeom', 'parse_WKT_lwgeom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromewkt(text) OWNER TO ortelius;

--
-- Name: st_geomfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomfromtext(text) RETURNS geometry
    AS $_$SELECT geometryfromtext($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromtext(text) OWNER TO ortelius;

--
-- Name: st_geomfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomfromtext(text, integer) RETURNS geometry
    AS $_$SELECT geometryfromtext($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_geomfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomfromwkb(bytea) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_from_WKB'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_geomfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_geomfromwkb(bytea, integer) RETURNS geometry
    AS $_$SELECT setSRID(GeomFromWKB($1), $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_geomfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_hasarc(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_hasarc(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_has_arc'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_hasarc(geometry) OWNER TO ortelius;

--
-- Name: st_hasbbox(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_hasbbox(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_hasBBOX'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_hasbbox(geometry) OWNER TO ortelius;

--
-- Name: st_height(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_height(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getHeight'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_height(chip) OWNER TO ortelius;

--
-- Name: st_interiorringn(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_interiorringn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_interiorringn_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_interiorringn(geometry, integer) OWNER TO ortelius;

--
-- Name: st_intersection(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_intersection(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'intersection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_intersection(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_intersects(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_intersects(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Intersects($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_intersects(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_isclosed(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_isclosed(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_isclosed_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_isclosed(geometry) OWNER TO ortelius;

--
-- Name: st_isempty(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_isempty(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_isempty'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_isempty(geometry) OWNER TO ortelius;

--
-- Name: st_isring(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_isring(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'isring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_isring(geometry) OWNER TO ortelius;

--
-- Name: st_issimple(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_issimple(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'issimple'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_issimple(geometry) OWNER TO ortelius;

--
-- Name: st_isvalid(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_isvalid(geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'isvalid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_isvalid(geometry) OWNER TO ortelius;

--
-- Name: st_length(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_length(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length(geometry) OWNER TO ortelius;

--
-- Name: st_length2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_length2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length2d(geometry) OWNER TO ortelius;

--
-- Name: st_length2d_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_length2d_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length2d_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length2d_spheroid(geometry, spheroid) OWNER TO ortelius;

--
-- Name: st_length3d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_length3d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length3d(geometry) OWNER TO ortelius;

--
-- Name: st_length3d_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_length3d_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length3d_spheroid(geometry, spheroid) OWNER TO ortelius;

--
-- Name: st_length_spheroid(geometry, spheroid); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_length_spheroid(geometry, spheroid) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_length_ellipsoid_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_length_spheroid(geometry, spheroid) OWNER TO ortelius;

--
-- Name: st_line_interpolate_point(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_line_interpolate_point(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_interpolate_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_line_interpolate_point(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_line_locate_point(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_line_locate_point(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_line_locate_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_line_locate_point(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_line_substring(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_line_substring(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_substring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_line_substring(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_linefrommultipoint(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_linefrommultipoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_from_mpoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefrommultipoint(geometry) OWNER TO ortelius;

--
-- Name: st_linefromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_linefromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'LINESTRING'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefromtext(text) OWNER TO ortelius;

--
-- Name: st_linefromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_linefromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'LINESTRING'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_linefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_linefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_linefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_linefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'LINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linefromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_linemerge(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_linemerge(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'linemerge'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_linemerge(geometry) OWNER TO ortelius;

--
-- Name: st_linestringfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_linestringfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'LINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linestringfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_linestringfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_linestringfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'LINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_linestringfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_linetocurve(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_linetocurve(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_line_desegmentize'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_linetocurve(geometry) OWNER TO ortelius;

--
-- Name: st_locate_along_measure(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_locate_along_measure(geometry, double precision) RETURNS geometry
    AS $_$SELECT locate_between_measures($1, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_locate_along_measure(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_locate_between_measures(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_locate_between_measures(geometry, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_locate_between_m'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_locate_between_measures(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_m(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_m(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_m_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_m(geometry) OWNER TO ortelius;

--
-- Name: st_makebox2d(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_makebox2d(geometry, geometry) RETURNS box2d
    AS '$libdir/liblwgeom', 'BOX2DFLOAT4_construct'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makebox2d(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_makebox3d(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_makebox3d(geometry, geometry) RETURNS box3d
    AS '$libdir/liblwgeom', 'BOX3D_construct'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makebox3d(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_makeline(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_makeline(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makeline'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makeline(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_makeline_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_makeline_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makeline_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makeline_garray(geometry[]) OWNER TO ortelius;

--
-- Name: st_makepoint(double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_makepoint(double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepoint(double precision, double precision) OWNER TO ortelius;

--
-- Name: st_makepoint(double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_makepoint(double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepoint(double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_makepoint(double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_makepoint(double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepoint(double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_makepolygon(geometry, geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_makepolygon(geometry, geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepolygon(geometry, geometry[]) OWNER TO ortelius;

--
-- Name: st_makepolygon(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_makepolygon(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_makepolygon(geometry) OWNER TO ortelius;

--
-- Name: st_max_distance(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_max_distance(geometry, geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_maxdistance2d_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_max_distance(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_mem_size(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mem_size(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_mem_size'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_mem_size(geometry) OWNER TO ortelius;

--
-- Name: st_mlinefromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mlinefromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE
	WHEN geometrytype(GeomFromText($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mlinefromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_mlinefromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mlinefromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTILINESTRING'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mlinefromtext(text) OWNER TO ortelius;

--
-- Name: st_mlinefromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mlinefromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mlinefromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_mlinefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mlinefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mlinefromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_mpointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mpointfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'MULTIPOINT'
	THEN GeomFromText($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpointfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_mpointfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mpointfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTIPOINT'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpointfromtext(text) OWNER TO ortelius;

--
-- Name: st_mpointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mpointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpointfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_mpointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mpointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpointfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_mpolyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mpolyfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromText($1,$2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpolyfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_mpolyfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mpolyfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'MULTIPOLYGON'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpolyfromtext(text) OWNER TO ortelius;

--
-- Name: st_mpolyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mpolyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpolyfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_mpolyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_mpolyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_mpolyfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_multi(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multi(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_force_multi'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_multi(geometry) OWNER TO ortelius;

--
-- Name: st_multilinefromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multilinefromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTILINESTRING'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multilinefromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_multilinestringfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multilinestringfromtext(text) RETURNS geometry
    AS $_$SELECT MLineFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multilinestringfromtext(text) OWNER TO ortelius;

--
-- Name: st_multilinestringfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multilinestringfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MLineFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multilinestringfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_multipointfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multipointfromtext(text) RETURNS geometry
    AS $_$SELECT MPointFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipointfromtext(text) OWNER TO ortelius;

--
-- Name: st_multipointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multipointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'MULTIPOINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipointfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_multipointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multipointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipointfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_multipolyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multipolyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipolyfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_multipolyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multipolyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'MULTIPOLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipolyfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_multipolygonfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multipolygonfromtext(text, integer) RETURNS geometry
    AS $_$SELECT MPolyFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipolygonfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_multipolygonfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_multipolygonfromtext(text) RETURNS geometry
    AS $_$SELECT MPolyFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_multipolygonfromtext(text) OWNER TO ortelius;

--
-- Name: st_ndims(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_ndims(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_ndims'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ndims(geometry) OWNER TO ortelius;

--
-- Name: st_noop(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_noop(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_noop'
    LANGUAGE c STRICT;


ALTER FUNCTION public.st_noop(geometry) OWNER TO ortelius;

--
-- Name: st_npoints(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_npoints(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_npoints'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_npoints(geometry) OWNER TO ortelius;

--
-- Name: st_nrings(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_nrings(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_nrings'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_nrings(geometry) OWNER TO ortelius;

--
-- Name: st_numgeometries(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_numgeometries(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numgeometries_collection'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_numgeometries(geometry) OWNER TO ortelius;

--
-- Name: st_numinteriorring(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_numinteriorring(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numinteriorrings_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_numinteriorring(geometry) OWNER TO ortelius;

--
-- Name: st_numinteriorrings(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_numinteriorrings(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numinteriorrings_polygon'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_numinteriorrings(geometry) OWNER TO ortelius;

--
-- Name: st_numpoints(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_numpoints(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_numpoints_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_numpoints(geometry) OWNER TO ortelius;

--
-- Name: st_orderingequals(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_orderingequals(geometry, geometry) RETURNS boolean
    AS $_$
    SELECT $1 && $2 AND $1 ~= $2
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_orderingequals(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_overlaps(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_overlaps(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Overlaps($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_overlaps(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_perimeter(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_perimeter(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter2d_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_perimeter(geometry) OWNER TO ortelius;

--
-- Name: st_perimeter2d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_perimeter2d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter2d_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_perimeter2d(geometry) OWNER TO ortelius;

--
-- Name: st_perimeter3d(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_perimeter3d(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_perimeter_poly'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_perimeter3d(geometry) OWNER TO ortelius;

--
-- Name: st_point(double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_point(double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_makepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_point(double precision, double precision) OWNER TO ortelius;

--
-- Name: st_point_inside_circle(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_point_inside_circle(geometry, double precision, double precision, double precision) RETURNS boolean
    AS '$libdir/liblwgeom', 'LWGEOM_inside_circle_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_point_inside_circle(geometry, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_pointfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_pointfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'POINT'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointfromtext(text) OWNER TO ortelius;

--
-- Name: st_pointfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_pointfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'POINT'
	THEN GeomFromText($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_pointfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_pointfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'POINT'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_pointfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_pointfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POINT'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_pointn(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_pointn(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_pointn_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointn(geometry, integer) OWNER TO ortelius;

--
-- Name: st_pointonsurface(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_pointonsurface(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'pointonsurface'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_pointonsurface(geometry) OWNER TO ortelius;

--
-- Name: st_polyfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polyfromtext(text) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1)) = 'POLYGON'
	THEN GeomFromText($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polyfromtext(text) OWNER TO ortelius;

--
-- Name: st_polyfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polyfromtext(text, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromText($1, $2)) = 'POLYGON'
	THEN GeomFromText($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polyfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_polyfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polyfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1, $2)) = 'POLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polyfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_polyfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polyfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polyfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_polygon(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polygon(geometry, integer) RETURNS geometry
    AS $_$
	SELECT setSRID(makepolygon($1), $2)
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygon(geometry, integer) OWNER TO ortelius;

--
-- Name: st_polygonfromtext(text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polygonfromtext(text, integer) RETURNS geometry
    AS $_$SELECT PolyFromText($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonfromtext(text, integer) OWNER TO ortelius;

--
-- Name: st_polygonfromtext(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polygonfromtext(text) RETURNS geometry
    AS $_$SELECT PolyFromText($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonfromtext(text) OWNER TO ortelius;

--
-- Name: st_polygonfromwkb(bytea, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polygonfromwkb(bytea, integer) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1,$2)) = 'POLYGON'
	THEN GeomFromWKB($1, $2)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonfromwkb(bytea, integer) OWNER TO ortelius;

--
-- Name: st_polygonfromwkb(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polygonfromwkb(bytea) RETURNS geometry
    AS $_$
	SELECT CASE WHEN geometrytype(GeomFromWKB($1)) = 'POLYGON'
	THEN GeomFromWKB($1)
	ELSE NULL END
	$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonfromwkb(bytea) OWNER TO ortelius;

--
-- Name: st_polygonize_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_polygonize_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'polygonize_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_polygonize_garray(geometry[]) OWNER TO ortelius;

--
-- Name: st_postgis_gist_joinsel(internal, oid, internal, smallint); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_postgis_gist_joinsel(internal, oid, internal, smallint) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_gist_joinsel'
    LANGUAGE c;


ALTER FUNCTION public.st_postgis_gist_joinsel(internal, oid, internal, smallint) OWNER TO ortelius;

--
-- Name: st_postgis_gist_sel(internal, oid, internal, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_postgis_gist_sel(internal, oid, internal, integer) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_gist_sel'
    LANGUAGE c;


ALTER FUNCTION public.st_postgis_gist_sel(internal, oid, internal, integer) OWNER TO ortelius;

--
-- Name: st_relate(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_relate(geometry, geometry) RETURNS text
    AS '$libdir/liblwgeom', 'relate_full'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_relate(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_relate(geometry, geometry, text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_relate(geometry, geometry, text) RETURNS boolean
    AS '$libdir/liblwgeom', 'relate_pattern'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_relate(geometry, geometry, text) OWNER TO ortelius;

--
-- Name: st_removepoint(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_removepoint(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_removepoint'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_removepoint(geometry, integer) OWNER TO ortelius;

--
-- Name: st_reverse(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_reverse(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_reverse'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_reverse(geometry) OWNER TO ortelius;

--
-- Name: st_rotate(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_rotate(geometry, double precision) RETURNS geometry
    AS $_$SELECT rotateZ($1, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_rotate(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_rotatex(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_rotatex(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1, 1, 0, 0, 0, cos($2), -sin($2), 0, sin($2), cos($2), 0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_rotatex(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_rotatey(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_rotatey(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  cos($2), 0, sin($2),  0, 1, 0,  -sin($2), 0, cos($2), 0,  0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_rotatey(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_rotatez(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_rotatez(geometry, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  cos($2), -sin($2), 0,  sin($2), cos($2), 0,  0, 0, 1,  0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_rotatez(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_scale(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_scale(geometry, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $2, 0, 0,  0, $3, 0,  0, 0, $4,  0, 0, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_scale(geometry, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_scale(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_scale(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT scale($1, $2, $3, 1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_scale(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_segmentize(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_segmentize(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_segmentize2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_segmentize(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_setfactor(chip, real); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_setfactor(chip, real) RETURNS chip
    AS '$libdir/liblwgeom', 'CHIP_setFactor'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_setfactor(chip, real) OWNER TO ortelius;

--
-- Name: st_setpoint(geometry, integer, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_setpoint(geometry, integer, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_setpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_setpoint(geometry, integer, geometry) OWNER TO ortelius;

--
-- Name: st_setsrid(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_setsrid(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_setSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_setsrid(geometry, integer) OWNER TO ortelius;

--
-- Name: st_shift_longitude(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_shift_longitude(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_longitude_shift'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_shift_longitude(geometry) OWNER TO ortelius;

--
-- Name: st_simplify(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_simplify(geometry, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_simplify2d'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_simplify(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_snaptogrid(geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_snaptogrid(geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_snaptogrid'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_snaptogrid(geometry, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_snaptogrid(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_snaptogrid(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT SnapToGrid($1, 0, 0, $2, $3)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_snaptogrid(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_snaptogrid(geometry, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_snaptogrid(geometry, double precision) RETURNS geometry
    AS $_$SELECT SnapToGrid($1, 0, 0, $2, $2)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_snaptogrid(geometry, double precision) OWNER TO ortelius;

--
-- Name: st_snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_snaptogrid_pointoff'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_snaptogrid(geometry, geometry, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_srid(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_srid(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_srid(chip) OWNER TO ortelius;

--
-- Name: st_srid(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_srid(geometry) RETURNS integer
    AS '$libdir/liblwgeom', 'LWGEOM_getSRID'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_srid(geometry) OWNER TO ortelius;

--
-- Name: st_startpoint(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_startpoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_startpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_startpoint(geometry) OWNER TO ortelius;

--
-- Name: st_summary(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_summary(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_summary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_summary(geometry) OWNER TO ortelius;

--
-- Name: st_symdifference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_symdifference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'symdifference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_symdifference(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_symmetricdifference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_symmetricdifference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'symdifference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_symmetricdifference(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_text(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_text(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_to_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_text(geometry) OWNER TO ortelius;

--
-- Name: st_text(boolean); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_text(boolean) RETURNS text
    AS '$libdir/liblwgeom', 'BOOL_to_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_text(boolean) OWNER TO ortelius;

--
-- Name: st_touches(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_touches(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Touches($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_touches(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_transform(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_transform(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'transform'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_transform(geometry, integer) OWNER TO ortelius;

--
-- Name: st_translate(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_translate(geometry, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1, 1, 0, 0, 0, 1, 0, 0, 0, 1, $2, $3, $4)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_translate(geometry, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_translate(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_translate(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT translate($1, $2, $3, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_translate(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_transscale(geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_transscale(geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $4, 0, 0,  0, $5, 0, 
		0, 0, 1,  $2 * $4, $3 * $5, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_transscale(geometry, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: st_union(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_union(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'geomunion'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_union(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_unite_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_unite_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'unite_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_unite_garray(geometry[]) OWNER TO ortelius;

--
-- Name: st_width(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_width(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getWidth'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_width(chip) OWNER TO ortelius;

--
-- Name: st_within(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_within(geometry, geometry) RETURNS boolean
    AS $_$SELECT $1 && $2 AND _ST_Within($1,$2)$_$
    LANGUAGE sql IMMUTABLE;


ALTER FUNCTION public.st_within(geometry, geometry) OWNER TO ortelius;

--
-- Name: st_wkbtosql(bytea); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_wkbtosql(bytea) RETURNS geometry
    AS $_$SELECT GeomFromWKB($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_wkbtosql(bytea) OWNER TO ortelius;

--
-- Name: st_wkttosql(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_wkttosql(text) RETURNS geometry
    AS $_$SELECT geometryfromtext($1)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.st_wkttosql(text) OWNER TO ortelius;

--
-- Name: st_x(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_x(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_x_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_x(geometry) OWNER TO ortelius;

--
-- Name: st_xmax(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_xmax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_xmax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_xmax(box3d) OWNER TO ortelius;

--
-- Name: st_xmin(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_xmin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_xmin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_xmin(box3d) OWNER TO ortelius;

--
-- Name: st_y(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_y(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_y_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_y(geometry) OWNER TO ortelius;

--
-- Name: st_ymax(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_ymax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_ymax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ymax(box3d) OWNER TO ortelius;

--
-- Name: st_ymin(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_ymin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_ymin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_ymin(box3d) OWNER TO ortelius;

--
-- Name: st_z(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_z(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_z_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_z(geometry) OWNER TO ortelius;

--
-- Name: st_zmax(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_zmax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_zmax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_zmax(box3d) OWNER TO ortelius;

--
-- Name: st_zmflag(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_zmflag(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_zmflag'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_zmflag(geometry) OWNER TO ortelius;

--
-- Name: st_zmin(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION st_zmin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_zmin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.st_zmin(box3d) OWNER TO ortelius;

--
-- Name: startpoint(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION startpoint(geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'LWGEOM_startpoint_linestring'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.startpoint(geometry) OWNER TO ortelius;

--
-- Name: summary(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION summary(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_summary'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.summary(geometry) OWNER TO ortelius;

--
-- Name: symdifference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION symdifference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'symdifference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.symdifference(geometry, geometry) OWNER TO ortelius;

--
-- Name: symmetricdifference(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION symmetricdifference(geometry, geometry) RETURNS geometry
    AS '$libdir/liblwgeom', 'symdifference'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.symmetricdifference(geometry, geometry) OWNER TO ortelius;

--
-- Name: text(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION text(geometry) RETURNS text
    AS '$libdir/liblwgeom', 'LWGEOM_to_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.text(geometry) OWNER TO ortelius;

--
-- Name: text(boolean); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION text(boolean) RETURNS text
    AS '$libdir/liblwgeom', 'BOOL_to_text'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.text(boolean) OWNER TO ortelius;

--
-- Name: touches(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION touches(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'touches'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.touches(geometry, geometry) OWNER TO ortelius;

--
-- Name: transform(geometry, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION transform(geometry, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'transform'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.transform(geometry, integer) OWNER TO ortelius;

--
-- Name: transform_geometry(geometry, text, text, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION transform_geometry(geometry, text, text, integer) RETURNS geometry
    AS '$libdir/liblwgeom', 'transform_geom'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.transform_geometry(geometry, text, text, integer) OWNER TO ortelius;

--
-- Name: translate(geometry, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION translate(geometry, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1, 1, 0, 0, 0, 1, 0, 0, 0, 1, $2, $3, $4)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.translate(geometry, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: translate(geometry, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION translate(geometry, double precision, double precision) RETURNS geometry
    AS $_$SELECT translate($1, $2, $3, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.translate(geometry, double precision, double precision) OWNER TO ortelius;

--
-- Name: transscale(geometry, double precision, double precision, double precision, double precision); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION transscale(geometry, double precision, double precision, double precision, double precision) RETURNS geometry
    AS $_$SELECT affine($1,  $4, 0, 0,  0, $5, 0, 
		0, 0, 1,  $2 * $4, $3 * $5, 0)$_$
    LANGUAGE sql IMMUTABLE STRICT;


ALTER FUNCTION public.transscale(geometry, double precision, double precision, double precision, double precision) OWNER TO ortelius;

--
-- Name: unite_garray(geometry[]); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION unite_garray(geometry[]) RETURNS geometry
    AS '$libdir/liblwgeom', 'unite_garray'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.unite_garray(geometry[]) OWNER TO ortelius;

--
-- Name: unlockrows(text); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION unlockrows(text) RETURNS integer
    AS $_$
DECLARE
	ret int;
BEGIN

	IF NOT LongTransactionsEnabled() THEN
		RAISE EXCEPTION 'Long transaction support disabled, use EnableLongTransaction() to enable.';
	END IF;

	EXECUTE 'DELETE FROM authorization_table where authid = ' ||
		quote_literal($1);

	GET DIAGNOSTICS ret = ROW_COUNT;

	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.unlockrows(text) OWNER TO ortelius;

--
-- Name: update_geometry_stats(); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION update_geometry_stats() RETURNS text
    AS $$ SELECT 'update_geometry_stats() has been obsoleted. Statistics are automatically built running the ANALYZE command'::text$$
    LANGUAGE sql;


ALTER FUNCTION public.update_geometry_stats() OWNER TO ortelius;

--
-- Name: update_geometry_stats(character varying, character varying); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION update_geometry_stats(character varying, character varying) RETURNS text
    AS $$SELECT update_geometry_stats();$$
    LANGUAGE sql;


ALTER FUNCTION public.update_geometry_stats(character varying, character varying) OWNER TO ortelius;

--
-- Name: updategeometrysrid(character varying, character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION updategeometrysrid(character varying, character varying, character varying, character varying, integer) RETURNS text
    AS $_$
DECLARE
	catalog_name alias for $1; 
	schema_name alias for $2;
	table_name alias for $3;
	column_name alias for $4;
	new_srid alias for $5;
	myrec RECORD;
	okay boolean;
	cname varchar;
	real_schema name;

BEGIN


	-- Find, check or fix schema_name
	IF ( schema_name != '' ) THEN
		okay = 'f';

		FOR myrec IN SELECT nspname FROM pg_namespace WHERE text(nspname) = schema_name LOOP
			okay := 't';
		END LOOP;

		IF ( okay <> 't' ) THEN
			RAISE EXCEPTION 'Invalid schema name';
		ELSE
			real_schema = schema_name;
		END IF;
	ELSE
		SELECT INTO real_schema current_schema()::text;
	END IF;

 	-- Find out if the column is in the geometry_columns table
	okay = 'f';
	FOR myrec IN SELECT * from geometry_columns where f_table_schema = text(real_schema) and f_table_name = table_name and f_geometry_column = column_name LOOP
		okay := 't';
	END LOOP; 
	IF (okay <> 't') THEN 
		RAISE EXCEPTION 'column not found in geometry_columns table';
		RETURN 'f';
	END IF;

	-- Update ref from geometry_columns table
	EXECUTE 'UPDATE geometry_columns SET SRID = ' || new_srid::text || 
		' where f_table_schema = ' ||
		quote_literal(real_schema) || ' and f_table_name = ' ||
		quote_literal(table_name)  || ' and f_geometry_column = ' ||
		quote_literal(column_name);
	
	-- Make up constraint name
	cname = 'enforce_srid_'  || column_name;

	-- Drop enforce_srid constraint
	EXECUTE 'ALTER TABLE ' || quote_ident(real_schema) ||
		'.' || quote_ident(table_name) ||
		' DROP constraint ' || quote_ident(cname);

	-- Update geometries SRID
	EXECUTE 'UPDATE ' || quote_ident(real_schema) ||
		'.' || quote_ident(table_name) ||
		' SET ' || quote_ident(column_name) ||
		' = setSRID(' || quote_ident(column_name) ||
		', ' || new_srid::text || ')';

	-- Reset enforce_srid constraint
	EXECUTE 'ALTER TABLE ' || quote_ident(real_schema) ||
		'.' || quote_ident(table_name) ||
		' ADD constraint ' || quote_ident(cname) ||
		' CHECK (srid(' || quote_ident(column_name) ||
		') = ' || new_srid::text || ')';

	RETURN real_schema || '.' || table_name || '.' || column_name ||' SRID changed to ' || new_srid::text;
	
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.updategeometrysrid(character varying, character varying, character varying, character varying, integer) OWNER TO ortelius;

--
-- Name: updategeometrysrid(character varying, character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION updategeometrysrid(character varying, character varying, character varying, integer) RETURNS text
    AS $_$
DECLARE
	ret  text;
BEGIN
	SELECT UpdateGeometrySRID('',$1,$2,$3,$4) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.updategeometrysrid(character varying, character varying, character varying, integer) OWNER TO ortelius;

--
-- Name: updategeometrysrid(character varying, character varying, integer); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION updategeometrysrid(character varying, character varying, integer) RETURNS text
    AS $_$
DECLARE
	ret  text;
BEGIN
	SELECT UpdateGeometrySRID('','',$1,$2,$3) into ret;
	RETURN ret;
END;
$_$
    LANGUAGE plpgsql STRICT;


ALTER FUNCTION public.updategeometrysrid(character varying, character varying, integer) OWNER TO ortelius;

--
-- Name: width(chip); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION width(chip) RETURNS integer
    AS '$libdir/liblwgeom', 'CHIP_getWidth'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.width(chip) OWNER TO ortelius;

--
-- Name: within(geometry, geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION within(geometry, geometry) RETURNS boolean
    AS '$libdir/liblwgeom', 'within'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.within(geometry, geometry) OWNER TO ortelius;

--
-- Name: x(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION x(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_x_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.x(geometry) OWNER TO ortelius;

--
-- Name: xmax(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION xmax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_xmax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.xmax(box3d) OWNER TO ortelius;

--
-- Name: xmin(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION xmin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_xmin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.xmin(box3d) OWNER TO ortelius;

--
-- Name: y(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION y(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_y_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.y(geometry) OWNER TO ortelius;

--
-- Name: ymax(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION ymax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_ymax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ymax(box3d) OWNER TO ortelius;

--
-- Name: ymin(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION ymin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_ymin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.ymin(box3d) OWNER TO ortelius;

--
-- Name: z(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION z(geometry) RETURNS double precision
    AS '$libdir/liblwgeom', 'LWGEOM_z_point'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.z(geometry) OWNER TO ortelius;

--
-- Name: zmax(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION zmax(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_zmax'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.zmax(box3d) OWNER TO ortelius;

--
-- Name: zmflag(geometry); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION zmflag(geometry) RETURNS smallint
    AS '$libdir/liblwgeom', 'LWGEOM_zmflag'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.zmflag(geometry) OWNER TO ortelius;

--
-- Name: zmin(box3d); Type: FUNCTION; Schema: public; Owner: ortelius
--

CREATE FUNCTION zmin(box3d) RETURNS double precision
    AS '$libdir/liblwgeom', 'BOX3D_zmin'
    LANGUAGE c IMMUTABLE STRICT;


ALTER FUNCTION public.zmin(box3d) OWNER TO ortelius;

--
-- Name: accum(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE accum(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[]
);


ALTER AGGREGATE public.accum(geometry) OWNER TO ortelius;

--
-- Name: collect(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE collect(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_collect_garray
);


ALTER AGGREGATE public.collect(geometry) OWNER TO ortelius;

--
-- Name: extent(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE extent(geometry) (
    SFUNC = public.st_combine_bbox,
    STYPE = box2d
);


ALTER AGGREGATE public.extent(geometry) OWNER TO ortelius;

--
-- Name: extent3d(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE extent3d(geometry) (
    SFUNC = public.combine_bbox,
    STYPE = box3d
);


ALTER AGGREGATE public.extent3d(geometry) OWNER TO ortelius;

--
-- Name: geomunion(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE geomunion(geometry) (
    SFUNC = geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_unite_garray
);


ALTER AGGREGATE public.geomunion(geometry) OWNER TO ortelius;

--
-- Name: makeline(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE makeline(geometry) (
    SFUNC = geom_accum,
    STYPE = geometry[],
    FINALFUNC = makeline_garray
);


ALTER AGGREGATE public.makeline(geometry) OWNER TO ortelius;

--
-- Name: memcollect(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE memcollect(geometry) (
    SFUNC = public.st_collect,
    STYPE = geometry
);


ALTER AGGREGATE public.memcollect(geometry) OWNER TO ortelius;

--
-- Name: memgeomunion(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE memgeomunion(geometry) (
    SFUNC = public.geomunion,
    STYPE = geometry
);


ALTER AGGREGATE public.memgeomunion(geometry) OWNER TO ortelius;

--
-- Name: polygonize(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE polygonize(geometry) (
    SFUNC = geom_accum,
    STYPE = geometry[],
    FINALFUNC = polygonize_garray
);


ALTER AGGREGATE public.polygonize(geometry) OWNER TO ortelius;

--
-- Name: st_accum(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE st_accum(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[]
);


ALTER AGGREGATE public.st_accum(geometry) OWNER TO ortelius;

--
-- Name: st_collect(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE st_collect(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_collect_garray
);


ALTER AGGREGATE public.st_collect(geometry) OWNER TO ortelius;

--
-- Name: st_extent(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE st_extent(geometry) (
    SFUNC = public.st_combine_bbox,
    STYPE = box2d
);


ALTER AGGREGATE public.st_extent(geometry) OWNER TO ortelius;

--
-- Name: st_extent3d(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE st_extent3d(geometry) (
    SFUNC = public.st_combine_bbox,
    STYPE = box3d
);


ALTER AGGREGATE public.st_extent3d(geometry) OWNER TO ortelius;

--
-- Name: st_makeline(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE st_makeline(geometry) (
    SFUNC = geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_makeline_garray
);


ALTER AGGREGATE public.st_makeline(geometry) OWNER TO ortelius;

--
-- Name: st_memcollect(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE st_memcollect(geometry) (
    SFUNC = public.st_collect,
    STYPE = geometry
);


ALTER AGGREGATE public.st_memcollect(geometry) OWNER TO ortelius;

--
-- Name: st_memunion(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE st_memunion(geometry) (
    SFUNC = public.st_union,
    STYPE = geometry
);


ALTER AGGREGATE public.st_memunion(geometry) OWNER TO ortelius;

--
-- Name: st_polygonize(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE st_polygonize(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_polygonize_garray
);


ALTER AGGREGATE public.st_polygonize(geometry) OWNER TO ortelius;

--
-- Name: st_union(geometry); Type: AGGREGATE; Schema: public; Owner: ortelius
--

CREATE AGGREGATE st_union(geometry) (
    SFUNC = st_geom_accum,
    STYPE = geometry[],
    FINALFUNC = st_unite_garray
);


ALTER AGGREGATE public.st_union(geometry) OWNER TO ortelius;

--
-- Name: &&; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR && (
    PROCEDURE = st_geometry_overlap,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = &&,
    RESTRICT = st_postgis_gist_sel,
    JOIN = st_postgis_gist_joinsel
);


ALTER OPERATOR public.&& (geometry, geometry) OWNER TO ortelius;

--
-- Name: &<; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR &< (
    PROCEDURE = st_geometry_overleft,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = &>,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.&< (geometry, geometry) OWNER TO ortelius;

--
-- Name: &<|; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR &<| (
    PROCEDURE = st_geometry_overbelow,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = |&>,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.&<| (geometry, geometry) OWNER TO ortelius;

--
-- Name: &>; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR &> (
    PROCEDURE = st_geometry_overright,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = &<,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.&> (geometry, geometry) OWNER TO ortelius;

--
-- Name: <; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR < (
    PROCEDURE = st_geometry_lt,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = >,
    NEGATOR = >=,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.< (geometry, geometry) OWNER TO ortelius;

--
-- Name: <<; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR << (
    PROCEDURE = st_geometry_left,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = >>,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.<< (geometry, geometry) OWNER TO ortelius;

--
-- Name: <<|; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR <<| (
    PROCEDURE = st_geometry_below,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = |>>,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.<<| (geometry, geometry) OWNER TO ortelius;

--
-- Name: <=; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR <= (
    PROCEDURE = st_geometry_le,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = >=,
    NEGATOR = >,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.<= (geometry, geometry) OWNER TO ortelius;

--
-- Name: =; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR = (
    PROCEDURE = st_geometry_eq,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = =,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.= (geometry, geometry) OWNER TO ortelius;

--
-- Name: >; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR > (
    PROCEDURE = st_geometry_gt,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = <,
    NEGATOR = <=,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.> (geometry, geometry) OWNER TO ortelius;

--
-- Name: >=; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR >= (
    PROCEDURE = st_geometry_ge,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = <=,
    NEGATOR = <,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.>= (geometry, geometry) OWNER TO ortelius;

--
-- Name: >>; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR >> (
    PROCEDURE = st_geometry_right,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = <<,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.>> (geometry, geometry) OWNER TO ortelius;

--
-- Name: @; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR @ (
    PROCEDURE = st_geometry_contained,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = ~,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.@ (geometry, geometry) OWNER TO ortelius;

--
-- Name: |&>; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR |&> (
    PROCEDURE = st_geometry_overabove,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = &<|,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.|&> (geometry, geometry) OWNER TO ortelius;

--
-- Name: |>>; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR |>> (
    PROCEDURE = st_geometry_above,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = <<|,
    RESTRICT = positionsel,
    JOIN = positionjoinsel
);


ALTER OPERATOR public.|>> (geometry, geometry) OWNER TO ortelius;

--
-- Name: ~; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR ~ (
    PROCEDURE = st_geometry_contain,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = @,
    RESTRICT = contsel,
    JOIN = contjoinsel
);


ALTER OPERATOR public.~ (geometry, geometry) OWNER TO ortelius;

--
-- Name: ~=; Type: OPERATOR; Schema: public; Owner: ortelius
--

CREATE OPERATOR ~= (
    PROCEDURE = st_geometry_same,
    LEFTARG = geometry,
    RIGHTARG = geometry,
    COMMUTATOR = ~=,
    RESTRICT = eqsel,
    JOIN = eqjoinsel
);


ALTER OPERATOR public.~= (geometry, geometry) OWNER TO ortelius;

--
-- Name: btree_geometry_ops; Type: OPERATOR CLASS; Schema: public; Owner: ortelius
--

CREATE OPERATOR CLASS btree_geometry_ops
    DEFAULT FOR TYPE geometry USING btree AS
    OPERATOR 1 <(geometry,geometry) ,
    OPERATOR 2 <=(geometry,geometry) ,
    OPERATOR 3 =(geometry,geometry) ,
    OPERATOR 4 >=(geometry,geometry) ,
    OPERATOR 5 >(geometry,geometry) ,
    FUNCTION 1 geometry_cmp(geometry,geometry);


ALTER OPERATOR CLASS public.btree_geometry_ops USING btree OWNER TO ortelius;

--
-- Name: gist_geometry_ops; Type: OPERATOR CLASS; Schema: public; Owner: ortelius
--

CREATE OPERATOR CLASS gist_geometry_ops
    DEFAULT FOR TYPE geometry USING gist AS
    STORAGE box2d ,
    OPERATOR 1 <<(geometry,geometry) RECHECK ,
    OPERATOR 2 &<(geometry,geometry) RECHECK ,
    OPERATOR 3 &&(geometry,geometry) RECHECK ,
    OPERATOR 4 &>(geometry,geometry) RECHECK ,
    OPERATOR 5 >>(geometry,geometry) RECHECK ,
    OPERATOR 6 ~=(geometry,geometry) RECHECK ,
    OPERATOR 7 ~(geometry,geometry) RECHECK ,
    OPERATOR 8 @(geometry,geometry) RECHECK ,
    OPERATOR 9 &<|(geometry,geometry) RECHECK ,
    OPERATOR 10 <<|(geometry,geometry) RECHECK ,
    OPERATOR 11 |>>(geometry,geometry) RECHECK ,
    OPERATOR 12 |&>(geometry,geometry) RECHECK ,
    FUNCTION 1 lwgeom_gist_consistent(internal,geometry,integer) ,
    FUNCTION 2 lwgeom_gist_union(bytea,internal) ,
    FUNCTION 3 lwgeom_gist_compress(internal) ,
    FUNCTION 4 lwgeom_gist_decompress(internal) ,
    FUNCTION 5 lwgeom_gist_penalty(internal,internal,internal) ,
    FUNCTION 6 lwgeom_gist_picksplit(internal,internal) ,
    FUNCTION 7 lwgeom_gist_same(box2d,box2d,internal);


ALTER OPERATOR CLASS public.gist_geometry_ops USING gist OWNER TO ortelius;

SET search_path = pg_catalog;

--
-- Name: CAST (public.box2d AS public.box3d); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box2d AS public.box3d) WITH FUNCTION public.st_box3d(public.box2d) AS IMPLICIT;


--
-- Name: CAST (public.box2d AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box2d AS public.geometry) WITH FUNCTION public.st_geometry(public.box2d) AS IMPLICIT;


--
-- Name: CAST (public.box3d AS box); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box3d AS box) WITH FUNCTION public.st_box(public.box3d) AS IMPLICIT;


--
-- Name: CAST (public.box3d AS public.box2d); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box3d AS public.box2d) WITH FUNCTION public.st_box2d(public.box3d) AS IMPLICIT;


--
-- Name: CAST (public.box3d AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.box3d AS public.geometry) WITH FUNCTION public.st_geometry(public.box3d) AS IMPLICIT;


--
-- Name: CAST (bytea AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (bytea AS public.geometry) WITH FUNCTION public.st_geometry(bytea) AS IMPLICIT;


--
-- Name: CAST (public.chip AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.chip AS public.geometry) WITH FUNCTION public.st_geometry(public.chip) AS IMPLICIT;


--
-- Name: CAST (public.geometry AS box); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS box) WITH FUNCTION public.st_box(public.geometry) AS IMPLICIT;


--
-- Name: CAST (public.geometry AS public.box2d); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS public.box2d) WITH FUNCTION public.st_box2d(public.geometry) AS IMPLICIT;


--
-- Name: CAST (public.geometry AS public.box3d); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS public.box3d) WITH FUNCTION public.st_box3d(public.geometry) AS IMPLICIT;


--
-- Name: CAST (public.geometry AS bytea); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS bytea) WITH FUNCTION public.st_bytea(public.geometry) AS IMPLICIT;


--
-- Name: CAST (public.geometry AS text); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (public.geometry AS text) WITH FUNCTION public.st_text(public.geometry) AS IMPLICIT;


--
-- Name: CAST (text AS public.geometry); Type: CAST; Schema: pg_catalog; Owner: 
--

CREATE CAST (text AS public.geometry) WITH FUNCTION public.st_geometry(text) AS IMPLICIT;


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO bmeadmin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO bmeadmin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO bmeadmin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO bmeadmin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_message; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE auth_message (
    id integer NOT NULL,
    user_id integer NOT NULL,
    message text NOT NULL
);


ALTER TABLE public.auth_message OWNER TO bmeadmin;

--
-- Name: auth_message_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE auth_message_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_message_id_seq OWNER TO bmeadmin;

--
-- Name: auth_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE auth_message_id_seq OWNED BY auth_message.id;


--
-- Name: auth_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('auth_message_id_seq', 208, true);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO bmeadmin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE auth_permission_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO bmeadmin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('auth_permission_id_seq', 66, true);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    "password" character varying(128) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO bmeadmin;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO bmeadmin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO bmeadmin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE auth_user_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO bmeadmin;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('auth_user_id_seq', 7, true);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO bmeadmin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO bmeadmin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO bmeadmin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE django_admin_log_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO bmeadmin;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 202, true);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO bmeadmin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE django_content_type_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO bmeadmin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('django_content_type_id_seq', 22, true);


--
-- Name: django_flatpage; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE django_flatpage (
    id integer NOT NULL,
    url character varying(100) NOT NULL,
    title character varying(200) NOT NULL,
    content text NOT NULL,
    enable_comments boolean NOT NULL,
    template_name character varying(70) NOT NULL,
    registration_required boolean NOT NULL
);


ALTER TABLE public.django_flatpage OWNER TO bmeadmin;

--
-- Name: django_flatpage_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE django_flatpage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_flatpage_id_seq OWNER TO bmeadmin;

--
-- Name: django_flatpage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE django_flatpage_id_seq OWNED BY django_flatpage.id;


--
-- Name: django_flatpage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('django_flatpage_id_seq', 1, false);


--
-- Name: django_flatpage_sites; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE django_flatpage_sites (
    id integer NOT NULL,
    flatpage_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.django_flatpage_sites OWNER TO bmeadmin;

--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE django_flatpage_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_flatpage_sites_id_seq OWNER TO bmeadmin;

--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE django_flatpage_sites_id_seq OWNED BY django_flatpage_sites.id;


--
-- Name: django_flatpage_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('django_flatpage_sites_id_seq', 1, false);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO bmeadmin;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    "domain" character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO bmeadmin;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE django_site_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO bmeadmin;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Name: feedjack_feed; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE feedjack_feed (
    id integer NOT NULL,
    feed_url character varying(200) NOT NULL,
    name character varying(100) NOT NULL,
    shortname character varying(50) NOT NULL,
    is_active boolean NOT NULL,
    title character varying(200) NOT NULL,
    tagline text NOT NULL,
    link character varying(200) NOT NULL,
    etag character varying(50) NOT NULL,
    last_modified timestamp with time zone,
    last_checked timestamp with time zone
);


ALTER TABLE public.feedjack_feed OWNER TO bmeadmin;

--
-- Name: feedjack_feed_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE feedjack_feed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feedjack_feed_id_seq OWNER TO bmeadmin;

--
-- Name: feedjack_feed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE feedjack_feed_id_seq OWNED BY feedjack_feed.id;


--
-- Name: feedjack_feed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('feedjack_feed_id_seq', 1, false);


--
-- Name: feedjack_link; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE feedjack_link (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    link character varying(200) NOT NULL
);


ALTER TABLE public.feedjack_link OWNER TO bmeadmin;

--
-- Name: feedjack_link_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE feedjack_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feedjack_link_id_seq OWNER TO bmeadmin;

--
-- Name: feedjack_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE feedjack_link_id_seq OWNED BY feedjack_link.id;


--
-- Name: feedjack_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('feedjack_link_id_seq', 1, false);


--
-- Name: feedjack_post; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE feedjack_post (
    id integer NOT NULL,
    feed_id integer NOT NULL,
    title character varying(255) NOT NULL,
    link character varying(200) NOT NULL,
    content text NOT NULL,
    date_modified timestamp with time zone,
    guid character varying(200) NOT NULL,
    author character varying(50) NOT NULL,
    author_email character varying(75) NOT NULL,
    comments character varying(200) NOT NULL,
    date_created date NOT NULL
);


ALTER TABLE public.feedjack_post OWNER TO bmeadmin;

--
-- Name: feedjack_post_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE feedjack_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feedjack_post_id_seq OWNER TO bmeadmin;

--
-- Name: feedjack_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE feedjack_post_id_seq OWNED BY feedjack_post.id;


--
-- Name: feedjack_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('feedjack_post_id_seq', 1, false);


--
-- Name: feedjack_post_tags; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE feedjack_post_tags (
    id integer NOT NULL,
    post_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.feedjack_post_tags OWNER TO bmeadmin;

--
-- Name: feedjack_post_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE feedjack_post_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feedjack_post_tags_id_seq OWNER TO bmeadmin;

--
-- Name: feedjack_post_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE feedjack_post_tags_id_seq OWNED BY feedjack_post_tags.id;


--
-- Name: feedjack_post_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('feedjack_post_tags_id_seq', 1, false);


--
-- Name: feedjack_site; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE feedjack_site (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    url character varying(100) NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    welcome text,
    greets text,
    default_site boolean NOT NULL,
    posts_per_page integer NOT NULL,
    order_posts_by integer NOT NULL,
    tagcloud_levels integer NOT NULL,
    show_tagcloud boolean NOT NULL,
    use_internal_cache boolean NOT NULL,
    cache_duration integer NOT NULL,
    "template" character varying(100)
);


ALTER TABLE public.feedjack_site OWNER TO bmeadmin;

--
-- Name: feedjack_site_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE feedjack_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feedjack_site_id_seq OWNER TO bmeadmin;

--
-- Name: feedjack_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE feedjack_site_id_seq OWNED BY feedjack_site.id;


--
-- Name: feedjack_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('feedjack_site_id_seq', 1, false);


--
-- Name: feedjack_site_links; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE feedjack_site_links (
    id integer NOT NULL,
    site_id integer NOT NULL,
    link_id integer NOT NULL
);


ALTER TABLE public.feedjack_site_links OWNER TO bmeadmin;

--
-- Name: feedjack_site_links_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE feedjack_site_links_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feedjack_site_links_id_seq OWNER TO bmeadmin;

--
-- Name: feedjack_site_links_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE feedjack_site_links_id_seq OWNED BY feedjack_site_links.id;


--
-- Name: feedjack_site_links_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('feedjack_site_links_id_seq', 1, false);


--
-- Name: feedjack_subscriber; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE feedjack_subscriber (
    id integer NOT NULL,
    site_id integer NOT NULL,
    feed_id integer NOT NULL,
    name character varying(100),
    shortname character varying(50),
    is_active boolean NOT NULL
);


ALTER TABLE public.feedjack_subscriber OWNER TO bmeadmin;

--
-- Name: feedjack_subscriber_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE feedjack_subscriber_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feedjack_subscriber_id_seq OWNER TO bmeadmin;

--
-- Name: feedjack_subscriber_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE feedjack_subscriber_id_seq OWNED BY feedjack_subscriber.id;


--
-- Name: feedjack_subscriber_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('feedjack_subscriber_id_seq', 1, false);


--
-- Name: feedjack_tag; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE feedjack_tag (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.feedjack_tag OWNER TO bmeadmin;

--
-- Name: feedjack_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE feedjack_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.feedjack_tag_id_seq OWNER TO bmeadmin;

--
-- Name: feedjack_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE feedjack_tag_id_seq OWNED BY feedjack_tag.id;


--
-- Name: feedjack_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('feedjack_tag_id_seq', 1, false);


SET default_with_oids = true;

--
-- Name: geometry_columns; Type: TABLE; Schema: public; Owner: ortelius; Tablespace: 
--

CREATE TABLE geometry_columns (
    f_table_catalog character varying(256) NOT NULL,
    f_table_schema character varying(256) NOT NULL,
    f_table_name character varying(256) NOT NULL,
    f_geometry_column character varying(256) NOT NULL,
    coord_dimension integer NOT NULL,
    srid integer NOT NULL,
    "type" character varying(30) NOT NULL
);


ALTER TABLE public.geometry_columns OWNER TO ortelius;

SET default_with_oids = false;

--
-- Name: spatial_ref_sys; Type: TABLE; Schema: public; Owner: ortelius; Tablespace: 
--

CREATE TABLE spatial_ref_sys (
    srid integer NOT NULL,
    auth_name character varying(256),
    auth_srid integer,
    srtext character varying(2048),
    proj4text character varying(2048)
);


ALTER TABLE public.spatial_ref_sys OWNER TO ortelius;

--
-- Name: tagging_tag; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE tagging_tag (
    id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.tagging_tag OWNER TO bmeadmin;

--
-- Name: tagging_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE tagging_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tagging_tag_id_seq OWNER TO bmeadmin;

--
-- Name: tagging_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE tagging_tag_id_seq OWNED BY tagging_tag.id;


--
-- Name: tagging_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('tagging_tag_id_seq', 1, false);


--
-- Name: tagging_taggeditem; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE tagging_taggeditem (
    id integer NOT NULL,
    tag_id integer NOT NULL,
    content_type_id integer NOT NULL,
    object_id integer NOT NULL,
    CONSTRAINT tagging_taggeditem_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE public.tagging_taggeditem OWNER TO bmeadmin;

--
-- Name: tagging_taggeditem_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE tagging_taggeditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.tagging_taggeditem_id_seq OWNER TO bmeadmin;

--
-- Name: tagging_taggeditem_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE tagging_taggeditem_id_seq OWNED BY tagging_taggeditem.id;


--
-- Name: tagging_taggeditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('tagging_taggeditem_id_seq', 1, false);


--
-- Name: web_art_installation; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE web_art_installation (
    id integer NOT NULL,
    year_id integer NOT NULL,
    name character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    artist character varying(255),
    description text,
    url character varying(200),
    contact_email character varying(75),
    circular_street_id integer,
    time_address time without time zone,
    location_point geometry,
    location_poly geometry,
    CONSTRAINT enforce_dims_location_point CHECK ((ndims(location_point) = 2)),
    CONSTRAINT enforce_dims_location_poly CHECK ((ndims(location_poly) = 2)),
    CONSTRAINT enforce_geotype_location_point CHECK (((geometrytype(location_point) = 'POINT'::text) OR (location_point IS NULL))),
    CONSTRAINT enforce_geotype_location_poly CHECK (((geometrytype(location_poly) = 'POLYGON'::text) OR (location_poly IS NULL))),
    CONSTRAINT enforce_srid_location_point CHECK ((srid(location_point) = 4326)),
    CONSTRAINT enforce_srid_location_poly CHECK ((srid(location_poly) = 4326))
);


ALTER TABLE public.web_art_installation OWNER TO bmeadmin;

--
-- Name: web_art_installation_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE web_art_installation_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.web_art_installation_id_seq OWNER TO bmeadmin;

--
-- Name: web_art_installation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE web_art_installation_id_seq OWNED BY web_art_installation.id;


--
-- Name: web_art_installation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('web_art_installation_id_seq', 284, true);


--
-- Name: web_circular_street; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE web_circular_street (
    id integer NOT NULL,
    year_id integer NOT NULL,
    name character varying(50) NOT NULL,
    "order" integer,
    width integer,
    distance_from_center integer
);


ALTER TABLE public.web_circular_street OWNER TO bmeadmin;

--
-- Name: web_circular_street_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE web_circular_street_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.web_circular_street_id_seq OWNER TO bmeadmin;

--
-- Name: web_circular_street_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE web_circular_street_id_seq OWNED BY web_circular_street.id;


--
-- Name: web_circular_street_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('web_circular_street_id_seq', 25, true);


--
-- Name: web_playa_event; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE web_playa_event (
    id integer NOT NULL,
    year_id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    "type" character varying(6) NOT NULL,
    start_date_time timestamp with time zone,
    end_date_time timestamp with time zone,
    duration integer,
    repeats boolean,
    hosted_by_camp_id integer,
    located_at_art_id integer,
    url character varying(200),
    contact_email character varying(75),
    location_point geometry,
    location_track geometry,
    CONSTRAINT enforce_dims_location_point CHECK ((ndims(location_point) = 2)),
    CONSTRAINT enforce_dims_location_track CHECK ((ndims(location_track) = 2)),
    CONSTRAINT enforce_geotype_location_point CHECK (((geometrytype(location_point) = 'POINT'::text) OR (location_point IS NULL))),
    CONSTRAINT enforce_geotype_location_track CHECK (((geometrytype(location_track) = 'LINESTRING'::text) OR (location_track IS NULL))),
    CONSTRAINT enforce_srid_location_point CHECK ((srid(location_point) = 4326)),
    CONSTRAINT enforce_srid_location_track CHECK ((srid(location_track) = 4326))
);


ALTER TABLE public.web_playa_event OWNER TO bmeadmin;

--
-- Name: web_playa_event_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE web_playa_event_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.web_playa_event_id_seq OWNER TO bmeadmin;

--
-- Name: web_playa_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE web_playa_event_id_seq OWNED BY web_playa_event.id;


--
-- Name: web_playa_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('web_playa_event_id_seq', 1, true);


--
-- Name: web_theme_camp; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE web_theme_camp (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    year_id integer NOT NULL,
    description text,
    url character varying(200),
    contact_email character varying(75),
    hometown character varying(50),
    circular_street_id integer,
    time_address time without time zone,
    location_point geometry,
    location_poly geometry,
    CONSTRAINT enforce_dims_location_point CHECK ((ndims(location_point) = 2)),
    CONSTRAINT enforce_dims_location_poly CHECK ((ndims(location_poly) = 2)),
    CONSTRAINT enforce_geotype_location_point CHECK (((geometrytype(location_point) = 'POINT'::text) OR (location_point IS NULL))),
    CONSTRAINT enforce_geotype_location_poly CHECK (((geometrytype(location_poly) = 'POLYGON'::text) OR (location_poly IS NULL))),
    CONSTRAINT enforce_srid_location_point CHECK ((srid(location_point) = 4326)),
    CONSTRAINT enforce_srid_location_poly CHECK ((srid(location_poly) = 4326))
);


ALTER TABLE public.web_theme_camp OWNER TO bmeadmin;

--
-- Name: web_theme_camp_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE web_theme_camp_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.web_theme_camp_id_seq OWNER TO bmeadmin;

--
-- Name: web_theme_camp_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE web_theme_camp_id_seq OWNED BY web_theme_camp.id;


--
-- Name: web_theme_camp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('web_theme_camp_id_seq', 663, true);


--
-- Name: web_theme_camp_participants; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE web_theme_camp_participants (
    id integer NOT NULL,
    theme_camp_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.web_theme_camp_participants OWNER TO bmeadmin;

--
-- Name: web_theme_camp_participants_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE web_theme_camp_participants_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.web_theme_camp_participants_id_seq OWNER TO bmeadmin;

--
-- Name: web_theme_camp_participants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE web_theme_camp_participants_id_seq OWNED BY web_theme_camp_participants.id;


--
-- Name: web_theme_camp_participants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('web_theme_camp_participants_id_seq', 2, true);


--
-- Name: web_year; Type: TABLE; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE TABLE web_year (
    id integer NOT NULL,
    "year" character varying(4) NOT NULL,
    "location" character varying(50) NOT NULL,
    participants integer,
    theme character varying(20),
    notes text,
    location_point geometry,
    CONSTRAINT enforce_dims_location_point CHECK ((ndims(location_point) = 2)),
    CONSTRAINT enforce_geotype_location_point CHECK (((geometrytype(location_point) = 'POINT'::text) OR (location_point IS NULL))),
    CONSTRAINT enforce_srid_location_point CHECK ((srid(location_point) = 4326))
);


ALTER TABLE public.web_year OWNER TO bmeadmin;

--
-- Name: web_year_id_seq; Type: SEQUENCE; Schema: public; Owner: bmeadmin
--

CREATE SEQUENCE web_year_id_seq
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.web_year_id_seq OWNER TO bmeadmin;

--
-- Name: web_year_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: bmeadmin
--

ALTER SEQUENCE web_year_id_seq OWNED BY web_year.id;


--
-- Name: web_year_id_seq; Type: SEQUENCE SET; Schema: public; Owner: bmeadmin
--

SELECT pg_catalog.setval('web_year_id_seq', 3, true);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE auth_message ALTER COLUMN id SET DEFAULT nextval('auth_message_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE django_flatpage ALTER COLUMN id SET DEFAULT nextval('django_flatpage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE django_flatpage_sites ALTER COLUMN id SET DEFAULT nextval('django_flatpage_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE feedjack_feed ALTER COLUMN id SET DEFAULT nextval('feedjack_feed_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE feedjack_link ALTER COLUMN id SET DEFAULT nextval('feedjack_link_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE feedjack_post ALTER COLUMN id SET DEFAULT nextval('feedjack_post_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE feedjack_post_tags ALTER COLUMN id SET DEFAULT nextval('feedjack_post_tags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE feedjack_site ALTER COLUMN id SET DEFAULT nextval('feedjack_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE feedjack_site_links ALTER COLUMN id SET DEFAULT nextval('feedjack_site_links_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE feedjack_subscriber ALTER COLUMN id SET DEFAULT nextval('feedjack_subscriber_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE feedjack_tag ALTER COLUMN id SET DEFAULT nextval('feedjack_tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE tagging_tag ALTER COLUMN id SET DEFAULT nextval('tagging_tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE tagging_taggeditem ALTER COLUMN id SET DEFAULT nextval('tagging_taggeditem_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE web_art_installation ALTER COLUMN id SET DEFAULT nextval('web_art_installation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE web_circular_street ALTER COLUMN id SET DEFAULT nextval('web_circular_street_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE web_playa_event ALTER COLUMN id SET DEFAULT nextval('web_playa_event_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE web_theme_camp ALTER COLUMN id SET DEFAULT nextval('web_theme_camp_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE web_theme_camp_participants ALTER COLUMN id SET DEFAULT nextval('web_theme_camp_participants_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: bmeadmin
--

ALTER TABLE web_year ALTER COLUMN id SET DEFAULT nextval('web_year_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY auth_group (id, name) FROM stdin;
\.
copy auth_group (id, name)  from '$$PATH$$/2678.dat' ;
--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
copy auth_group_permissions (id, group_id, permission_id)  from '$$PATH$$/2687.dat' ;
--
-- Data for Name: auth_message; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY auth_message (id, user_id, message) FROM stdin;
\.
copy auth_message (id, user_id, message)  from '$$PATH$$/2677.dat' ;
--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
copy auth_permission (id, name, content_type_id, codename)  from '$$PATH$$/2680.dat' ;
--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY auth_user (id, username, first_name, last_name, email, "password", is_staff, is_active, is_superuser, last_login, date_joined) FROM stdin;
\.
copy auth_user (id, username, first_name, last_name, email, "password", is_staff, is_active, is_superuser, last_login, date_joined)  from '$$PATH$$/2679.dat' ;
--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.
copy auth_user_groups (id, user_id, group_id)  from '$$PATH$$/2688.dat' ;
--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
copy auth_user_user_permissions (id, user_id, permission_id)  from '$$PATH$$/2689.dat' ;
--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
\.
copy django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message)  from '$$PATH$$/2684.dat' ;
--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
\.
copy django_content_type (id, name, app_label, model)  from '$$PATH$$/2681.dat' ;
--
-- Data for Name: django_flatpage; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY django_flatpage (id, url, title, content, enable_comments, template_name, registration_required) FROM stdin;
\.
copy django_flatpage (id, url, title, content, enable_comments, template_name, registration_required)  from '$$PATH$$/2693.dat' ;
--
-- Data for Name: django_flatpage_sites; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY django_flatpage_sites (id, flatpage_id, site_id) FROM stdin;
\.
copy django_flatpage_sites (id, flatpage_id, site_id)  from '$$PATH$$/2696.dat' ;
--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.
copy django_session (session_key, session_data, expire_date)  from '$$PATH$$/2682.dat' ;
--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY django_site (id, "domain", name) FROM stdin;
\.
copy django_site (id, "domain", name)  from '$$PATH$$/2683.dat' ;
--
-- Data for Name: feedjack_feed; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY feedjack_feed (id, feed_url, name, shortname, is_active, title, tagline, link, etag, last_modified, last_checked) FROM stdin;
\.
copy feedjack_feed (id, feed_url, name, shortname, is_active, title, tagline, link, etag, last_modified, last_checked)  from '$$PATH$$/2697.dat' ;
--
-- Data for Name: feedjack_link; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY feedjack_link (id, name, link) FROM stdin;
\.
copy feedjack_link (id, name, link)  from '$$PATH$$/2701.dat' ;
--
-- Data for Name: feedjack_post; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY feedjack_post (id, feed_id, title, link, content, date_modified, guid, author, author_email, comments, date_created) FROM stdin;
\.
copy feedjack_post (id, feed_id, title, link, content, date_modified, guid, author, author_email, comments, date_created)  from '$$PATH$$/2702.dat' ;
--
-- Data for Name: feedjack_post_tags; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY feedjack_post_tags (id, post_id, tag_id) FROM stdin;
\.
copy feedjack_post_tags (id, post_id, tag_id)  from '$$PATH$$/2704.dat' ;
--
-- Data for Name: feedjack_site; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY feedjack_site (id, name, url, title, description, welcome, greets, default_site, posts_per_page, order_posts_by, tagcloud_levels, show_tagcloud, use_internal_cache, cache_duration, "template") FROM stdin;
\.
copy feedjack_site (id, name, url, title, description, welcome, greets, default_site, posts_per_page, order_posts_by, tagcloud_levels, show_tagcloud, use_internal_cache, cache_duration, "template")  from '$$PATH$$/2698.dat' ;
--
-- Data for Name: feedjack_site_links; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY feedjack_site_links (id, site_id, link_id) FROM stdin;
\.
copy feedjack_site_links (id, site_id, link_id)  from '$$PATH$$/2703.dat' ;
--
-- Data for Name: feedjack_subscriber; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY feedjack_subscriber (id, site_id, feed_id, name, shortname, is_active) FROM stdin;
\.
copy feedjack_subscriber (id, site_id, feed_id, name, shortname, is_active)  from '$$PATH$$/2699.dat' ;
--
-- Data for Name: feedjack_tag; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY feedjack_tag (id, name) FROM stdin;
\.
copy feedjack_tag (id, name)  from '$$PATH$$/2700.dat' ;
--
-- Data for Name: geometry_columns; Type: TABLE DATA; Schema: public; Owner: ortelius
--

COPY geometry_columns (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type") FROM stdin;
\.
copy geometry_columns (f_table_catalog, f_table_schema, f_table_name, f_geometry_column, coord_dimension, srid, "type")  from '$$PATH$$/2676.dat' ;
--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: ortelius
--

COPY spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
copy spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text)  from '$$PATH$$/2675.dat' ;
--
-- Data for Name: tagging_tag; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY tagging_tag (id, name) FROM stdin;
\.
copy tagging_tag (id, name)  from '$$PATH$$/2695.dat' ;
--
-- Data for Name: tagging_taggeditem; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY tagging_taggeditem (id, tag_id, content_type_id, object_id) FROM stdin;
\.
copy tagging_taggeditem (id, tag_id, content_type_id, object_id)  from '$$PATH$$/2694.dat' ;
--
-- Data for Name: web_art_installation; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY web_art_installation (id, year_id, name, slug, artist, description, url, contact_email, circular_street_id, time_address, location_point, location_poly) FROM stdin;
\.
copy web_art_installation (id, year_id, name, slug, artist, description, url, contact_email, circular_street_id, time_address, location_point, location_poly)  from '$$PATH$$/2705.dat' ;
--
-- Data for Name: web_circular_street; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY web_circular_street (id, year_id, name, "order", width, distance_from_center) FROM stdin;
\.
copy web_circular_street (id, year_id, name, "order", width, distance_from_center)  from '$$PATH$$/2685.dat' ;
--
-- Data for Name: web_playa_event; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY web_playa_event (id, year_id, name, description, "type", start_date_time, end_date_time, duration, repeats, hosted_by_camp_id, located_at_art_id, url, contact_email, location_point, location_track) FROM stdin;
\.
copy web_playa_event (id, year_id, name, description, "type", start_date_time, end_date_time, duration, repeats, hosted_by_camp_id, located_at_art_id, url, contact_email, location_point, location_track)  from '$$PATH$$/2692.dat' ;
--
-- Data for Name: web_theme_camp; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY web_theme_camp (id, name, year_id, description, url, contact_email, hometown, circular_street_id, time_address, location_point, location_poly) FROM stdin;
\.
copy web_theme_camp (id, name, year_id, description, url, contact_email, hometown, circular_street_id, time_address, location_point, location_poly)  from '$$PATH$$/2690.dat' ;
--
-- Data for Name: web_theme_camp_participants; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY web_theme_camp_participants (id, theme_camp_id, user_id) FROM stdin;
\.
copy web_theme_camp_participants (id, theme_camp_id, user_id)  from '$$PATH$$/2691.dat' ;
--
-- Data for Name: web_year; Type: TABLE DATA; Schema: public; Owner: bmeadmin
--

COPY web_year (id, "year", "location", participants, theme, notes, location_point) FROM stdin;
\.
copy web_year (id, "year", "location", participants, theme, notes, location_point)  from '$$PATH$$/2686.dat' ;
--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_message_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_flatpage_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY django_flatpage
    ADD CONSTRAINT django_flatpage_pkey PRIMARY KEY (id);


--
-- Name: django_flatpage_sites_flatpage_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_flatpage_id_key UNIQUE (flatpage_id, site_id);


--
-- Name: django_flatpage_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: feedjack_feed_feed_url_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_feed
    ADD CONSTRAINT feedjack_feed_feed_url_key UNIQUE (feed_url);


--
-- Name: feedjack_feed_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_feed
    ADD CONSTRAINT feedjack_feed_pkey PRIMARY KEY (id);


--
-- Name: feedjack_link_name_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_link
    ADD CONSTRAINT feedjack_link_name_key UNIQUE (name);


--
-- Name: feedjack_link_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_link
    ADD CONSTRAINT feedjack_link_pkey PRIMARY KEY (id);


--
-- Name: feedjack_post_feed_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_post
    ADD CONSTRAINT feedjack_post_feed_id_key UNIQUE (feed_id, guid);


--
-- Name: feedjack_post_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_post
    ADD CONSTRAINT feedjack_post_pkey PRIMARY KEY (id);


--
-- Name: feedjack_post_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_post_tags
    ADD CONSTRAINT feedjack_post_tags_pkey PRIMARY KEY (id);


--
-- Name: feedjack_post_tags_post_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_post_tags
    ADD CONSTRAINT feedjack_post_tags_post_id_key UNIQUE (post_id, tag_id);


--
-- Name: feedjack_site_links_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_site_links
    ADD CONSTRAINT feedjack_site_links_pkey PRIMARY KEY (id);


--
-- Name: feedjack_site_links_site_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_site_links
    ADD CONSTRAINT feedjack_site_links_site_id_key UNIQUE (site_id, link_id);


--
-- Name: feedjack_site_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_site
    ADD CONSTRAINT feedjack_site_pkey PRIMARY KEY (id);


--
-- Name: feedjack_site_url_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_site
    ADD CONSTRAINT feedjack_site_url_key UNIQUE (url);


--
-- Name: feedjack_subscriber_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_subscriber
    ADD CONSTRAINT feedjack_subscriber_pkey PRIMARY KEY (id);


--
-- Name: feedjack_subscriber_site_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_subscriber
    ADD CONSTRAINT feedjack_subscriber_site_id_key UNIQUE (site_id, feed_id);


--
-- Name: feedjack_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_tag
    ADD CONSTRAINT feedjack_tag_name_key UNIQUE (name);


--
-- Name: feedjack_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY feedjack_tag
    ADD CONSTRAINT feedjack_tag_pkey PRIMARY KEY (id);


--
-- Name: geometry_columns_pk; Type: CONSTRAINT; Schema: public; Owner: ortelius; Tablespace: 
--

ALTER TABLE ONLY geometry_columns
    ADD CONSTRAINT geometry_columns_pk PRIMARY KEY (f_table_catalog, f_table_schema, f_table_name, f_geometry_column);


--
-- Name: spatial_ref_sys_pkey; Type: CONSTRAINT; Schema: public; Owner: ortelius; Tablespace: 
--

ALTER TABLE ONLY spatial_ref_sys
    ADD CONSTRAINT spatial_ref_sys_pkey PRIMARY KEY (srid);


--
-- Name: tagging_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY tagging_tag
    ADD CONSTRAINT tagging_tag_name_key UNIQUE (name);


--
-- Name: tagging_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY tagging_tag
    ADD CONSTRAINT tagging_tag_pkey PRIMARY KEY (id);


--
-- Name: tagging_taggeditem_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY tagging_taggeditem
    ADD CONSTRAINT tagging_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: tagging_taggeditem_tag_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY tagging_taggeditem
    ADD CONSTRAINT tagging_taggeditem_tag_id_key UNIQUE (tag_id, content_type_id, object_id);


--
-- Name: web_art_installation_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY web_art_installation
    ADD CONSTRAINT web_art_installation_pkey PRIMARY KEY (id);


--
-- Name: web_circular_street_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY web_circular_street
    ADD CONSTRAINT web_circular_street_pkey PRIMARY KEY (id);


--
-- Name: web_playa_event_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY web_playa_event
    ADD CONSTRAINT web_playa_event_pkey PRIMARY KEY (id);


--
-- Name: web_theme_camp_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY web_theme_camp_participants
    ADD CONSTRAINT web_theme_camp_participants_pkey PRIMARY KEY (id);


--
-- Name: web_theme_camp_participants_theme_camp_id_key; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY web_theme_camp_participants
    ADD CONSTRAINT web_theme_camp_participants_theme_camp_id_key UNIQUE (theme_camp_id, user_id);


--
-- Name: web_theme_camp_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY web_theme_camp
    ADD CONSTRAINT web_theme_camp_pkey PRIMARY KEY (id);


--
-- Name: web_year_pkey; Type: CONSTRAINT; Schema: public; Owner: bmeadmin; Tablespace: 
--

ALTER TABLE ONLY web_year
    ADD CONSTRAINT web_year_pkey PRIMARY KEY (id);


--
-- Name: auth_message_user_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX auth_message_user_id ON auth_message USING btree (user_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_flatpage_url; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX django_flatpage_url ON django_flatpage USING btree (url);


--
-- Name: feedjack_post_feed_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX feedjack_post_feed_id ON feedjack_post USING btree (feed_id);


--
-- Name: feedjack_post_guid; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX feedjack_post_guid ON feedjack_post USING btree (guid);


--
-- Name: feedjack_subscriber_feed_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX feedjack_subscriber_feed_id ON feedjack_subscriber USING btree (feed_id);


--
-- Name: feedjack_subscriber_site_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX feedjack_subscriber_site_id ON feedjack_subscriber USING btree (site_id);


--
-- Name: tagging_taggeditem_content_type_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX tagging_taggeditem_content_type_id ON tagging_taggeditem USING btree (content_type_id);


--
-- Name: tagging_taggeditem_object_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX tagging_taggeditem_object_id ON tagging_taggeditem USING btree (object_id);


--
-- Name: tagging_taggeditem_tag_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX tagging_taggeditem_tag_id ON tagging_taggeditem USING btree (tag_id);


--
-- Name: web_art_installation_circular_street_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_art_installation_circular_street_id ON web_art_installation USING btree (circular_street_id);


--
-- Name: web_art_installation_location_point_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_art_installation_location_point_id ON web_art_installation USING gist (location_point);


--
-- Name: web_art_installation_location_poly_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_art_installation_location_poly_id ON web_art_installation USING gist (location_poly);


--
-- Name: web_art_installation_slug; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_art_installation_slug ON web_art_installation USING btree (slug);


--
-- Name: web_art_installation_year_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_art_installation_year_id ON web_art_installation USING btree (year_id);


--
-- Name: web_circular_street_year_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_circular_street_year_id ON web_circular_street USING btree (year_id);


--
-- Name: web_playa_event_hosted_by_camp_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_playa_event_hosted_by_camp_id ON web_playa_event USING btree (hosted_by_camp_id);


--
-- Name: web_playa_event_located_at_art_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_playa_event_located_at_art_id ON web_playa_event USING btree (located_at_art_id);


--
-- Name: web_playa_event_location_point_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_playa_event_location_point_id ON web_playa_event USING gist (location_point);


--
-- Name: web_playa_event_location_track_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_playa_event_location_track_id ON web_playa_event USING gist (location_track);


--
-- Name: web_playa_event_year_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_playa_event_year_id ON web_playa_event USING btree (year_id);


--
-- Name: web_theme_camp_circular_street_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_theme_camp_circular_street_id ON web_theme_camp USING btree (circular_street_id);


--
-- Name: web_theme_camp_location_point_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_theme_camp_location_point_id ON web_theme_camp USING gist (location_point);


--
-- Name: web_theme_camp_location_poly_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_theme_camp_location_poly_id ON web_theme_camp USING gist (location_poly);


--
-- Name: web_theme_camp_year_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_theme_camp_year_id ON web_theme_camp USING btree (year_id);


--
-- Name: web_year_location_point_id; Type: INDEX; Schema: public; Owner: bmeadmin; Tablespace: 
--

CREATE INDEX web_year_location_point_id ON web_year USING gist (location_point);


--
-- Name: auth_group_permissions_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_728de91f; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_728de91f FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_flatpage_sites_flatpage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_flatpage_id_fkey FOREIGN KEY (flatpage_id) REFERENCES django_flatpage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_flatpage_sites_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY django_flatpage_sites
    ADD CONSTRAINT django_flatpage_sites_site_id_fkey FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feedjack_post_feed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY feedjack_post
    ADD CONSTRAINT feedjack_post_feed_id_fkey FOREIGN KEY (feed_id) REFERENCES feedjack_feed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feedjack_post_tags_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY feedjack_post_tags
    ADD CONSTRAINT feedjack_post_tags_post_id_fkey FOREIGN KEY (post_id) REFERENCES feedjack_post(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feedjack_post_tags_tag_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY feedjack_post_tags
    ADD CONSTRAINT feedjack_post_tags_tag_id_fkey FOREIGN KEY (tag_id) REFERENCES feedjack_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feedjack_site_links_link_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY feedjack_site_links
    ADD CONSTRAINT feedjack_site_links_link_id_fkey FOREIGN KEY (link_id) REFERENCES feedjack_link(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feedjack_site_links_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY feedjack_site_links
    ADD CONSTRAINT feedjack_site_links_site_id_fkey FOREIGN KEY (site_id) REFERENCES feedjack_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feedjack_subscriber_feed_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY feedjack_subscriber
    ADD CONSTRAINT feedjack_subscriber_feed_id_fkey FOREIGN KEY (feed_id) REFERENCES feedjack_feed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feedjack_subscriber_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY feedjack_subscriber
    ADD CONSTRAINT feedjack_subscriber_site_id_fkey FOREIGN KEY (site_id) REFERENCES feedjack_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tag_id_refs_id_60aefff3; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY tagging_taggeditem
    ADD CONSTRAINT tag_id_refs_id_60aefff3 FOREIGN KEY (tag_id) REFERENCES tagging_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tagging_taggeditem_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY tagging_taggeditem
    ADD CONSTRAINT tagging_taggeditem_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_650f49a6; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT user_id_refs_id_650f49a6 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: web_art_installation_circular_street_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY web_art_installation
    ADD CONSTRAINT web_art_installation_circular_street_id_fkey FOREIGN KEY (circular_street_id) REFERENCES web_circular_street(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: web_art_installation_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY web_art_installation
    ADD CONSTRAINT web_art_installation_year_id_fkey FOREIGN KEY (year_id) REFERENCES web_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: web_playa_event_hosted_by_camp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY web_playa_event
    ADD CONSTRAINT web_playa_event_hosted_by_camp_id_fkey FOREIGN KEY (hosted_by_camp_id) REFERENCES web_theme_camp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: web_playa_event_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY web_playa_event
    ADD CONSTRAINT web_playa_event_year_id_fkey FOREIGN KEY (year_id) REFERENCES web_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: web_theme_camp_circular_street_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY web_theme_camp
    ADD CONSTRAINT web_theme_camp_circular_street_id_fkey FOREIGN KEY (circular_street_id) REFERENCES web_circular_street(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: web_theme_camp_participants_theme_camp_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY web_theme_camp_participants
    ADD CONSTRAINT web_theme_camp_participants_theme_camp_id_fkey FOREIGN KEY (theme_camp_id) REFERENCES web_theme_camp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: web_theme_camp_participants_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY web_theme_camp_participants
    ADD CONSTRAINT web_theme_camp_participants_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: web_theme_camp_year_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY web_theme_camp
    ADD CONSTRAINT web_theme_camp_year_id_fkey FOREIGN KEY (year_id) REFERENCES web_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: year_id_refs_id_4f38e2fa; Type: FK CONSTRAINT; Schema: public; Owner: bmeadmin
--

ALTER TABLE ONLY web_circular_street
    ADD CONSTRAINT year_id_refs_id_4f38e2fa FOREIGN KEY (year_id) REFERENCES web_year(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- Name: web_theme_camp; Type: ACL; Schema: public; Owner: bmeadmin
--

REVOKE ALL ON TABLE web_theme_camp FROM PUBLIC;
REVOKE ALL ON TABLE web_theme_camp FROM bmeadmin;
GRANT ALL ON TABLE web_theme_camp TO bmeadmin;
GRANT ALL ON TABLE web_theme_camp TO "www-data";


--
-- PostgreSQL database dump complete
--

